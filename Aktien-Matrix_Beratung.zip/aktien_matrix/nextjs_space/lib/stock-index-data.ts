// Major index constituents with names for search
export interface IndexStock {
  ticker: string;
  name: string;
  sector: string;
  index: string;
}

// Sector classification for peer matching
export const SECTOR_LABELS: Record<string, string> = {
  tech: 'Technologie',
  health: 'Gesundheit',
  pharma: 'Pharma',
  finance: 'Finanzen',
  energy: 'Energie',
  consumer: 'Konsum',
  industrial: 'Industrie',
  auto: 'Automobil / E-Mobilität',
  telecom: 'Telekommunikation',
  utility: 'Versorger',
  realestate: 'Immobilien',
  materials: 'Grundstoffe',
  defense: 'Rüstung / Verteidigung',
  semiconductor: 'Halbleiter',
  software: 'Software / Cloud',
  retail: 'Einzelhandel',
  food: 'Nahrungsmittel / Getränke',
  luxury: 'Luxusgüter',
  insurance: 'Versicherung',
  banking: 'Banken',
  chemical: 'Chemie',
  media: 'Medien / Entertainment',
};

export const INDEX_STOCKS: IndexStock[] = [
  // === DAX 40 ===
  { ticker: 'SAP.DE', name: 'SAP', sector: 'software', index: 'DAX' },
  { ticker: 'SIE.DE', name: 'Siemens', sector: 'industrial', index: 'DAX' },
  { ticker: 'ALV.DE', name: 'Allianz', sector: 'insurance', index: 'DAX' },
  { ticker: 'DTE.DE', name: 'Deutsche Telekom', sector: 'telecom', index: 'DAX' },
  { ticker: 'AIR.DE', name: 'Airbus', sector: 'industrial', index: 'DAX' },
  { ticker: 'MUV2.DE', name: 'Munich Re', sector: 'insurance', index: 'DAX' },
  { ticker: 'DHL.DE', name: 'Deutsche Post DHL', sector: 'industrial', index: 'DAX' },
  { ticker: 'MBG.DE', name: 'Mercedes-Benz', sector: 'auto', index: 'DAX' },
  { ticker: 'BMW.DE', name: 'BMW', sector: 'auto', index: 'DAX' },
  { ticker: 'VOW3.DE', name: 'Volkswagen VZ', sector: 'auto', index: 'DAX' },
  { ticker: 'BAS.DE', name: 'BASF', sector: 'chemical', index: 'DAX' },
  { ticker: 'BAYN.DE', name: 'Bayer', sector: 'pharma', index: 'DAX' },
  { ticker: 'IFX.DE', name: 'Infineon', sector: 'semiconductor', index: 'DAX' },
  { ticker: 'ADS.DE', name: 'adidas', sector: 'consumer', index: 'DAX' },
  { ticker: 'DB1.DE', name: 'Deutsche Börse', sector: 'finance', index: 'DAX' },
  { ticker: 'RHM.DE', name: 'Rheinmetall', sector: 'defense', index: 'DAX' },
  { ticker: 'HEN3.DE', name: 'Henkel VZ', sector: 'consumer', index: 'DAX' },
  { ticker: 'BEI.DE', name: 'Beiersdorf', sector: 'consumer', index: 'DAX' },
  { ticker: 'RWE.DE', name: 'RWE', sector: 'energy', index: 'DAX' },
  { ticker: 'EOAN.DE', name: 'E.ON', sector: 'utility', index: 'DAX' },
  { ticker: 'FRE.DE', name: 'Fresenius', sector: 'health', index: 'DAX' },
  { ticker: 'HEI.DE', name: 'HeidelbergCement', sector: 'materials', index: 'DAX' },
  { ticker: 'SHL.DE', name: 'Siemens Healthineers', sector: 'health', index: 'DAX' },
  { ticker: 'MTX.DE', name: 'MTU Aero Engines', sector: 'industrial', index: 'DAX' },
  { ticker: 'SRT3.DE', name: 'Sartorius VZ', sector: 'health', index: 'DAX' },
  { ticker: 'P911.DE', name: 'Porsche AG', sector: 'auto', index: 'DAX' },
  { ticker: 'PAH3.DE', name: 'Porsche SE', sector: 'auto', index: 'DAX' },
  { ticker: 'ENR.DE', name: 'Siemens Energy', sector: 'energy', index: 'DAX' },
  { ticker: 'CBK.DE', name: 'Commerzbank', sector: 'banking', index: 'DAX' },
  { ticker: 'DBK.DE', name: 'Deutsche Bank', sector: 'banking', index: 'DAX' },
  { ticker: 'VNA.DE', name: 'Vonovia', sector: 'realestate', index: 'DAX' },
  { ticker: 'QIA.DE', name: 'Qiagen', sector: 'health', index: 'DAX' },
  { ticker: 'ZAL.DE', name: 'Zalando', sector: 'retail', index: 'DAX' },
  { ticker: 'SY1.DE', name: 'Symrise', sector: 'chemical', index: 'DAX' },
  { ticker: 'MRK.DE', name: 'Merck KGaA', sector: 'pharma', index: 'DAX' },
  { ticker: 'HNR1.DE', name: 'Hannover Rück', sector: 'insurance', index: 'DAX' },
  { ticker: 'BNR.DE', name: 'Brenntag', sector: 'chemical', index: 'DAX' },
  { ticker: 'CON.DE', name: 'Continental', sector: 'auto', index: 'DAX' },

  // === S&P 500 (Top 50) ===
  { ticker: 'AAPL', name: 'Apple', sector: 'tech', index: 'S&P 500' },
  { ticker: 'MSFT', name: 'Microsoft', sector: 'software', index: 'S&P 500' },
  { ticker: 'NVDA', name: 'NVIDIA', sector: 'semiconductor', index: 'S&P 500' },
  { ticker: 'GOOGL', name: 'Alphabet (Google)', sector: 'tech', index: 'S&P 500' },
  { ticker: 'AMZN', name: 'Amazon', sector: 'retail', index: 'S&P 500' },
  { ticker: 'META', name: 'Meta (Facebook)', sector: 'media', index: 'S&P 500' },
  { ticker: 'TSLA', name: 'Tesla', sector: 'auto', index: 'S&P 500' },
  { ticker: 'BRK-B', name: 'Berkshire Hathaway', sector: 'finance', index: 'S&P 500' },
  { ticker: 'UNH', name: 'UnitedHealth', sector: 'health', index: 'S&P 500' },
  { ticker: 'JNJ', name: 'Johnson & Johnson', sector: 'health', index: 'S&P 500' },
  { ticker: 'V', name: 'Visa', sector: 'finance', index: 'S&P 500' },
  { ticker: 'XOM', name: 'Exxon Mobil', sector: 'energy', index: 'S&P 500' },
  { ticker: 'JPM', name: 'JPMorgan Chase', sector: 'banking', index: 'S&P 500' },
  { ticker: 'MA', name: 'Mastercard', sector: 'finance', index: 'S&P 500' },
  { ticker: 'PG', name: 'Procter & Gamble', sector: 'consumer', index: 'S&P 500' },
  { ticker: 'HD', name: 'Home Depot', sector: 'retail', index: 'S&P 500' },
  { ticker: 'CVX', name: 'Chevron', sector: 'energy', index: 'S&P 500' },
  { ticker: 'MRK', name: 'Merck & Co', sector: 'pharma', index: 'S&P 500' },
  { ticker: 'ABBV', name: 'AbbVie', sector: 'pharma', index: 'S&P 500' },
  { ticker: 'LLY', name: 'Eli Lilly', sector: 'pharma', index: 'S&P 500' },
  { ticker: 'PFE', name: 'Pfizer', sector: 'pharma', index: 'S&P 500' },
  { ticker: 'KO', name: 'Coca-Cola', sector: 'food', index: 'S&P 500' },
  { ticker: 'PEP', name: 'PepsiCo', sector: 'food', index: 'S&P 500' },
  { ticker: 'AVGO', name: 'Broadcom', sector: 'semiconductor', index: 'S&P 500' },
  { ticker: 'COST', name: 'Costco', sector: 'retail', index: 'S&P 500' },
  { ticker: 'TMO', name: 'Thermo Fisher Scientific', sector: 'health', index: 'S&P 500' },
  { ticker: 'WMT', name: 'Walmart', sector: 'retail', index: 'S&P 500' },
  { ticker: 'BAC', name: 'Bank of America', sector: 'banking', index: 'S&P 500' },
  { ticker: 'DIS', name: 'Walt Disney', sector: 'media', index: 'S&P 500' },
  { ticker: 'CSCO', name: 'Cisco Systems', sector: 'tech', index: 'S&P 500' },
  { ticker: 'ADBE', name: 'Adobe', sector: 'software', index: 'S&P 500' },
  { ticker: 'CRM', name: 'Salesforce', sector: 'software', index: 'S&P 500' },
  { ticker: 'NFLX', name: 'Netflix', sector: 'media', index: 'S&P 500' },
  { ticker: 'AMD', name: 'Advanced Micro Devices', sector: 'semiconductor', index: 'S&P 500' },
  { ticker: 'INTC', name: 'Intel', sector: 'semiconductor', index: 'S&P 500' },
  { ticker: 'NKE', name: 'Nike', sector: 'consumer', index: 'S&P 500' },
  { ticker: 'BA', name: 'Boeing', sector: 'industrial', index: 'S&P 500' },
  { ticker: 'GS', name: 'Goldman Sachs', sector: 'banking', index: 'S&P 500' },
  { ticker: 'CAT', name: 'Caterpillar', sector: 'industrial', index: 'S&P 500' },
  { ticker: 'RTX', name: 'RTX (Raytheon)', sector: 'defense', index: 'S&P 500' },
  { ticker: 'LMT', name: 'Lockheed Martin', sector: 'defense', index: 'S&P 500' },
  { ticker: 'NOC', name: 'Northrop Grumman', sector: 'defense', index: 'S&P 500' },
  { ticker: 'GD', name: 'General Dynamics', sector: 'defense', index: 'S&P 500' },
  { ticker: 'QCOM', name: 'Qualcomm', sector: 'semiconductor', index: 'S&P 500' },
  { ticker: 'T', name: 'AT&T', sector: 'telecom', index: 'S&P 500' },
  { ticker: 'VZ', name: 'Verizon', sector: 'telecom', index: 'S&P 500' },
  { ticker: 'ORCL', name: 'Oracle', sector: 'software', index: 'S&P 500' },
  { ticker: 'IBM', name: 'IBM', sector: 'tech', index: 'S&P 500' },
  { ticker: 'GE', name: 'General Electric', sector: 'industrial', index: 'S&P 500' },
  { ticker: 'MMM', name: '3M', sector: 'industrial', index: 'S&P 500' },

  // === NASDAQ 100 (zusätzliche) ===
  { ticker: 'MRVL', name: 'Marvell Technology', sector: 'semiconductor', index: 'NASDAQ' },
  { ticker: 'PANW', name: 'Palo Alto Networks', sector: 'software', index: 'NASDAQ' },
  { ticker: 'SNPS', name: 'Synopsys', sector: 'software', index: 'NASDAQ' },
  { ticker: 'CDNS', name: 'Cadence Design', sector: 'software', index: 'NASDAQ' },
  { ticker: 'ABNB', name: 'Airbnb', sector: 'consumer', index: 'NASDAQ' },
  { ticker: 'LRCX', name: 'Lam Research', sector: 'semiconductor', index: 'NASDAQ' },
  { ticker: 'KLAC', name: 'KLA Corp', sector: 'semiconductor', index: 'NASDAQ' },
  { ticker: 'ASML', name: 'ASML', sector: 'semiconductor', index: 'NASDAQ' },
  { ticker: 'AMAT', name: 'Applied Materials', sector: 'semiconductor', index: 'NASDAQ' },
  { ticker: 'MU', name: 'Micron Technology', sector: 'semiconductor', index: 'NASDAQ' },
  { ticker: 'PYPL', name: 'PayPal', sector: 'finance', index: 'NASDAQ' },
  { ticker: 'UBER', name: 'Uber', sector: 'tech', index: 'NASDAQ' },
  { ticker: 'SQ', name: 'Block (Square)', sector: 'finance', index: 'NASDAQ' },
  { ticker: 'SHOP', name: 'Shopify', sector: 'software', index: 'NASDAQ' },
  { ticker: 'SNOW', name: 'Snowflake', sector: 'software', index: 'NASDAQ' },
  { ticker: 'PLTR', name: 'Palantir', sector: 'software', index: 'NASDAQ' },
  { ticker: 'ARM', name: 'ARM Holdings', sector: 'semiconductor', index: 'NASDAQ' },
  { ticker: 'COIN', name: 'Coinbase', sector: 'finance', index: 'NASDAQ' },

  // === EURO STOXX 50 (zusätzliche) ===
  { ticker: 'MC.PA', name: 'LVMH', sector: 'luxury', index: 'EURO STOXX' },
  { ticker: 'OR.PA', name: "L'Oréal", sector: 'consumer', index: 'EURO STOXX' },
  { ticker: 'SAN.PA', name: 'Sanofi', sector: 'pharma', index: 'EURO STOXX' },
  { ticker: 'TTE.PA', name: 'TotalEnergies', sector: 'energy', index: 'EURO STOXX' },
  { ticker: 'AI.PA', name: 'Air Liquide', sector: 'chemical', index: 'EURO STOXX' },
  { ticker: 'SU.PA', name: 'Schneider Electric', sector: 'industrial', index: 'EURO STOXX' },
  { ticker: 'KER.PA', name: 'Kering (Gucci)', sector: 'luxury', index: 'EURO STOXX' },
  { ticker: 'CDI.PA', name: 'Christian Dior', sector: 'luxury', index: 'EURO STOXX' },
  { ticker: 'BN.PA', name: 'Danone', sector: 'food', index: 'EURO STOXX' },
  { ticker: 'ASML', name: 'ASML (NL)', sector: 'semiconductor', index: 'EURO STOXX' },
  { ticker: 'NESN.SW', name: 'Nestlé', sector: 'food', index: 'SMI' },
  { ticker: 'ROG.SW', name: 'Roche', sector: 'pharma', index: 'SMI' },
  { ticker: 'NOVN.SW', name: 'Novartis', sector: 'pharma', index: 'SMI' },

  // === Weitere wichtige Einzeltitel ===
  { ticker: 'NVO', name: 'Novo Nordisk', sector: 'pharma', index: 'OMX Copenhagen' },
  { ticker: 'BYDDY', name: 'BYD Company', sector: 'auto', index: 'Shenzhen' },
  { ticker: 'NIO', name: 'NIO', sector: 'auto', index: 'NYSE' },
  { ticker: 'BABA', name: 'Alibaba', sector: 'tech', index: 'NYSE' },
  { ticker: 'TSM', name: 'TSMC', sector: 'semiconductor', index: 'NYSE' },
  { ticker: 'SONY', name: 'Sony', sector: 'tech', index: 'NYSE' },
  { ticker: 'TM', name: 'Toyota', sector: 'auto', index: 'NYSE' },
];

// Search function - searches by name AND ticker
export function searchStocks(query: string, limit: number = 12): IndexStock[] {
  if (!query || query.trim().length < 1) return [];
  const q = query.trim().toLowerCase();
  
  // Exact ticker match first
  const exactTicker = INDEX_STOCKS.filter(s => s.ticker.toLowerCase() === q);
  if (exactTicker.length > 0) return exactTicker.slice(0, limit);
  
  // Score-based search
  const scored = INDEX_STOCKS.map(s => {
    let score = 0;
    const tickerLower = s.ticker.toLowerCase();
    const nameLower = s.name.toLowerCase();
    const sectorLabel = (SECTOR_LABELS[s.sector] ?? '').toLowerCase();
    
    // Ticker starts with query
    if (tickerLower.startsWith(q)) score += 100;
    else if (tickerLower.includes(q)) score += 50;
    
    // Name starts with query
    if (nameLower.startsWith(q)) score += 90;
    else if (nameLower.includes(q)) score += 40;
    
    // Sector match
    if (sectorLabel.includes(q)) score += 30;
    
    // Index match
    if (s.index.toLowerCase().includes(q)) score += 20;
    
    return { stock: s, score };
  }).filter(s => s.score > 0)
    .sort((a, b) => b.score - a.score)
    .slice(0, limit)
    .map(s => s.stock);
  
  return scored;
}

// Get all stocks in the same sector
export function getSectorPeers(ticker: string): IndexStock[] {
  const stock = INDEX_STOCKS.find(s => s.ticker.toUpperCase() === ticker.toUpperCase());
  if (!stock) return [];
  return INDEX_STOCKS.filter(s => s.sector === stock.sector && s.ticker !== stock.ticker);
}

// Get stock info by ticker
export function getStockInfo(ticker: string): IndexStock | undefined {
  return INDEX_STOCKS.find(s => s.ticker.toUpperCase() === ticker.toUpperCase());
}
