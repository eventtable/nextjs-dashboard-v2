// Shared Users - für Serverless Umgebungen
// ⚠️ WICHTIG: Keine Klartext-Passwörter in diesem File!
// Auth wird über NextAuth und Umgebungsvariablen verwaltet.

export const SHARED_USERS: Record<string, any> = {};
