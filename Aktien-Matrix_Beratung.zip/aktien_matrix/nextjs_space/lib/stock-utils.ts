// RSI Calculation from close prices
export function calculateRSI(closes: number[], period: number = 14): number {
  if (!closes || closes.length < period + 1) return 50;
  
  const changes: number[] = [];
  for (let i = 1; i < closes.length; i++) {
    changes.push((closes[i] ?? 0) - (closes[i - 1] ?? 0));
  }
  
  let avgGain = 0;
  let avgLoss = 0;
  
  for (let i = 0; i < period; i++) {
    const change = changes[i] ?? 0;
    if (change > 0) avgGain += change;
    else avgLoss += Math.abs(change);
  }
  
  avgGain /= period;
  avgLoss /= period;
  
  for (let i = period; i < changes.length; i++) {
    const change = changes[i] ?? 0;
    if (change > 0) {
      avgGain = (avgGain * (period - 1) + change) / period;
      avgLoss = (avgLoss * (period - 1)) / period;
    } else {
      avgGain = (avgGain * (period - 1)) / period;
      avgLoss = (avgLoss * (period - 1) + Math.abs(change)) / period;
    }
  }
  
  if (avgLoss === 0) return 100;
  const rs = avgGain / avgLoss;
  return 100 - (100 / (1 + rs));
}

// Matrix Ampel Logic
export type AmpelStatus = 'gruen' | 'gelb' | 'orange' | 'rot';

export interface AmpelResult {
  status: AmpelStatus;
  label: string;
  emoji: string;
  color: string;
  beschreibung: string;
}

export function berechneAmpel(data: {
  kgv: number | null;
  rsi: number;
  fcfPositiv: boolean;
  dividendenRendite: number;
  umsatzWachstum: number | null;
  verschuldungsgrad: number | null;
}): AmpelResult {
  let score = 0;
  const kgv = data?.kgv;
  const rsi = data?.rsi ?? 50;
  const fcf = data?.fcfPositiv ?? false;
  const div = data?.dividendenRendite ?? 0;
  const wachstum = data?.umsatzWachstum;
  const verschuldung = data?.verschuldungsgrad;

  // KGV Score
  if (kgv !== null && kgv !== undefined) {
    if (kgv > 0 && kgv < 15) score += 3;
    else if (kgv >= 15 && kgv <= 25) score += 2;
    else if (kgv > 25 && kgv <= 35) score += 1;
    else if (kgv > 35) score -= 1;
  }

  // RSI Score
  if (rsi >= 30 && rsi <= 50) score += 3;
  else if (rsi > 50 && rsi <= 70) score += 2;
  else if (rsi > 70 && rsi <= 80) score -= 1;
  else if (rsi > 80) score -= 2;
  else if (rsi < 30) score += 1;

  // FCF Score
  if (fcf) score += 2;
  else score -= 1;

  // Dividende Score
  if (div >= 3) score += 2;
  else if (div >= 1) score += 1;

  // Umsatzwachstum
  if (wachstum !== null && wachstum !== undefined) {
    if (wachstum > 10) score += 2;
    else if (wachstum > 0) score += 1;
    else score -= 1;
  }

  // Verschuldung
  if (verschuldung !== null && verschuldung !== undefined) {
    if (verschuldung < 0.5) score += 1;
    else if (verschuldung > 1.5) score -= 1;
  }

  if (score >= 8) return { status: 'gruen', label: 'Halten / Nachkauf', emoji: '🟢', color: '#22c55e', beschreibung: 'Starke Fundamentaldaten. Position halten oder nachkaufen.' };
  if (score >= 5) return { status: 'gelb', label: 'Prüfen', emoji: '🟡', color: '#eab308', beschreibung: 'Gemischte Signale. Weitere Analyse empfohlen.' };
  if (score >= 2) return { status: 'orange', label: 'Vorsicht', emoji: '🟠', color: '#f97316', beschreibung: 'Mehrere Warnsignale. Position überprüfen.' };
  return { status: 'rot', label: 'Rotation', emoji: '🔴', color: '#ef4444', beschreibung: 'Starke Warnsignale. Rotation in Betracht ziehen.' };
}

// Peer Groups
export const PEER_GROUPS: Record<string, { name: string; tickers: string[] }> = {
  gesundheit: { name: 'Gesundheit', tickers: ['MRK', 'UNH', 'JNJ'] },
  pharma: { name: 'Pharma / Diabetes', tickers: ['NVO', 'LLY'] },
  technologie: { name: 'Technologie', tickers: ['GOOGL', 'MSFT', 'META'] },
  emobilitaet: { name: 'E-Mobilität', tickers: ['BYDDY', 'TSLA', 'NIO'] },
};

export function findPeerGroup(ticker: string): { name: string; tickers: string[] } | null {
  const upperTicker = ticker?.toUpperCase?.() ?? '';
  for (const group of Object.values(PEER_GROUPS ?? {})) {
    if (group?.tickers?.includes?.(upperTicker)) {
      return group;
    }
  }
  return null;
}

// Format helpers
export function formatNumber(num: number | null | undefined, decimals: number = 2): string {
  if (num === null || num === undefined || isNaN(num)) return 'N/A';
  return num.toLocaleString('de-DE', { minimumFractionDigits: decimals, maximumFractionDigits: decimals });
}

export function formatMarketCap(num: number | null | undefined): string {
  if (num === null || num === undefined || isNaN(num)) return 'N/A';
  if (num >= 1e12) return `${(num / 1e12).toFixed(2)} Bio. $`;
  if (num >= 1e9) return `${(num / 1e9).toFixed(2)} Mrd. $`;
  if (num >= 1e6) return `${(num / 1e6).toFixed(2)} Mio. $`;
  return `${num.toFixed(0)} $`;
}

export function formatPercent(num: number | null | undefined): string {
  if (num === null || num === undefined || isNaN(num)) return 'N/A';
  const sign = num >= 0 ? '+' : '';
  return `${sign}${num.toFixed(2)}%`;
}
