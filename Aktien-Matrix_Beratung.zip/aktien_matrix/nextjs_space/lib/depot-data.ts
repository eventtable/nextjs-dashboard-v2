// Trade Republic Depot – Frank Müller (Stand: 27.03.2026)
// Hinweis: Trade Republic bietet KEINE offizielle öffentliche API an.
// Die Daten werden manuell gepflegt und Live-Kurse über Yahoo Finance geladen.

export type AssetCategory = 'aktie' | 'etf' | 'etp' | 'anleihe';
export type StrategyType = 'performance' | 'dividende' | 'etf_fonds' | 'rohstoff' | 'absicherung' | 'anleihe';

export interface DepotPosition {
  name: string;
  shortName: string;
  isin: string;
  ticker: string; // Yahoo Finance Ticker
  stueck: number;
  kaufkurs: number; // Kurs pro Stück beim letzten Stand (27.03.2026)
  kaufwert: number; // Gesamtkurswert zum Kaufzeitpunkt
  category: AssetCategory;
  strategy: StrategyType;
  currency: string;
  lagerland: string;
}

export const DEPOT_POSITIONS: DepotPosition[] = [
  // === EINZELAKTIEN ===
  {
    name: 'Barrick Mining Corp.',
    shortName: 'Barrick Gold',
    isin: 'CA06849F1080',
    ticker: 'GOLD',
    stueck: 14,
    kaufkurs: 32.61,
    kaufwert: 456.54,
    category: 'aktie',
    strategy: 'rohstoff',
    currency: 'EUR',
    lagerland: 'Kanada',
  },
  {
    name: 'BYD Co. Ltd.',
    shortName: 'BYD',
    isin: 'CNE100000296',
    ticker: '1211.HK',
    stueck: 43,
    kaufkurs: 11.31,
    kaufwert: 486.12,
    category: 'aktie',
    strategy: 'performance',
    currency: 'EUR',
    lagerland: 'Hongkong',
  },
  {
    name: 'SAP SE',
    shortName: 'SAP',
    isin: 'DE0007164600',
    ticker: 'SAP.DE',
    stueck: 2.5,
    kaufkurs: 145.80,
    kaufwert: 364.50,
    category: 'aktie',
    strategy: 'performance',
    currency: 'EUR',
    lagerland: 'Deutschland',
  },
  {
    name: 'Allianz SE',
    shortName: 'Allianz',
    isin: 'DE0008404005',
    ticker: 'ALV.DE',
    stueck: 1,
    kaufkurs: 351.40,
    kaufwert: 351.40,
    category: 'aktie',
    strategy: 'dividende',
    currency: 'EUR',
    lagerland: 'Deutschland',
  },
  {
    name: 'Münchener Rückvers.-Ges. AG',
    shortName: 'Munich Re',
    isin: 'DE0008430026',
    ticker: 'MUV2.DE',
    stueck: 1,
    kaufkurs: 520.20,
    kaufwert: 520.20,
    category: 'aktie',
    strategy: 'dividende',
    currency: 'EUR',
    lagerland: 'Deutschland',
  },
  {
    name: 'Novo-Nordisk AS',
    shortName: 'Novo Nordisk',
    isin: 'DK0062498333',
    ticker: 'NOVO-B.CO',
    stueck: 21.5,
    kaufkurs: 31.76,
    kaufwert: 682.84,
    category: 'aktie',
    strategy: 'performance',
    currency: 'EUR',
    lagerland: 'Dänemark',
  },
  {
    name: 'Microsoft Corp.',
    shortName: 'Microsoft',
    isin: 'US5949181045',
    ticker: 'MSFT',
    stueck: 1.45,
    kaufkurs: 317.25,
    kaufwert: 460.01,
    category: 'aktie',
    strategy: 'performance',
    currency: 'EUR',
    lagerland: 'USA',
  },

  // === ETFs ===
  {
    name: 'HanETF Future of Defence ETF',
    shortName: 'Defence ETF',
    isin: 'IE000OJ5TQP4',
    ticker: 'NATO.DE',
    stueck: 31,
    kaufkurs: 16.60,
    kaufwert: 514.60,
    category: 'etf',
    strategy: 'etf_fonds',
    currency: 'EUR',
    lagerland: 'UK',
  },
  {
    name: 'Xtr. Artificial Intelligence & Big Data ETF',
    shortName: 'AI & Big Data ETF',
    isin: 'IE00BGV5VN51',
    ticker: 'XAIX.DE',
    stueck: 4.666933,
    kaufkurs: 146.38,
    kaufwert: 683.15,
    category: 'etf',
    strategy: 'etf_fonds',
    currency: 'EUR',
    lagerland: 'Irland',
  },
  {
    name: 'Vanguard FTSE All-World High Div. Yield ETF',
    shortName: 'Vanguard High Div.',
    isin: 'IE00BK5BR626',
    ticker: 'VGWD.DE',
    stueck: 6.791796,
    kaufkurs: 82.40,
    kaufwert: 559.64,
    category: 'etf',
    strategy: 'dividende',
    currency: 'EUR',
    lagerland: 'UK',
  },
  {
    name: 'Xtr. MSCI World Energy ETF',
    shortName: 'World Energy ETF',
    isin: 'IE00BM67HM91',
    ticker: 'XDW0.DE',
    stueck: 15,
    kaufkurs: 64.14,
    kaufwert: 962.10,
    category: 'etf',
    strategy: 'etf_fonds',
    currency: 'EUR',
    lagerland: 'Irland',
  },
  {
    name: 'iShares Bloomberg Roll Select Commodity ETF',
    shortName: 'Commodity ETF',
    isin: 'IE00BZ1NCS44',
    ticker: 'ROLL.L',
    stueck: 52,
    kaufkurs: 8.96,
    kaufwert: 465.76,
    category: 'etf',
    strategy: 'rohstoff',
    currency: 'EUR',
    lagerland: 'Irland',
  },
  {
    name: 'Amundi MSCI Emerging Markets ETF',
    shortName: 'Emerging Markets ETF',
    isin: 'LU1681045370',
    ticker: 'AEEM.PA',
    stueck: 42,
    kaufkurs: 6.36,
    kaufwert: 266.94,
    category: 'etf',
    strategy: 'etf_fonds',
    currency: 'EUR',
    lagerland: 'Frankreich',
  },

  // === ETPs / Rohstoffe ===
  {
    name: 'iShares Physical Gold ETC',
    shortName: 'Gold ETC',
    isin: 'IE00B4ND3602',
    ticker: 'IGLN.L',
    stueck: 15,
    kaufkurs: 73.14,
    kaufwert: 1097.10,
    category: 'etp',
    strategy: 'rohstoff',
    currency: 'EUR',
    lagerland: 'Irland',
  },
  {
    name: 'WisdomTree DAX 3x Short ETP',
    shortName: 'DAX 3x Short',
    isin: 'IE00B8GKPP93',
    ticker: '3DES.L',
    stueck: 2000,
    kaufkurs: 0.21,
    kaufwert: 416.40,
    category: 'etp',
    strategy: 'absicherung',
    currency: 'EUR',
    lagerland: 'Irland',
  },

  // === ANLEIHEN ===
  {
    name: 'Air Baltic Corporation AS Bonds 2024(24/29)',
    shortName: 'Air Baltic Anleihe',
    isin: 'XS2800678224',
    ticker: '', // Kein Yahoo-Ticker für diese Anleihe
    stueck: 536.82,
    kaufkurs: 0.6925, // 69,25% vom Nennwert
    kaufwert: 371.75,
    category: 'anleihe',
    strategy: 'anleihe',
    currency: 'EUR',
    lagerland: 'UK',
  },
];

// Gesamtwert laut Trade Republic Auszug: 8.659,05 EUR
export const DEPOT_TOTAL_REPORTED = 8659.05;

// Strategie-Kategorien für Balancing
export const STRATEGY_CONFIG: Record<StrategyType, { label: string; color: string; targetPercent: number; description: string }> = {
  performance: {
    label: 'Performance / Wachstum',
    color: '#60B5FF',
    targetPercent: 30,
    description: 'Wachstumsaktien mit hohem Kurspotenzial',
  },
  dividende: {
    label: 'Dividenden / Cashflow',
    color: '#22c55e',
    targetPercent: 20,
    description: 'Stabile Dividendenzahler für regelmäßige Erträge',
  },
  etf_fonds: {
    label: 'ETFs / Fonds',
    color: '#f0b90b',
    targetPercent: 25,
    description: 'Breit gestreute Index- und Themen-ETFs',
  },
  rohstoff: {
    label: 'Rohstoffe / Gold',
    color: '#f59e0b',
    targetPercent: 15,
    description: 'Inflationsschutz und Sachwerte',
  },
  absicherung: {
    label: 'Absicherung / Hedging',
    color: '#ef4444',
    targetPercent: 5,
    description: 'Short-Positionen und Gegengewichte',
  },
  anleihe: {
    label: 'Anleihen / Bonds',
    color: '#8b5cf6',
    targetPercent: 5,
    description: 'Festverzinsliche Wertpapiere',
  },
};

export const CATEGORY_LABELS: Record<AssetCategory, string> = {
  aktie: 'Einzelaktien',
  etf: 'ETFs',
  etp: 'ETPs / Zertifikate',
  anleihe: 'Anleihen',
};
