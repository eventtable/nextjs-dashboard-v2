// Yahoo Finance API für historische Kursdaten
// Kostenlos, keine API-Key nötig

export interface HistoricalData {
  date: string;
  open: number;
  high: number;
  low: number;
  close: number;
  volume: number;
}

export interface MarketScenario {
  id: string;
  name: string;
  description: string;
  period: string;
  tickers: string[];
  characteristics: {
    avgReturn: number;
    volatility: number;
    trend: 'up' | 'down' | 'sideways';
  };
}

// Vordefinierte Markt-Szenarien
export const MARKET_SCENARIOS: MarketScenario[] = [
  {
    id: 'boom',
    name: '🚀 Boom Phase',
    description: 'Bullenmarkt mit steigenden Kursen und niedriger Volatilität',
    period: '2019-01-01 bis 2020-02-01',
    tickers: ['SAP', 'ALV', 'MUV2', 'MSFT'],
    characteristics: { avgReturn: 15, volatility: 12, trend: 'up' }
  },
  {
    id: 'crash',
    name: '📉 Covid Crash',
    description: 'Marktcrash mit hoher Volatilität (März 2020)',
    period: '2020-02-01 bis 2020-04-01',
    tickers: ['SAP', 'ALV', 'MUV2', 'MSFT'],
    characteristics: { avgReturn: -35, volatility: 45, trend: 'down' }
  },
  {
    id: 'inflation',
    name: '💸 Inflationäre Phase',
    description: 'Steigende Zinsen, rotierende Märkte (2022)',
    period: '2022-01-01 bis 2022-12-31',
    tickers: ['SAP', 'ALV', 'MUV2', 'MSFT'],
    characteristics: { avgReturn: -8, volatility: 25, trend: 'sideways' }
  },
  {
    id: 'recovery',
    name: '📈 Recovery Phase',
    description: 'Erholung nach Crash (2020-2021)',
    period: '2020-04-01 bis 2021-12-31',
    tickers: ['SAP', 'ALV', 'MUV2', 'MSFT'],
    characteristics: { avgReturn: 25, volatility: 18, trend: 'up' }
  }
];

// Yahoo Finance API Aufruf mit Timeout
export async function fetchHistoricalData(
  ticker: string,
  startDate: string,
  endDate: string
): Promise<HistoricalData[]> {
  try {
    // Yahoo Finance URL
    const start = Math.floor(new Date(startDate).getTime() / 1000);
    const end = Math.floor(new Date(endDate).getTime() / 1000);
    
    const url = `https://query1.finance.yahoo.com/v7/finance/download/${ticker}?period1=${start}&period2=${end}&interval=1d&events=history`;
    
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 5000); // 5 Sekunden Timeout
    
    const response = await fetch(url, {
      signal: controller.signal
    });
    
    clearTimeout(timeoutId);
    
    if (!response.ok) {
      console.warn('Yahoo Finance nicht erreichbar, verwende Fallback');
      return generateSimulatedData(ticker, startDate, endDate);
    }
    
    const csvText = await response.text();
    
    // Prüfe ob die Antwort valide ist
    if (!csvText || csvText.length < 100) {
      console.warn('Ungültige Yahoo Finance Antwort, verwende Fallback');
      return generateSimulatedData(ticker, startDate, endDate);
    }
    
    const lines = csvText.split('\n').slice(1); // Header überspringen
    
    const data: HistoricalData[] = [];
    
    for (const line of lines) {
      if (!line.trim()) continue;
      const parts = line.split(',');
      
      // Stelle sicher, dass alle Felder vorhanden sind
      if (parts.length < 7) continue;
      
      const [date, open, high, low, close, adjClose, volume] = parts;
      
      // Validiere Daten
      const closePrice = parseFloat(close);
      if (isNaN(closePrice) || closePrice <= 0) continue;
      
      data.push({
        date,
        open: parseFloat(open) || closePrice,
        high: parseFloat(high) || closePrice,
        low: parseFloat(low) || closePrice,
        close: closePrice,
        volume: parseInt(volume) || 0
      });
    }
    
    // Stelle sicher, dass genug Daten vorhanden sind
    if (data.length < 50) {
      console.warn(`Nur ${data.length} Datenpunkte erhalten, verwende Fallback`);
      return generateSimulatedData(ticker, startDate, endDate);
    }
    
    return data.reverse(); // Neueste zuerst
  } catch (error) {
    console.error('Fehler beim Laden der Daten:', error);
    return generateSimulatedData(ticker, startDate, endDate);
  }
}

// Simulierte Daten als Fallback
function generateSimulatedData(
  ticker: string,
  startDate: string,
  endDate: string
): HistoricalData[] {
  const data: HistoricalData[] = [];
  const start = new Date(startDate);
  const end = new Date(endDate);
  
  // Basis-Kurs je nach Ticker
  const basePrices: Record<string, number> = {
    'SAP': 150,
    'ALV': 200,
    'MUV2': 400,
    'MSFT': 300
  };
  
  let currentPrice = basePrices[ticker] || 100;
  
  for (let d = new Date(start); d <= end; d.setDate(d.getDate() + 1)) {
    if (d.getDay() === 0 || d.getDay() === 6) continue; // Wochenende überspringen
    
    const change = (Math.random() - 0.48) * 0.02; // Leicht positiver Trend
    currentPrice = currentPrice * (1 + change);
    
    data.push({
      date: d.toISOString().split('T')[0],
      open: currentPrice * (1 + (Math.random() - 0.5) * 0.01),
      high: currentPrice * (1 + Math.random() * 0.02),
      low: currentPrice * (1 - Math.random() * 0.02),
      close: currentPrice,
      volume: Math.floor(Math.random() * 1000000)
    });
  }
  
  return data.reverse();
}

// Berechne Matrix Score für historischen Zeitpunkt
export function calculateMatrixScoreForDate(
  ticker: string,
  currentPrice: number,
  scenario: MarketScenario
): number {
  // Simulierte Matrix-Bewertung basierend auf Szenario
  const baseScore: Record<string, number> = {
    'boom': 65,
    'crash': 35,
    'inflation': 50,
    'recovery': 70
  };
  
  // Zufällige Schwankung
  const variance = Math.floor(Math.random() * 20) - 10;
  return Math.max(20, Math.min(95, (baseScore[scenario.id] || 50) + variance));
}