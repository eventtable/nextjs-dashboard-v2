import { HistoricalData, MarketScenario, calculateMatrixScoreForDate } from './yahoo-finance';

export interface BacktestTrade {
  date: string;
  ticker: string;
  type: 'long' | 'short';
  entryPrice: number;
  exitPrice?: number;
  shares: number;
  pnl: number;
  pnlPercent: number;
  reason: string;
}

export interface BacktestResult {
  scenario: MarketScenario;
  totalTrades: number;
  winningTrades: number;
  losingTrades: number;
  totalReturn: number;
  maxDrawdown: number;
  sharpeRatio: number;
  trades: BacktestTrade[];
  equityCurve: { date: string; value: number }[];
}

interface BacktestConfig {
  initialCapital: number;
  minScore: number;
  shortThreshold: number;
  positionSize: number; // % des Kapitals
  stopLoss: number;
  takeProfit: number;
  maxPositions: number;
}

export async function runBacktest(
  scenario: MarketScenario,
  config: BacktestConfig
): Promise<BacktestResult> {
  const trades: BacktestTrade[] = [];
  const equityCurve: { date: string; value: number }[] = [];
  
  let capital = config.initialCapital;
  let maxCapital = config.initialCapital;
  let maxDrawdown = 0;
  
  // Lade Daten für alle Tickers
  const tickerData: Record<string, HistoricalData[]> = {};
  
  for (const ticker of scenario.tickers) {
    // Importiere hier dynamisch um Circular Dependencies zu vermeiden
    const { fetchHistoricalData } = await import('./yahoo-finance');
    tickerData[ticker] = await fetchHistoricalData(
      ticker,
      scenario.period.split(' bis ')[0],
      scenario.period.split(' bis ')[1]
    );
  }
  
  // Simuliere Trading Tag für Tag
  const allDates = tickerData[scenario.tickers[0]].map(d => d.date);
  
  for (let i = 20; i < allDates.length; i++) {
    const date = allDates[i];
    const currentDateData: Record<string, HistoricalData> = {};
    
    // Aktuelle Daten für alle Tickers
    for (const ticker of scenario.tickers) {
      const dayData = tickerData[ticker].find(d => d.date === date);
      if (dayData) currentDateData[ticker] = dayData;
    }
    
    // Trading-Logik für jeden Tag
    for (const ticker of scenario.tickers) {
      const data = currentDateData[ticker];
      if (!data) continue;
      
      const score = calculateMatrixScoreForDate(ticker, data.close, scenario);
      const positionSize = capital * (config.positionSize / 100);
      const shares = Math.floor(positionSize / data.close);
      
      if (shares < 1) continue;
      
      // LONG Signal
      if (score >= config.minScore) {
        const entryPrice = data.close;
        const exitDay = Math.min(i + 20, allDates.length - 1); // Halte für 20 Tage oder Stop
        const exitData = tickerData[ticker].find(d => d.date === allDates[exitDay]);
        
        if (exitData) {
          let exitPrice = exitData.close;
          let pnlPercent = ((exitPrice - entryPrice) / entryPrice) * 100;
          
          // Stop Loss / Take Profit
          for (let j = i + 1; j <= exitDay; j++) {
            const checkData = tickerData[ticker].find(d => d.date === allDates[j]);
            if (!checkData) continue;
            
            const currentPnl = ((checkData.close - entryPrice) / entryPrice) * 100;
            
            if (currentPnl <= -config.stopLoss) {
              exitPrice = checkData.close;
              pnlPercent = -config.stopLoss;
              break;
            }
            if (currentPnl >= config.takeProfit) {
              exitPrice = checkData.close;
              pnlPercent = config.takeProfit;
              break;
            }
          }
          
          const pnl = shares * (exitPrice - entryPrice);
          capital += pnl;
          
          trades.push({
            date,
            ticker,
            type: 'long',
            entryPrice,
            exitPrice,
            shares,
            pnl,
            pnlPercent,
            reason: `Score: ${score}/100`
          });
        }
      }
      
      // SHORT Signal
      else if (score <= config.shortThreshold) {
        const entryPrice = data.close;
        const exitDay = Math.min(i + 20, allDates.length - 1);
        const exitData = tickerData[ticker].find(d => d.date === allDates[exitDay]);
        
        if (exitData) {
          let exitPrice = exitData.close;
          let pnlPercent = ((entryPrice - exitPrice) / entryPrice) * 100;
          
          // Stop Loss / Take Profit (inverted für Short)
          for (let j = i + 1; j <= exitDay; j++) {
            const checkData = tickerData[ticker].find(d => d.date === allDates[j]);
            if (!checkData) continue;
            
            const currentPnl = ((entryPrice - checkData.close) / entryPrice) * 100;
            
            if (currentPnl <= -config.stopLoss) {
              exitPrice = checkData.close;
              pnlPercent = -config.stopLoss;
              break;
            }
            if (currentPnl >= config.takeProfit) {
              exitPrice = checkData.close;
              pnlPercent = config.takeProfit;
              break;
            }
          }
          
          const pnl = shares * (entryPrice - exitPrice);
          capital += pnl;
          
          trades.push({
            date,
            ticker,
            type: 'short',
            entryPrice,
            exitPrice,
            shares,
            pnl,
            pnlPercent,
            reason: `Score: ${score}/100 (Short)`
          });
        }
      }
    }
    
    // Track Equity Curve
    equityCurve.push({ date, value: capital });
    
    // Track Max Drawdown
    if (capital > maxCapital) {
      maxCapital = capital;
    }
    const drawdown = ((maxCapital - capital) / maxCapital) * 100;
    if (drawdown > maxDrawdown) {
      maxDrawdown = drawdown;
    }
  }
  
  // Berechne Statistiken
  const winningTrades = trades.filter(t => t.pnl > 0).length;
  const losingTrades = trades.filter(t => t.pnl <= 0).length;
  const totalReturn = ((capital - config.initialCapital) / config.initialCapital) * 100;
  
  // Vereinfachte Sharpe Ratio
  const returns = equityCurve.map((e, i) => {
    if (i === 0) return 0;
    return ((e.value - equityCurve[i-1].value) / equityCurve[i-1].value) * 100;
  }).slice(1);
  
  const avgReturn = returns.reduce((a, b) => a + b, 0) / returns.length;
  const variance = returns.reduce((sum, r) => sum + Math.pow(r - avgReturn, 2), 0) / returns.length;
  const stdDev = Math.sqrt(variance);
  const sharpeRatio = stdDev !== 0 ? (avgReturn / stdDev) * Math.sqrt(252) : 0; // Annualisiert
  
  return {
    scenario,
    totalTrades: trades.length,
    winningTrades,
    losingTrades,
    totalReturn,
    maxDrawdown,
    sharpeRatio,
    trades,
    equityCurve
  };
}