import { prisma } from './prisma';

export interface Session {
  id: string;
  userId: string;
  email: string;
  name: string | null;
  loginAt: Date;
  lastActiveAt: Date;
  ipAddress: string | null;
  isActive: boolean;
}

export async function createSession(userId: string, email: string, name: string, ip: string): Promise<Session> {
  return await prisma.session.create({
    data: {
      userId,
      email,
      name,
      ipAddress: ip,
      isActive: true
    }
  });
}

export async function updateSessionActivity(sessionId: string): Promise<void> {
  await prisma.session.update({
    where: { id: sessionId },
    data: { lastActiveAt: new Date() }
  });
}

export async function deactivateSession(sessionId: string): Promise<void> {
  await prisma.session.update({
    where: { id: sessionId },
    data: { isActive: false }
  });
}

export async function deactivateAllUserSessions(userId: string): Promise<void> {
  await prisma.session.updateMany({
    where: { userId },
    data: { isActive: false }
  });
}

export async function getActiveSessions(): Promise<Session[]> {
  const fiveMinutesAgo = new Date(Date.now() - 5 * 60 * 1000);
  return await prisma.session.findMany({
    where: {
      isActive: true,
      lastActiveAt: { gte: fiveMinutesAgo }
    },
    orderBy: { lastActiveAt: 'desc' }
  });
}

export async function getAllSessions(): Promise<Session[]> {
  return await prisma.session.findMany({
    orderBy: { lastActiveAt: 'desc' },
    take: 100
  });
}