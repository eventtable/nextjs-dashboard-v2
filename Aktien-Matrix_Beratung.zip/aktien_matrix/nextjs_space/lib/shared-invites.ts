// Shared Invite Codes - für Serverless Umgebungen
export const SHARED_INVITES: any[] = [
  {
    id: 'invite_1',
    code: 'DASHBOARD2024',
    maxUses: 10,
    usedCount: 0,
    isActive: true,
    expiresAt: null,
    createdAt: '2026-03-30T18:00:00Z'
  },
  {
    id: 'invite_2',
    code: 'ADMIN2024',
    maxUses: 5,
    usedCount: 0,
    isActive: true,
    expiresAt: null,
    createdAt: '2026-03-30T18:00:00Z'
  }
];