export interface StockData {
  ticker: string;
  name: string;
  currency: string;
  currentPrice: number | null;
  previousClose: number | null;
  change: number | null;
  changePercent: number | null;
  marketCap: number | null;
  kgv: number | null;
  forwardKgv: number | null;
  dividendenRendite: number;
  forwardDividendAmount: number | null;
  trailingDividendRate: number | null;
  trailingDividendYield: number | null;
  payoutRatio: number | null;
  fiveYearAvgDividendYield: number | null;
  exDividendDate: string | null;
  earningsDate: string | null;
  fiftyTwoWeekHigh: number | null;
  fiftyTwoWeekLow: number | null;
  beta: number | null;
  freeCashflow: number | null;
  totalDebt: number | null;
  totalRevenue: number | null;
  revenueGrowth: number | null;
  profitMargins: number | null;
  verschuldungsgrad: number | null;
  returnOnEquity: number | null;
  targetMeanPrice: number | null;
  recommendationKey: string | null;
  rsi: number;
  trend: string;
  ma50: number | null;
  ma200: number | null;
  support: number | null;
  resistance: number | null;
  chartData: ChartPoint[];
}

export interface ChartPoint {
  date: string;
  close: number | null;
  open: number | null;
  high: number | null;
  low: number | null;
  volume: number | null;
}