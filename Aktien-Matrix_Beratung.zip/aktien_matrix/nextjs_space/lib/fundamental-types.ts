// Erweiterte Fundamental-Typen für die Detailanalyse

export interface BewertungsKennzahlen {
  pegRatio: number | null;        // PEG Ratio - unter 1 = günstig
  evEbitda: number | null;        // EV/EBITDA - besser als KGV bei Schulden
  priceToBook: number | null;     // Kurs-Buchwert - unter 1 = unter Substanz
  priceToSales: number | null;    // Kurs-Umsatz - wichtig für Wachstumsaktien
  evToSales: number | null;       // EV/Umsatz
  epsTrailing: number | null;     // EPS (Trailing)
  epsForward: number | null;      // EPS Forward (Prognose)
  enterpriseValue: number | null; // Enterprise Value
}

export interface ProfitabilitaetsKennzahlen {
  ebitdaMargin: number | null;     // EBITDA-Marge
  grossMargin: number | null;      // Bruttomarge
  operatingMargin: number | null; // Operating Margin
  earningsGrowth: number | null;   // Gewinnwachstum
}

export interface BilanzKennzahlen {
  currentRatio: number | null;     // Current Ratio (>2 = sehr gut)
  quickRatio: number | null;       // Quick Ratio (strengerer Test)
  netCash: number | null;          // Netto-Cash (Cash - Schulden)
  shortRatio: number | null;       // Short Ratio (Tage bis Leerverkauf)
  perf52W: number | null;          // 52W Performance
}

export interface FundamentalData {
  bewertung: BewertungsKennzahlen;
  profitabilitaet: ProfitabilitaetsKennzahlen;
  bilanz: BilanzKennzahlen;
}

// News Typen
export interface NewsItem {
  id: string;
  title: string;
  description?: string;
  source: string;
  publishedAt: Date;
  url: string;
  ticker?: string;
  imageUrl?: string;
}

// Farb-Status für Kennzahlen
export type KennzahlStatus = 'gut' | 'mittel' | 'schlecht' | 'neutral';

export interface KennzahlBewertung {
  value: number | null;
  formatted: string;
  status: KennzahlStatus;
  label: string;
  hilfetext: string;
  einheit?: string;
}

// Bewertung für einen kompletten Tab
export interface TabBewertung {
  gesamtScore: number;      // Tatsächliche Punkte (z.B. 13 von 30)
  maxPunkte: number;        // Maximale Punkte
  durchschnittsPunkte: number; // Durchschnitt pro Kennzahl 0-2.0
  totalKennzahlen: number;  // Anzahl bewertbarer Kennzahlen
  gut: number;
  mittel: number;
  schlecht: number;
  rating: 'GUT' | 'MITTEL' | 'SCHLECHT';
  farbe: string;
  empfehlung: string;
  score: number;            // Legacy - verwende durchschnittsPunkte
}

// Gesamtbewertung der Aktie
export interface GesamtBewertung {
  gesamtScore: number;      // Tatsächliche Punkte über alle Tabs
  maxPunkte: number;        // Maximale Punkte über alle Tabs
  durchschnittsPunkte: number; // Durchschnitt pro Kennzahl 0-2.0
  totalKennzahlen: number;  // Anzahl aller bewertbarer Kennzahlen
  gut: number;
  mittel: number;
  schlecht: number;
  rating: 'GUT' | 'MITTEL' | 'SCHLECHT';
  farbe: string;
  empfehlung: 'KAUFEN' | 'HALTEN' | 'VERKAUFEN';
  score: number;            // Gewichteter Gesamtscore
}
