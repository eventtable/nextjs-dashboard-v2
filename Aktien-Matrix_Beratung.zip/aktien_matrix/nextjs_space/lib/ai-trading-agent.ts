// AI Trading Agent - Machine Learning basierte Trading-Entscheidungen
import { HistoricalData } from './yahoo-finance';

// Trading-Entscheidung
export type TradingDecision = 'buy' | 'sell' | 'hold' | 'short';

// Features für ML
export interface TradingFeatures {
  // Technische Indikatoren
  rsi: number;                    // Relative Strength Index
  macd: number;                   // MACD Wert
  macdSignal: number;            // MACD Signal Line
  ema20: number;                 // 20-Tage EMA
  ema50: number;                 // 50-Tage EMA
  sma20: number;                 // 20-Tage SMA
  sma50: number;                 // 50-Tage SMA
  bollingerUpper: number;        // Bollinger Bands Upper
  bollingerLower: number;        // Bollinger Bands Lower
  atr: number;                   // Average True Range (Volatilität)
  volumeSma: number;             // Volume Durchschnitt
  priceChange1d: number;         // 1-Tage Preisänderung %
  priceChange5d: number;         // 5-Tage Preisänderung %
  priceChange20d: number;        // 20-Tage Preisänderung %
  volatility20d: number;          // 20-Tage Volatilität
  
  // Trend-Features
  trendDirection: number;          // +1 = aufwärts, -1 = abwärts, 0 = seitwärts
  momentum: number;              // Preismomentum
  supportDistance: number;       // % Distanz zum Support
  resistanceDistance: number;     // % Distanz zum Resistance
}

// Trainings-Daten
export interface TrainingSample {
  features: TradingFeatures;
  decision: TradingDecision;
  reward: number;                // Finanzielle Belohnung für diese Entscheidung
}

// Einfacher Neural Network Klasse
export class NeuralNetwork {
  private weights: number[][][];
  private biases: number[][];
  private learningRate: number = 0.01;
  private layers: number[];

  constructor(layerSizes: number[]) {
    this.layers = layerSizes;
    this.weights = [];
    this.biases = [];
    
    // Initialisiere Gewichte und Biases
    for (let i = 0; i < layerSizes.length - 1; i++) {
      const w: number[][] = [];
      for (let j = 0; j < layerSizes[i + 1]; j++) {
        w.push(Array(layerSizes[i]).fill(0).map(() => Math.random() * 0.1 - 0.05));
      }
      this.weights.push(w);
      this.biases.push(Array(layerSizes[i + 1]).fill(0).map(() => Math.random() * 0.1 - 0.05));
    }
  }

  // Sigmoid Aktivierungsfunktion
  private sigmoid(x: number): number {
    return 1 / (1 + Math.exp(-x));
  }

  // ReLU Aktivierungsfunktion
  private relu(x: number): number {
    return Math.max(0, x);
  }

  // Forward Propagation
  predict(inputs: number[]): number[] {
    let current = inputs;
    
    for (let i = 0; i < this.weights.length; i++) {
      const next: number[] = [];
      for (let j = 0; j < this.weights[i].length; j++) {
        let sum = this.biases[i][j];
        for (let k = 0; k < current.length; k++) {
          sum += current[k] * this.weights[i][j][k];
        }
        // ReLU für Hidden, Sigmoid für Output
        next.push(i === this.weights.length - 1 ? this.sigmoid(sum) : this.relu(sum));
      }
      current = next;
    }
    
    return current;
  }

  // Training mit einem Sample
  train(inputs: number[], targets: number[], epochs: number = 1): void {
    for (let e = 0; e < epochs; e++) {
      // Forward pass (speichere Zwischenwerte)
      const activations: number[][] = [inputs];
      let current = inputs;
      
      for (let i = 0; i < this.weights.length; i++) {
        const next: number[] = [];
        for (let j = 0; j < this.weights[i].length; j++) {
          let sum = this.biases[i][j];
          for (let k = 0; k < current.length; k++) {
            sum += current[k] * this.weights[i][j][k];
          }
          next.push(i === this.weights.length - 1 ? this.sigmoid(sum) : this.relu(sum));
        }
        activations.push(next);
        current = next;
      }

      // Backpropagation (vereinfacht)
      let errors: number[] = [];
      for (let i = 0; i < targets.length; i++) {
        errors.push(targets[i] - current[i]);
      }

      // Update letzte Schicht (vereinfachtes Gradient Descent)
      const lastLayer = this.weights.length - 1;
      for (let j = 0; j < this.weights[lastLayer].length; j++) {
        for (let k = 0; k < activations[lastLayer].length; k++) {
          this.weights[lastLayer][j][k] += this.learningRate * errors[j] * activations[lastLayer][k];
        }
        this.biases[lastLayer][j] += this.learningRate * errors[j];
      }
    }
  }

  // Speichern des Modells
  serialize(): string {
    return JSON.stringify({ weights: this.weights, biases: this.biases });
  }

  // Laden des Modells
  deserialize(data: string): void {
    const parsed = JSON.parse(data);
    this.weights = parsed.weights;
    this.biases = parsed.biases;
  }
}

// AI Trading Agent Hauptklasse
export class AITradingAgent {
  private model: NeuralNetwork;
  private featureSize: number = 16; // Anzahl der Features
  private decisionSize: number = 4; // buy, sell, hold, short
  private trainingData: TrainingSample[] = [];

  constructor() {
    // Netzwerk: 16 Inputs -> 32 Hidden -> 16 Hidden -> 4 Outputs
    this.model = new NeuralNetwork([this.featureSize, 32, 16, this.decisionSize]);
    
    // Lade gespeichertes Modell falls vorhanden
    if (typeof window !== 'undefined') {
      const saved = localStorage.getItem('ai_trading_model');
      if (saved) {
        try {
          this.model.deserialize(saved);
          console.log('AI Model geladen');
        } catch (e) {
          console.log('Konnte kein Model laden, starte neu');
        }
      }
    }
  }

  // Berechne technische Indikatoren
  calculateFeatures(data: HistoricalData[], window: number = 20): TradingFeatures | null {
    if (data.length < window + 10) return null;

    const prices = data.map(d => d.close);
    const volumes = data.map(d => d.volume);
    
    // Aktueller Index
    const current = prices[0];
    const currentVol = volumes[0];
    
    // RSI Berechnung (14 Tage)
    const rsi = this.calculateRSI(prices, 14);
    
    // MACD Berechnung
    const ema12 = this.calculateEMA(prices, 12);
    const ema26 = this.calculateEMA(prices, 26);
    const macd = ema12 - ema26;
    const macdSignal = this.calculateEMA([macd, ...prices.slice(0, 8).map(() => macd)], 9);
    
    // EMAs
    const ema20 = this.calculateEMA(prices, 20);
    const ema50 = this.calculateEMA(prices, 50);
    
    // SMAs
    const sma20 = this.calculateSMA(prices, 20);
    const sma50 = this.calculateSMA(prices, 50);
    
    // Bollinger Bands
    const bb = this.calculateBollingerBands(prices, 20);
    
    // ATR (Average True Range)
    const atr = this.calculateATR(data, 14);
    
    // Volume SMA
    const volumeSma = this.calculateSMA(volumes, 20);
    
    // Preisänderungen
    const priceChange1d = ((prices[0] - prices[1]) / prices[1]) * 100;
    const priceChange5d = ((prices[0] - prices[4]) / prices[4]) * 100;
    const priceChange20d = ((prices[0] - prices[19]) / prices[19]) * 100;
    
    // Volatilität (Standardabweichung der Returns)
    const returns: number[] = [];
    for (let i = 0; i < 20; i++) {
      returns.push((prices[i] - prices[i + 1]) / prices[i + 1]);
    }
    const volatility20d = Math.sqrt(returns.reduce((sum, r) => sum + r * r, 0) / returns.length) * 100;
    
    // Trend Direction
    const trendDirection = ema20 > ema50 ? 1 : ema20 < ema50 ? -1 : 0;
    
    // Momentum
    const momentum = current - sma20;
    
    // Support/Resistance (vereinfacht)
    const supportDistance = ((current - bb.lower) / current) * 100;
    const resistanceDistance = ((bb.upper - current) / current) * 100;

    return {
      rsi,
      macd,
      macdSignal,
      ema20,
      ema50,
      sma20,
      sma50,
      bollingerUpper: bb.upper,
      bollingerLower: bb.lower,
      atr,
      volumeSma,
      priceChange1d,
      priceChange5d,
      priceChange20d,
      volatility20d,
      trendDirection,
      momentum: momentum / current * 100, // als Prozentsatz
      supportDistance,
      resistanceDistance
    };
  }

  // RSI Berechnung
  private calculateRSI(prices: number[], period: number): number {
    let gains = 0;
    let losses = 0;
    
    for (let i = 0; i < period; i++) {
      const change = prices[i] - prices[i + 1];
      if (change > 0) gains += change;
      else losses -= change;
    }
    
    const avgGain = gains / period;
    const avgLoss = losses / period;
    
    if (avgLoss === 0) return 100;
    const rs = avgGain / avgLoss;
    return 100 - (100 / (1 + rs));
  }

  // EMA Berechnung
  private calculateEMA(prices: number[], period: number): number {
    const multiplier = 2 / (period + 1);
    let ema = prices[prices.length - 1]; // Start mit letztem Wert
    
    for (let i = prices.length - 2; i >= 0; i--) {
      ema = (prices[i] - ema) * multiplier + ema;
    }
    
    return ema;
  }

  // SMA Berechnung
  private calculateSMA(data: number[], period: number): number {
    const sum = data.slice(0, period).reduce((a, b) => a + b, 0);
    return sum / period;
  }

  // Bollinger Bands
  private calculateBollingerBands(prices: number[], period: number): { upper: number; middle: number; lower: number } {
    const middle = this.calculateSMA(prices, period);
    const squaredDiffs = prices.slice(0, period).map(p => Math.pow(p - middle, 2));
    const stdDev = Math.sqrt(squaredDiffs.reduce((a, b) => a + b, 0) / period);
    
    return {
      upper: middle + (stdDev * 2),
      middle,
      lower: middle - (stdDev * 2)
    };
  }

  // ATR Berechnung
  private calculateATR(data: HistoricalData[], period: number): number {
    const trs: number[] = [];
    
    for (let i = 0; i < period && i < data.length - 1; i++) {
      const current = data[i];
      const prev = data[i + 1];
      
      const tr1 = current.high - current.low;
      const tr2 = Math.abs(current.high - prev.close);
      const tr3 = Math.abs(current.low - prev.close);
      
      trs.push(Math.max(tr1, tr2, tr3));
    }
    
    return trs.reduce((a, b) => a + b, 0) / trs.length;
  }

  // Features normalisieren für Neural Network
  normalizeFeatures(features: TradingFeatures): number[] {
    return [
      features.rsi / 100,                    // 0-1
      features.macd / 10,                    // approx -10 to 10
      features.macdSignal / 10,
      (features.ema20 - features.sma20) / features.sma20 * 10, // relative diff
      (features.ema50 - features.sma50) / features.sma50 * 10,
      (features.bollingerUpper - features.sma20) / features.sma20, // % distance
      (features.bollingerLower - features.sma20) / features.sma20,
      features.atr / features.sma20 * 100,  // ATR as % of price
      features.volumeSma > 0 ? features.volumeSma / 1000000 : 0, // in millions
      features.priceChange1d / 100,           // as decimal
      features.priceChange5d / 100,
      features.priceChange20d / 100,
      features.volatility20d / 100,
      features.trendDirection === 1 ? 1 : features.trendDirection === -1 ? 0 : 0.5,
      features.momentum / 100,
      features.supportDistance / 100,
      features.resistanceDistance / 100
    ];
  }

  // Trading Entscheidung treffen
  predict(data: HistoricalData[]): { decision: TradingDecision; confidence: number } {
    const features = this.calculateFeatures(data);
    if (!features) return { decision: 'hold', confidence: 0 };

    const normalized = this.normalizeFeatures(features);
    const output = this.model.predict(normalized);

    // Output: [buy, sell, hold, short]
    const decisions: TradingDecision[] = ['buy', 'sell', 'hold', 'short'];
    const maxIndex = output.indexOf(Math.max(...output));
    const confidence = output[maxIndex];

    return { decision: decisions[maxIndex], confidence };
  }

  // Training auf historischen Daten
  train(historicalData: HistoricalData[]): void {
    console.log(`Training auf ${historicalData.length} Tagen...`);
    
    const trainingSamples: { features: number[]; target: number[] }[] = [];
    
    // Sliding window über historische Daten
    for (let i = historicalData.length - 50; i >= 20; i--) {
      const window = historicalData.slice(i, i + 20);
      const features = this.calculateFeatures(window);
      
      if (!features) continue;

      // Zukünftige Performance als Label
      const futurePrice = historicalData[i - 1]?.close || historicalData[0].close;
      const currentPrice = window[0].close;
      const futureReturn = (futurePrice - currentPrice) / currentPrice;

      // Erstelle Target-Vector basierend auf zukünftiger Performance
      let target: number[];
      if (futureReturn > 0.02) target = [1, 0, 0, 0];      // buy
      else if (futureReturn < -0.02) target = [0, 0, 0, 1]; // short
      else if (futureReturn < -0.01) target = [0, 1, 0, 0]; // sell
      else target = [0, 0, 1, 0];                              // hold

      trainingSamples.push({
        features: this.normalizeFeatures(features),
        target
      });
    }

    // Trainiere das Modell
    for (const sample of trainingSamples) {
      this.model.train(sample.features, sample.target, 1);
    }

    // Speichere Modell
    if (typeof window !== 'undefined') {
      localStorage.setItem('ai_trading_model', this.model.serialize());
    }

    console.log(`Training abgeschlossen. ${trainingSamples.length} Samples verarbeitet.`);
  }

  // Modell speichern
  saveModel(): void {
    if (typeof window !== 'undefined') {
      localStorage.setItem('ai_trading_model', this.model.serialize());
      localStorage.setItem('ai_trading_trained', Date.now().toString());
    }
  }

  // Modell laden
  loadModel(): boolean {
    if (typeof window !== 'undefined') {
      const saved = localStorage.getItem('ai_trading_model');
      if (saved) {
        this.model.deserialize(saved);
        return true;
      }
    }
    return false;
  }

  // Ist das Modell trainiert?
  isTrained(): boolean {
    if (typeof window !== 'undefined') {
      return localStorage.getItem('ai_trading_trained') !== null;
    }
    return false;
  }
}

// Singleton-Instanz
let aiTradingAgent: AITradingAgent | null = null;

export function getAITradingAgent(): AITradingAgent {
  if (!aiTradingAgent) {
    aiTradingAgent = new AITradingAgent();
  }
  return aiTradingAgent;
}
