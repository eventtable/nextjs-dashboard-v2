import { getServerSession } from 'next-auth';
import { NextResponse } from 'next/server';

/**
 * Prüft ob der aktuelle Request von einem eingeloggten Admin kommt.
 * Gibt die Session zurück wenn ja, oder eine 401-Response wenn nein.
 */
export async function requireAdmin() {
  try {
    const { authOptions } = await import('@/lib/auth');
    const session: any = await getServerSession(authOptions as any);

    if (!session?.user?.email) {
      return { authorized: false as const, response: NextResponse.json({ error: 'Nicht angemeldet' }, { status: 401 }) };
    }

    if (!session.user.isAdmin) {
      return { authorized: false as const, response: NextResponse.json({ error: 'Keine Admin-Berechtigung' }, { status: 403 }) };
    }

    return { authorized: true as const, session };
  } catch (error) {
    console.error('Auth check failed:', error);
    return { authorized: false as const, response: NextResponse.json({ error: 'Auth-Fehler' }, { status: 500 }) };
  }
}

/**
 * Prüft ob der aktuelle Request von einem eingeloggten Benutzer kommt.
 */
export async function requireAuth() {
  try {
    const { authOptions } = await import('@/lib/auth');
    const session: any = await getServerSession(authOptions as any);

    if (!session?.user?.email) {
      return { authorized: false as const, response: NextResponse.json({ error: 'Nicht angemeldet' }, { status: 401 }) };
    }

    return { authorized: true as const, session };
  } catch (error) {
    console.error('Auth check failed:', error);
    return { authorized: false as const, response: NextResponse.json({ error: 'Auth-Fehler' }, { status: 500 }) };
  }
}
