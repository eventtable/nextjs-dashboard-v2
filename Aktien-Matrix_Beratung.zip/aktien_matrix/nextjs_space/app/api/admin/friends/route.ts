import { NextResponse } from 'next/server';
import { requireAdmin } from '@/lib/auth-guard';

// In-memory cache für Runtime-Persistenz
let friendsCache: any = null;

// Get friends data from environment variable oder cache
const getFriendsData = () => {
  if (friendsCache) {
    return friendsCache;
  }
  
  try {
    const envData = process.env.FRIENDS_DATA;
    if (envData) {
      friendsCache = JSON.parse(envData);
      return friendsCache;
    }
  } catch (e) {
    console.error('Error parsing FRIENDS_DATA:', e);
  }
  
  return { 
    friends: [], 
    inviteCodes: [
      { code: 'FRIEND-001-ALPHA', usedBy: null, createdAt: '2024-03-31', permissions: { canViewDepot: true, canViewTrading: true, canViewML: true }},
      { code: 'FRIEND-002-BETA', usedBy: null, createdAt: '2024-03-31', permissions: { canViewDepot: true, canViewTrading: true, canViewML: true }},
      { code: 'FRIEND-003-GAMMA', usedBy: null, createdAt: '2024-03-31', permissions: { canViewDepot: true, canViewTrading: true, canViewML: true }},
      { code: 'FRIEND-004-DELTA', usedBy: null, createdAt: '2024-03-31', permissions: { canViewDepot: true, canViewTrading: true, canViewML: true }},
      { code: 'FRIEND-005-ECHO', usedBy: null, createdAt: '2024-03-31', permissions: { canViewDepot: true, canViewTrading: true, canViewML: true }},
      { code: 'FRIEND-006-FOXTROT', usedBy: null, createdAt: '2024-03-31', permissions: { canViewDepot: true, canViewTrading: true, canViewML: true }},
      { code: 'FRIEND-007-GOLF', usedBy: null, createdAt: '2024-03-31', permissions: { canViewDepot: true, canViewTrading: true, canViewML: true }},
      { code: 'FRIEND-008-HOTEL', usedBy: null, createdAt: '2024-03-31', permissions: { canViewDepot: true, canViewTrading: true, canViewML: true }},
      { code: 'FRIEND-009-INDIA', usedBy: null, createdAt: '2024-03-31', permissions: { canViewDepot: true, canViewTrading: true, canViewML: true }},
      { code: 'FRIEND-010-JULIET', usedBy: null, createdAt: '2024-03-31', permissions: { canViewDepot: true, canViewTrading: true, canViewML: true }},
      { code: 'FRIEND-011-KILO', usedBy: null, createdAt: '2024-03-31', permissions: { canViewDepot: true, canViewTrading: true, canViewML: true }},
      { code: 'FRIEND-012-LIMA', usedBy: null, createdAt: '2024-03-31', permissions: { canViewDepot: true, canViewTrading: true, canViewML: true }},
      { code: 'FRIEND-013-MIKE', usedBy: null, createdAt: '2024-03-31', permissions: { canViewDepot: true, canViewTrading: true, canViewML: true }},
      { code: 'FRIEND-014-NOVEMBER', usedBy: null, createdAt: '2024-03-31', permissions: { canViewDepot: true, canViewTrading: true, canViewML: true }},
      { code: 'FRIEND-015-OSCAR', usedBy: null, createdAt: '2024-03-31', permissions: { canViewDepot: true, canViewTrading: true, canViewML: true }},
      { code: 'FRIEND-016-PAPA', usedBy: null, createdAt: '2024-03-31', permissions: { canViewDepot: true, canViewTrading: true, canViewML: true }},
      { code: 'FRIEND-017-QUEBEC', usedBy: null, createdAt: '2024-03-31', permissions: { canViewDepot: true, canViewTrading: true, canViewML: true }},
      { code: 'FRIEND-018-ROMEO', usedBy: null, createdAt: '2024-03-31', permissions: { canViewDepot: true, canViewTrading: true, canViewML: true }},
      { code: 'FRIEND-019-SIERRA', usedBy: null, createdAt: '2024-03-31', permissions: { canViewDepot: true, canViewTrading: true, canViewML: true }},
      { code: 'FRIEND-020-TANGO', usedBy: null, createdAt: '2024-03-31', permissions: { canViewDepot: true, canViewTrading: true, canViewML: true }},
      { code: 'FRIEND-021-UNIFORM', usedBy: null, createdAt: '2024-03-31', permissions: { canViewDepot: true, canViewTrading: true, canViewML: true }},
      { code: 'FRIEND-022-VICTOR', usedBy: null, createdAt: '2024-03-31', permissions: { canViewDepot: true, canViewTrading: true, canViewML: true }},
      { code: 'FRIEND-023-WHISKEY', usedBy: null, createdAt: '2024-03-31', permissions: { canViewDepot: true, canViewTrading: true, canViewML: true }},
      { code: 'FRIEND-024-XRAY', usedBy: null, createdAt: '2024-03-31', permissions: { canViewDepot: true, canViewTrading: true, canViewML: true }},
      { code: 'FRIEND-025-YANKEE', usedBy: null, createdAt: '2024-03-31', permissions: { canViewDepot: true, canViewTrading: true, canViewML: true }},
      { code: 'FRIEND-026-ZULU', usedBy: null, createdAt: '2024-03-31', permissions: { canViewDepot: true, canViewTrading: true, canViewML: true }},
      { code: 'FRIEND-027-APOLLO', usedBy: null, createdAt: '2024-03-31', permissions: { canViewDepot: true, canViewTrading: true, canViewML: true }},
      { code: 'FRIEND-028-ARTEMIS', usedBy: null, createdAt: '2024-03-31', permissions: { canViewDepot: true, canViewTrading: true, canViewML: true }},
      { code: 'FRIEND-029-ATHENA', usedBy: null, createdAt: '2024-03-31', permissions: { canViewDepot: true, canViewTrading: true, canViewML: true }},
      { code: 'FRIEND-030-ZEUS', usedBy: null, createdAt: '2024-03-31', permissions: { canViewDepot: true, canViewTrading: true, canViewML: true }},
      { code: 'FRIEND-031-HERMES', usedBy: null, createdAt: '2024-03-31', permissions: { canViewDepot: true, canViewTrading: true, canViewML: true }},
      { code: 'FRIEND-032-POSEIDON', usedBy: null, createdAt: '2024-03-31', permissions: { canViewDepot: true, canViewTrading: true, canViewML: true }},
      { code: 'FRIEND-033-HADES', usedBy: null, createdAt: '2024-03-31', permissions: { canViewDepot: true, canViewTrading: true, canViewML: true }},
      { code: 'FRIEND-034-ARES', usedBy: null, createdAt: '2024-03-31', permissions: { canViewDepot: true, canViewTrading: true, canViewML: true }},
      { code: 'FRIEND-035-HERA', usedBy: null, createdAt: '2024-03-31', permissions: { canViewDepot: true, canViewTrading: true, canViewML: true }},
      { code: 'FRIEND-036-DEMETER', usedBy: null, createdAt: '2024-03-31', permissions: { canViewDepot: true, canViewTrading: true, canViewML: true }},
      { code: 'FRIEND-037-PERSEPHONE', usedBy: null, createdAt: '2024-03-31', permissions: { canViewDepot: true, canViewTrading: true, canViewML: true }},
      { code: 'FRIEND-038-DIONYSUS', usedBy: null, createdAt: '2024-03-31', permissions: { canViewDepot: true, canViewTrading: true, canViewML: true }},
      { code: 'FRIEND-039-HEPHAESTUS', usedBy: null, createdAt: '2024-03-31', permissions: { canViewDepot: true, canViewTrading: true, canViewML: true }},
      { code: 'FRIEND-040-HESTIA', usedBy: null, createdAt: '2024-03-31', permissions: { canViewDepot: true, canViewTrading: true, canViewML: true }},
      { code: 'FRIEND-041-NYX', usedBy: null, createdAt: '2024-03-31', permissions: { canViewDepot: true, canViewTrading: true, canViewML: true }},
      { code: 'FRIEND-042-EREBUS', usedBy: null, createdAt: '2024-03-31', permissions: { canViewDepot: true, canViewTrading: true, canViewML: true }},
      { code: 'FRIEND-043-TARTARUS', usedBy: null, createdAt: '2024-03-31', permissions: { canViewDepot: true, canViewTrading: true, canViewML: true }},
      { code: 'FRIEND-044-GAIA', usedBy: null, createdAt: '2024-03-31', permissions: { canViewDepot: true, canViewTrading: true, canViewML: true }},
      { code: 'FRIEND-045-URANUS', usedBy: null, createdAt: '2024-03-31', permissions: { canViewDepot: true, canViewTrading: true, canViewML: true }},
      { code: 'FRIEND-046-CHRONOS', usedBy: null, createdAt: '2024-03-31', permissions: { canViewDepot: true, canViewTrading: true, canViewML: true }},
      { code: 'FRIEND-047-RHEA', usedBy: null, createdAt: '2024-03-31', permissions: { canViewDepot: true, canViewTrading: true, canViewML: true }},
      { code: 'FRIEND-048-OCEANUS', usedBy: null, createdAt: '2024-03-31', permissions: { canViewDepot: true, canViewTrading: true, canViewML: true }},
      { code: 'FRIEND-049-TETHYS', usedBy: null, createdAt: '2024-03-31', permissions: { canViewDepot: true, canViewTrading: true, canViewML: true }},
      { code: 'FRIEND-050-HYPERION', usedBy: null, createdAt: '2024-03-31', permissions: { canViewDepot: true, canViewTrading: true, canViewML: true }}
    ]
  };
};

export async function GET() {
  const auth = await requireAdmin();
  if (!auth.authorized) return auth.response;

  try {
    const data = getFriendsData();
    const friends = (data.friends || []).map((friend: any) => ({
      id: friend.id,
      email: friend.email,
      name: friend.name,
      role: 'friend',
      isActive: friend.isActive ?? true,
      lastLoginAt: null,
      createdAt: friend.createdAt || new Date().toISOString(),
      isOnline: false,
      permissions: friend.permissions || {
        canViewDepot: true,
        canViewTrading: true,
        canViewML: false
      }
    }));
    
    return NextResponse.json({
      friends,
      inviteCodes: data.inviteCodes || []
    });
  } catch (error) {
    return NextResponse.json({ error: 'Server error' }, { status: 500 });
  }
}

export async function POST(request: Request) {
  const auth = await requireAdmin();
  if (!auth.authorized) return auth.response;

  try {
    const body = await request.json();
    const { action, ...data } = body;
    const friendsData = getFriendsData();
    
    if (action === 'create_invite') {
      const code = `FRIEND-${Date.now()}-${Math.random().toString(36).substr(2, 6).toUpperCase()}`;
      const newCode = {
        code,
        usedBy: null,
        createdAt: new Date().toISOString().split('T')[0],
        expiresAt: null,
        permissions: data.permissions || {
          canViewDepot: true,
          canViewTrading: true,
          canViewML: false,
          canEdit: false
        }
      };
      friendsData.inviteCodes = [...(friendsData.inviteCodes || []), newCode];
      friendsCache = friendsData;
      return NextResponse.json({ success: true, code: newCode });
    }
    
    if (action === 'add_friend') {
      const newFriend = {
        id: `friend_${Date.now()}`,
        email: data.email.toLowerCase(),
        name: data.name,
        password: data.password,
        inviteCode: 'DIRECT-ADD',
        createdAt: new Date().toISOString().split('T')[0],
        isActive: true,
        permissions: data.permissions || {
          canViewDepot: true,
          canViewTrading: true,
          canViewML: false,
          canEdit: false
        }
      };
      friendsData.friends = [...(friendsData.friends || []), newFriend];
      friendsCache = friendsData;
      return NextResponse.json({ success: true, friend: newFriend });
    }
    
    if (action === 'toggle_status') {
      const friendIndex = friendsData.friends?.findIndex((f: any) => f.id === data.id);
      if (friendIndex >= 0) {
        friendsData.friends[friendIndex].isActive = !friendsData.friends[friendIndex].isActive;
        friendsCache = friendsData;
        return NextResponse.json({ success: true });
      }
      return NextResponse.json({ error: 'Friend not found' }, { status: 404 });
    }
    
    return NextResponse.json({ error: 'Invalid action' }, { status: 400 });
  } catch (error) {
    return NextResponse.json({ error: 'Server error' }, { status: 500 });
  }
}

export async function DELETE(request: Request) {
  const auth = await requireAdmin();
  if (!auth.authorized) return auth.response;

  try {
    const { searchParams } = new URL(request.url);
    const friendId = searchParams.get('id');
    const code = searchParams.get('code');
    const friendsData = getFriendsData();
    
    if (friendId) {
      friendsData.friends = friendsData.friends?.filter((f: any) => f.id !== friendId) || [];
      friendsCache = friendsData;
      return NextResponse.json({ success: true });
    }
    if (code) {
      friendsData.inviteCodes = friendsData.inviteCodes?.filter((c: any) => c.code !== code) || [];
      friendsCache = friendsData;
      return NextResponse.json({ success: true });
    }
    return NextResponse.json({ error: 'Missing parameters' }, { status: 400 });
  } catch (error) {
    return NextResponse.json({ error: 'Server error' }, { status: 500 });
  }
}
