import { NextResponse } from 'next/server';
import { SHARED_INVITES } from '@/lib/shared-invites';
import { requireAdmin } from '@/lib/auth-guard';

export async function GET() {
  const auth = await requireAdmin();
  if (!auth.authorized) return auth.response;

  return NextResponse.json(SHARED_INVITES);
}

export async function POST(request: Request) {
  const auth = await requireAdmin();
  if (!auth.authorized) return auth.response;

  const { maxUses } = await request.json();
  const newInvite = {
    id: 'invite_' + Date.now(),
    code: 'INVITE' + Math.random().toString(36).substring(2, 8).toUpperCase(),
    maxUses: maxUses === null ? null : (maxUses || 5),
    usedCount: 0,
    isActive: true,
    expiresAt: null,
    createdAt: new Date().toISOString()
  };
  SHARED_INVITES.unshift(newInvite);
  return NextResponse.json(newInvite);
}

export async function DELETE(request: Request) {
  const auth = await requireAdmin();
  if (!auth.authorized) return auth.response;

  const { id } = await request.json();
  const invite = SHARED_INVITES.find(i => i.id === id);
  if (invite) {
    invite.isActive = false;
  }
  return NextResponse.json({ success: true });
}
