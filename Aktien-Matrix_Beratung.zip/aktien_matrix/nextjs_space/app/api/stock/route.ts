import { NextRequest, NextResponse } from 'next/server';
import { calculateRSI } from '@/lib/stock-utils';

export const dynamic = 'force-dynamic';

const UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36';

// Cache crumb + cookies for reuse (they last ~1 hour)
let cachedCrumb: string | null = null;
let cachedCookies: string = '';
let crumbTimestamp: number = 0;
const CRUMB_TTL = 25 * 60 * 1000; // 25 minutes

async function getCrumb(): Promise<{ crumb: string; cookies: string } | null> {
  const now = Date.now();
  if (cachedCrumb && cachedCookies && (now - crumbTimestamp) < CRUMB_TTL) {
    return { crumb: cachedCrumb, cookies: cachedCookies };
  }
  try {
    // Step 1: Get consent cookie from fc.yahoo.com (follow redirects)
    const initRes = await fetch('https://fc.yahoo.com/', {
      headers: { 'User-Agent': UA },
      redirect: 'manual',
    });
    // Collect Set-Cookie headers
    const setCookieHeaders = initRes.headers.getSetCookie?.() ?? [];
    let cookieStr = setCookieHeaders
      .map((c: string) => c.split(';')[0])
      .filter(Boolean)
      .join('; ');

    // If no cookies from redirect, try following
    if (!cookieStr) {
      const initRes2 = await fetch('https://fc.yahoo.com/', {
        headers: { 'User-Agent': UA },
      });
      const setCookieHeaders2 = initRes2.headers.getSetCookie?.() ?? [];
      cookieStr = setCookieHeaders2
        .map((c: string) => c.split(';')[0])
        .filter(Boolean)
        .join('; ');
    }

    if (!cookieStr) {
      console.log('[YF] No cookies received from fc.yahoo.com');
      return null;
    }

    // Step 2: Get crumb using cookies
    const crumbRes = await fetch('https://query2.finance.yahoo.com/v1/test/getcrumb', {
      headers: {
        'User-Agent': UA,
        'Cookie': cookieStr,
      },
    });

    // Collect additional cookies from crumb response
    const crumbSetCookies = crumbRes.headers.getSetCookie?.() ?? [];
    if (crumbSetCookies.length > 0) {
      const extraCookies = crumbSetCookies
        .map((c: string) => c.split(';')[0])
        .filter(Boolean)
        .join('; ');
      cookieStr = cookieStr + '; ' + extraCookies;
    }

    const crumb = (await crumbRes.text())?.trim?.() ?? '';
    if (crumb && !crumb.includes('Unauthorized') && !crumb.includes('{') && !crumb.includes('<')) {
      cachedCrumb = crumb;
      cachedCookies = cookieStr;
      crumbTimestamp = now;
      console.log('[YF] Crumb acquired successfully');
      return { crumb, cookies: cookieStr };
    }
    console.log('[YF] Invalid crumb response:', crumb.substring(0, 100));
    return null;
  } catch (err: any) {
    console.log('[YF] getCrumb error:', err?.message);
    return null;
  }
}

async function fetchQuoteSummaryOnce(ticker: string, auth: { crumb: string; cookies: string }): Promise<Record<string, any> | null> {
  const modules = 'summaryDetail,financialData,defaultKeyStatistics,calendarEvents';
  const encodedCrumb = encodeURIComponent(auth.crumb);
  const encodedTicker = encodeURIComponent(ticker);
  const url = `https://query2.finance.yahoo.com/v10/finance/quoteSummary/${encodedTicker}?modules=${modules}&crumb=${encodedCrumb}`;
  const res = await fetch(url, {
    headers: {
      'User-Agent': UA,
      'Cookie': auth.cookies,
    },
  });
  const json = await res.json();
  const summaryResult = json?.quoteSummary?.result?.[0];
  if (!summaryResult) {
    const errCode = json?.finance?.error?.code ?? json?.quoteSummary?.error?.code;
    console.log('[YF] quoteSummary failed for', ticker, '- error:', errCode ?? 'no result');
    if (errCode === 'Unauthorized' || errCode === 'Invalid Crumb') {
      cachedCrumb = null;
      cachedCookies = '';
      crumbTimestamp = 0;
    }
    return null;
  }
  return summaryResult;
}

async function fetchQuoteSummary(ticker: string): Promise<Record<string, any> | null> {
  // Try with current crumb
  let auth = await getCrumb();
  if (!auth) {
    console.log('[YF] No crumb available for', ticker);
    return null;
  }
  try {
    const result = await fetchQuoteSummaryOnce(ticker, auth);
    if (result) return result;

    // First attempt failed - force refresh crumb and retry once
    console.log('[YF] Retrying with fresh crumb for', ticker);
    cachedCrumb = null;
    cachedCookies = '';
    crumbTimestamp = 0;
    auth = await getCrumb();
    if (!auth) return null;
    return await fetchQuoteSummaryOnce(ticker, auth);
  } catch (err: any) {
    console.log('[YF] fetchQuoteSummary error for', ticker, ':', err?.message);
    return null;
  }
}

async function fetchChartData(ticker: string, range: string = '1y', interval: string = '1d') {
  try {
    const url = `https://query1.finance.yahoo.com/v8/finance/chart/${encodeURIComponent(ticker)}?range=${range}&interval=${interval}&includePrePost=false`;
    const res = await fetch(url, { headers: { 'User-Agent': UA } });
    if (!res.ok) return null;
    const json = await res.json();
    const result = json?.chart?.result?.[0];
    if (!result) return null;
    const quote = result?.indicators?.quote?.[0] ?? {};
    return {
      timestamp: result?.timestamp ?? [],
      close: quote?.close ?? [],
      open: quote?.open ?? [],
      high: quote?.high ?? [],
      low: quote?.low ?? [],
      volume: quote?.volume ?? [],
      meta: result?.meta ?? {},
    };
  } catch {
    return null;
  }
}

function extractRaw(obj: any): number | null {
  if (!obj || typeof obj !== 'object') return null;
  const raw = obj?.raw;
  if (raw === undefined || raw === null) return null;
  if (typeof raw === 'number' && !isNaN(raw)) return raw;
  return null;
}

function extractFmt(obj: any): string | null {
  if (!obj || typeof obj !== 'object') return null;
  return obj?.fmt ?? null;
}

export async function GET(request: NextRequest) {
  const ticker = request.nextUrl.searchParams.get('ticker')?.toUpperCase?.() ?? '';
  const range = request.nextUrl.searchParams.get('range') ?? '1y';

  if (!ticker) {
    return NextResponse.json({ error: 'Ticker fehlt' }, { status: 400 });
  }

  try {
    // Fetch chart data + quoteSummary in parallel
    const [chartData, summary] = await Promise.all([
      fetchChartData(ticker, range, range === '5y' ? '1wk' : '1d'),
      fetchQuoteSummary(ticker),
    ]);

    if (!chartData) {
      return NextResponse.json({ error: `Keine Daten f\u00fcr ${ticker} gefunden` }, { status: 404 });
    }

    const sd = summary?.summaryDetail ?? {};
    const fd = summary?.financialData ?? {};
    const ks = summary?.defaultKeyStatistics ?? {};
    const ce = summary?.calendarEvents ?? {};

    const closes = (chartData?.close ?? []).filter((c: any) => c !== null && c !== undefined) as number[];
    const rsi = calculateRSI(closes);
    const meta = chartData?.meta ?? {};

    const currentPrice = meta?.regularMarketPrice ?? (closes.length > 0 ? closes[closes.length - 1] : null);
    const previousClose = meta?.chartPreviousClose ?? meta?.previousClose ?? null;
    const change = currentPrice && previousClose ? currentPrice - previousClose : null;
    const changePercent = change !== null && previousClose ? (change / previousClose) * 100 : null;

    const name = meta?.longName ?? meta?.shortName ?? ticker;
    const currency = meta?.currency ?? 'USD';

    // Fundamental data from quoteSummary API (much more reliable than scraping)
    const kgv = extractRaw(sd?.trailingPE) ?? extractRaw(ks?.trailingPE);
    const forwardKgv = extractRaw(sd?.forwardPE) ?? extractRaw(ks?.forwardPE);
    const marketCap = extractRaw(sd?.marketCap);
    const beta = extractRaw(sd?.beta) ?? extractRaw(ks?.beta);
    const fiftyTwoWeekHigh = extractRaw(sd?.fiftyTwoWeekHigh) ?? meta?.fiftyTwoWeekHigh ?? null;
    const fiftyTwoWeekLow = extractRaw(sd?.fiftyTwoWeekLow) ?? meta?.fiftyTwoWeekLow ?? null;

    // Dividend data
    const dividendYieldRaw = extractRaw(sd?.dividendYield);
    const dividendenRendite = dividendYieldRaw !== null ? dividendYieldRaw * 100 : 0;
    const forwardDividendAmount = extractRaw(sd?.dividendRate);
    const trailingDividendRate = extractRaw(ks?.trailingAnnualDividendRate) ?? extractRaw(sd?.trailingAnnualDividendRate);
    const trailingDividendYieldRaw = extractRaw(ks?.trailingAnnualDividendYield) ?? extractRaw(sd?.trailingAnnualDividendYield);
    const trailingDividendYield = trailingDividendYieldRaw !== null ? trailingDividendYieldRaw * 100 : null;
    const payoutRatioRaw = extractRaw(sd?.payoutRatio);
    const payoutRatio = payoutRatioRaw !== null ? payoutRatioRaw * 100 : null;
    const fiveYearAvgDividendYield = extractRaw(sd?.fiveYearAvgDividendYield);
    const exDividendDate = extractFmt(sd?.exDividendDate);

    // Earnings date
    const earningsDates = ce?.earnings?.earningsDate;
    const earningsDate = Array.isArray(earningsDates) && earningsDates.length > 0
      ? extractFmt(earningsDates[0])
      : null;

    // Financial data
    const freeCashflow = extractRaw(fd?.freeCashflow);
    const revenueGrowthRaw = extractRaw(fd?.revenueGrowth);
    const revenueGrowth = revenueGrowthRaw !== null ? revenueGrowthRaw * 100 : null;
    const profitMarginsRaw = extractRaw(fd?.profitMargins);
    const profitMargins = profitMarginsRaw !== null ? profitMarginsRaw * 100 : null;
    const debtToEquity = extractRaw(fd?.debtToEquity);
    const verschuldungsgrad = debtToEquity !== null ? debtToEquity / 100 : null;
    const returnOnEquityRaw = extractRaw(fd?.returnOnEquity);
    const returnOnEquity = returnOnEquityRaw !== null ? returnOnEquityRaw * 100 : null;
    const targetMeanPrice = extractRaw(fd?.targetMeanPrice);
    const recommendationKey = fd?.recommendationKey ?? null;

    // === NEW: Extended indicators ===
    // Valuation
    const pegRatio = extractRaw(ks?.pegRatio);
    const priceToBook = extractRaw(ks?.priceToBook);
    const priceToSales = extractRaw(sd?.priceToSalesTrailing12Months) ?? extractRaw(ks?.priceToSalesTrailing12Months);
    const enterpriseValue = extractRaw(ks?.enterpriseValue);
    const evToEbitda = extractRaw(ks?.enterpriseToEbitda);
    const evToRevenue = extractRaw(ks?.enterpriseToRevenue);
    const trailingEps = extractRaw(ks?.trailingEps);
    const forwardEps = extractRaw(ks?.forwardEps);

    // Profitability
    const operatingMarginsRaw = extractRaw(fd?.operatingMargins);
    const operatingMargins = operatingMarginsRaw !== null ? operatingMarginsRaw * 100 : null;
    const grossMarginsRaw = extractRaw(fd?.grossMargins);
    const grossMargins = grossMarginsRaw !== null ? grossMarginsRaw * 100 : null;
    const ebitdaMarginsRaw = extractRaw(fd?.ebitdaMargins);
    const ebitdaMargins = ebitdaMarginsRaw !== null ? ebitdaMarginsRaw * 100 : null;

    // Balance sheet strength
    const currentRatio = extractRaw(fd?.currentRatio);
    const quickRatio = extractRaw(fd?.quickRatio);
    const totalCash = extractRaw(fd?.totalCash);
    const totalDebt = extractRaw(fd?.totalDebt);
    const totalRevenue = extractRaw(fd?.totalRevenue);

    // Other
    const shortRatio = extractRaw(ks?.shortRatio);
    const fiftyTwoWeekChangeRaw = extractRaw(ks?.['52WeekChange']);
    const fiftyTwoWeekChange = fiftyTwoWeekChangeRaw !== null ? fiftyTwoWeekChangeRaw * 100 : null;
    const bookValue = extractRaw(ks?.bookValue);
    const earningsGrowthRaw = extractRaw(fd?.earningsGrowth);
    const earningsGrowth = earningsGrowthRaw !== null ? earningsGrowthRaw * 100 : null;

    // Chart points
    const chartPoints = (chartData?.timestamp ?? []).map((ts: number, i: number) => ({
      date: new Date((ts ?? 0) * 1000).toISOString().split('T')[0],
      close: chartData?.close?.[i] ?? null,
      open: chartData?.open?.[i] ?? null,
      high: chartData?.high?.[i] ?? null,
      low: chartData?.low?.[i] ?? null,
      volume: chartData?.volume?.[i] ?? null,
    })).filter((p: any) => p?.close !== null);

    // Technical indicators
    const last50 = closes.slice(-50);
    const last200 = closes.slice(-200);
    const ma50 = last50.length >= 10 ? last50.reduce((a: number, b: number) => a + b, 0) / last50.length : null;
    const ma200 = last200.length >= 50 ? last200.reduce((a: number, b: number) => a + b, 0) / last200.length : null;

    let trend = 'Seitw\u00e4rts';
    if (currentPrice && ma50 && ma200) {
      if (currentPrice > ma50 && ma50 > ma200) trend = 'Aufw\u00e4rtstrend';
      else if (currentPrice < ma50 && ma50 < ma200) trend = 'Abw\u00e4rtstrend';
    }

    return NextResponse.json({
      ticker,
      name,
      currency,
      currentPrice,
      previousClose,
      change,
      changePercent,
      marketCap,
      kgv,
      forwardKgv,
      dividendenRendite,
      forwardDividendAmount,
      trailingDividendRate,
      trailingDividendYield,
      payoutRatio,
      fiveYearAvgDividendYield,
      exDividendDate,
      earningsDate,
      fiftyTwoWeekHigh,
      fiftyTwoWeekLow,
      beta,
      freeCashflow,
      totalDebt,
      totalRevenue,
      totalCash,
      revenueGrowth,
      earningsGrowth,
      profitMargins,
      verschuldungsgrad,
      returnOnEquity,
      targetMeanPrice,
      recommendationKey,
      // Extended indicators
      pegRatio,
      priceToBook,
      priceToSales,
      enterpriseValue,
      evToEbitda,
      evToRevenue,
      trailingEps,
      forwardEps,
      operatingMargins,
      grossMargins,
      ebitdaMargins,
      currentRatio,
      quickRatio,
      shortRatio,
      fiftyTwoWeekChange,
      bookValue,
      rsi,
      trend,
      ma50,
      ma200,
      support: fiftyTwoWeekLow,
      resistance: fiftyTwoWeekHigh,
      chartData: chartPoints,
    });
  } catch (err: any) {
    return NextResponse.json({ error: `Fehler beim Abrufen: ${err?.message ?? 'Unbekannt'}` }, { status: 500 });
  }
}
