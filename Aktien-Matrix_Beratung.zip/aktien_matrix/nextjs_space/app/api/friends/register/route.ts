import { NextResponse } from 'next/server';

// In-memory cache for friends data (persists during runtime)
let friendsCache: any = null;
let lastLoad = 0;

// Get friends data from environment variable, file, or cache
const getFriendsData = () => {
  // Return cached data if available
  if (friendsCache) {
    return friendsCache;
  }
  
  // Load from env var
  try {
    const envData = process.env.FRIENDS_DATA;
    if (envData) {
      friendsCache = JSON.parse(envData);
      lastLoad = Date.now();
      return friendsCache;
    }
  } catch (e) {
    console.error('Error parsing FRIENDS_DATA:', e);
  }
  
  // Try loading from file (for local dev or fallback)
  try {
    const fs = require('fs');
    const path = require('path');
    const filePath = path.join(process.cwd(), 'data', 'friends.json');
    if (fs.existsSync(filePath)) {
      const fileData = fs.readFileSync(filePath, 'utf8');
      friendsCache = JSON.parse(fileData);
      lastLoad = Date.now();
      return friendsCache;
    }
  } catch (e) {
    console.error('Error reading friends.json:', e);
  }
  
  // Default empty data
  return { 
    friends: [], 
    inviteCodes: [
      { code: 'FRIEND-2024-001', usedBy: null, permissions: { canViewDepot: true, canViewTrading: true, canViewML: true, canEdit: false } },
      { code: 'FRIEND-2024-002', usedBy: null, permissions: { canViewDepot: true, canViewTrading: true, canViewML: false, canEdit: false } },
      { code: 'FRIEND-2024-003', usedBy: null, permissions: { canViewDepot: true, canViewTrading: false, canViewML: false, canEdit: false } }
    ]
  };
};

// Send Telegram notification
const sendTelegramNotification = async (message: string) => {
  try {
    const botToken = process.env.TELEGRAM_BOT_TOKEN;
    const chatId = '-1003710399734'; // Claw Zentrale
    const topicId = '1'; // General topic
    
    if (!botToken) {
      console.log('No Telegram bot token configured');
      return;
    }
    
    const url = `https://api.telegram.org/bot${botToken}/sendMessage`;
    const response = await fetch(url, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        chat_id: chatId,
        message_thread_id: topicId,
        text: message,
        parse_mode: 'HTML'
      })
    });
    
    if (!response.ok) {
      console.error('Failed to send Telegram notification');
    }
  } catch (e) {
    console.error('Error sending Telegram notification:', e);
  }
};

// POST - Register with invite code
export async function POST(request: Request) {
  const body = await request.json();
  const { email, password, name, inviteCode } = body;

  if (!email || !password || !name || !inviteCode) {
    return NextResponse.json({ 
      error: 'Alle Felder sind erforderlich' 
    }, { status: 400 });
  }

  const friendsData = getFriendsData();

  // Find invite code
  const codeIndex = friendsData.inviteCodes?.findIndex((c: any) => c.code === inviteCode);
  
  if (codeIndex === -1 || !friendsData.inviteCodes?.[codeIndex]) {
    return NextResponse.json({ 
      error: 'Ungültiger Invite Code' 
    }, { status: 400 });
  }

  const code = friendsData.inviteCodes[codeIndex];

  // Check if code is already used
  if (code.usedBy) {
    return NextResponse.json({ 
      error: 'Dieser Code wurde bereits verwendet' 
    }, { status: 400 });
  }

  // Check if email is already registered
  const existingFriend = friendsData.friends?.find((f: any) => 
    f.email?.toLowerCase() === email.toLowerCase()
  );
  
  if (existingFriend) {
    return NextResponse.json({ 
      error: 'Diese E-Mail ist bereits registriert' 
    }, { status: 400 });
  }

  // Create new friend
  const newFriend = {
    id: `friend_${Date.now()}`,
    email: email.toLowerCase(),
    name,
    password,
    inviteCode,
    createdAt: new Date().toISOString().split('T')[0],
    isActive: true,
    permissions: code.permissions || {
      canViewDepot: true,
      canViewTrading: true,
      canViewML: false,
      canEdit: false
    }
  };

  // Update cache
  friendsCache = {
    ...friendsData,
    friends: [...(friendsData.friends || []), newFriend],
    inviteCodes: friendsData.inviteCodes.map((c: any, i: number) => 
      i === codeIndex ? { ...c, usedBy: email.toLowerCase() } : c
    )
  };

  // Send Telegram notification to admin
  const permissionsList = [];
  if (newFriend.permissions.canViewDepot) permissionsList.push('Depot');
  if (newFriend.permissions.canViewTrading) permissionsList.push('Trading');
  if (newFriend.permissions.canViewML) permissionsList.push('ML');
  
  const notificationMessage = `🎉 <b>NEUE REGISTRIERUNG!</b>

👤 <b>${name}</b>
📧 ${email}
🎫 Code: ${inviteCode}
🔑 Berechtigungen: ${permissionsList.join(', ')}

✅ Konto ist sofort aktiv!

⚠️ <i>HINWEIS: Um diesen Benutzer dauerhaft zu speichern, aktualisiere bitte die FRIENDS_DATA Environment Variable im Vercel Dashboard.</i>`;

  await sendTelegramNotification(notificationMessage);

  return NextResponse.json({ 
    success: true, 
    message: 'Registrierung erfolgreich!',
    permissions: newFriend.permissions
  });
}

// GET - Validate invite code
export async function GET(request: Request) {
  const { searchParams } = new URL(request.url);
  const code = searchParams.get('code');

  if (!code) {
    return NextResponse.json({ error: 'Code erforderlich' }, { status: 400 });
  }

  const friendsData = getFriendsData();
  const inviteCode = friendsData.inviteCodes?.find((c: any) => c.code === code);

  if (!inviteCode) {
    return NextResponse.json({ 
      valid: false, 
      error: 'Ungültiger Code' 
    });
  }

  if (inviteCode.usedBy) {
    return NextResponse.json({ 
      valid: false, 
      error: 'Code bereits verwendet' 
    });
  }

  return NextResponse.json({ 
    valid: true, 
    permissions: inviteCode.permissions 
  });
}