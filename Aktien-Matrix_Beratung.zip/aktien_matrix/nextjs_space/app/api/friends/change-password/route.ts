import { NextResponse } from 'next/server';

// In-memory cache
let friendsCache: any = null;

// Get friends data from environment variable or cache
const getFriendsData = () => {
  if (friendsCache) {
    return friendsCache;
  }
  
  try {
    const envData = process.env.FRIENDS_DATA;
    if (envData) {
      friendsCache = JSON.parse(envData);
      return friendsCache;
    }
  } catch (e) {
    console.error('Error parsing FRIENDS_DATA:', e);
  }
  
  return { friends: [], inviteCodes: [] };
};

// POST - Change password
export async function POST(request: Request) {
  const body = await request.json();
  const { email, currentPassword, newPassword } = body;

  if (!email || !currentPassword || !newPassword) {
    return NextResponse.json({ error: 'Alle Felder erforderlich' }, { status: 400 });
  }

  if (newPassword.length < 8) {
    return NextResponse.json({ error: 'Passwort muss mindestens 8 Zeichen haben' }, { status: 400 });
  }

  const friendsData = getFriendsData();
  const friendIndex = friendsData.friends?.findIndex((f: any) =>
    f.email === email.toLowerCase() && f.password === currentPassword
  );

  if (friendIndex === -1 || !friendsData.friends?.[friendIndex]) {
    return NextResponse.json({ error: 'Aktuelles Passwort ist falsch' }, { status: 400 });
  }

  // Update password in cache
  friendsData.friends[friendIndex].password = newPassword;
  friendsCache = friendsData;
  
  console.log('📝 PASSWORD CHANGED:', email);

  return NextResponse.json({ success: true, message: 'Passwort erfolgreich geändert' });
}