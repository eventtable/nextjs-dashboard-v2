import { NextResponse } from 'next/server';

// In-memory cache
let friendsCache: any = null;

// Get friends data from environment variable or cache
const getFriendsData = () => {
  if (friendsCache) {
    return friendsCache;
  }
  
  try {
    const envData = process.env.FRIENDS_DATA;
    if (envData) {
      friendsCache = JSON.parse(envData);
      return friendsCache;
    }
  } catch (e) {
    console.error('Error parsing FRIENDS_DATA:', e);
  }
  
  return { friends: [], inviteCodes: [] };
};

// POST - Update profile (name)
export async function POST(request: Request) {
  const body = await request.json();
  const { email, name } = body;

  if (!email || !name) {
    return NextResponse.json({ error: 'Email und Name erforderlich' }, { status: 400 });
  }

  const friendsData = getFriendsData();
  const friendIndex = friendsData.friends?.findIndex((f: any) => f.email === email.toLowerCase());

  if (friendIndex === -1 || !friendsData.friends?.[friendIndex]) {
    return NextResponse.json({ error: 'Benutzer nicht gefunden' }, { status: 404 });
  }

  // Update name in cache
  friendsData.friends[friendIndex].name = name;
  friendsCache = friendsData;
  
  console.log('📝 PROFILE UPDATED:', email);

  return NextResponse.json({ success: true, message: 'Profil aktualisiert' });
}