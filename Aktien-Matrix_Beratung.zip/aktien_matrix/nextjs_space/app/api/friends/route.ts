import { NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';

export async function GET() {
  try {
    const friends = await prisma.user.findMany({
      where: { isAdmin: false },
      orderBy: { createdAt: 'desc' },
      select: {
        id: true,
        name: true,
        email: true,
        isActive: true,
        createdAt: true
      }
    });

    const formatted = friends.map(f => ({
      id: f.id,
      name: f.name,
      email: f.email,
      status: f.isActive ? 'active' : 'inactive',
      createdAt: f.createdAt
    }));

    return NextResponse.json({ friends: formatted });
  } catch (error) {
    console.error('Friends API error:', error);
    return NextResponse.json({ friends: [], error: 'Server error' }, { status: 500 });
  }
}