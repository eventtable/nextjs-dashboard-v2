export const dynamic = 'force-dynamic';

import { NextRequest, NextResponse } from 'next/server';
import { searchStocks } from '@/lib/stock-index-data';

export async function GET(request: NextRequest) {
  const q = request.nextUrl.searchParams.get('q') ?? '';
  if (!q || q.trim().length < 1) {
    return NextResponse.json({ results: [] });
  }
  const results = searchStocks(q, 10);
  return NextResponse.json({ results });
}
