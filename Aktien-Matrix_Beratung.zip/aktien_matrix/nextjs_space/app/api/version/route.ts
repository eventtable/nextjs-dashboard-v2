import { NextResponse } from 'next/server';

export const dynamic = 'force-dynamic';

export async function GET() {
  return NextResponse.json({
    version: '2.8.0',
    deployedAt: new Date().toISOString(),
    nodeEnv: process.env.NODE_ENV || 'production'
  });
}