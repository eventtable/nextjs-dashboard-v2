import { NextRequest, NextResponse } from 'next/server';
import bcrypt from 'bcryptjs';

// In-memory Store für registrierte Benutzer (nicht-persistent)
const registeredUsers: Record<string, any> = {};

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { email, name, password } = body;

    if (!email || !password) {
      return NextResponse.json(
        { error: 'Email und Passwort erforderlich' },
        { status: 400 }
      );
    }

    if (password.length < 8) {
      return NextResponse.json(
        { error: 'Passwort muss mindestens 8 Zeichen lang sein' },
        { status: 400 }
      );
    }

    const normalizedEmail = email.toLowerCase().trim();

    // Prüfen ob Email bereits existiert
    if (registeredUsers[normalizedEmail]) {
      return NextResponse.json(
        { error: 'Diese Email ist bereits registriert' },
        { status: 400 }
      );
    }

    // Passwort hashen
    const hashedPassword = await bcrypt.hash(password, 12);

    // User erstellen (mit gehashtem Passwort)
    const user = {
      id: 'user_' + Date.now(),
      email: normalizedEmail,
      name: name || '',
      password: hashedPassword,
      isAdmin: false,
      createdAt: new Date().toISOString()
    };

    registeredUsers[normalizedEmail] = user;
    console.log('\u2705 User registered:', normalizedEmail);

    // Ohne Passwort zurückgeben
    const { password: _, ...userWithoutPassword } = user;

    return NextResponse.json({
      success: true,
      user: userWithoutPassword,
      message: 'Registrierung erfolgreich!'
    });
  } catch (error: any) {
    console.error('\u274c Registration error:', error);
    return NextResponse.json(
      { error: 'Registrierung fehlgeschlagen' },
      { status: 500 }
    );
  }
}
