import { NextRequest, NextResponse } from 'next/server';

// In-memory store for ML predictions (resets on server restart)
let latestPredictions: any = null;

export async function GET() {
  try {
    if (!latestPredictions) {
      return NextResponse.json(
        { error: 'No predictions available yet' },
        { status: 404 }
      );
    }
    
    return NextResponse.json(latestPredictions);
  } catch (error) {
    console.error('Error fetching ML predictions:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    
    // Validate the payload
    if (!body.predictions || !Array.isArray(body.predictions)) {
      return NextResponse.json(
        { error: 'Invalid payload: predictions array required' },
        { status: 400 }
      );
    }
    
    // Store the predictions
    latestPredictions = {
      ...body,
      received_at: new Date().toISOString()
    };
    
    console.log('✅ ML Predictions received:', body.predictions.length, 'signals');
    
    return NextResponse.json({
      success: true,
      message: 'Predictions stored successfully',
      count: body.predictions.length
    });
  } catch (error) {
    console.error('Error storing ML predictions:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}