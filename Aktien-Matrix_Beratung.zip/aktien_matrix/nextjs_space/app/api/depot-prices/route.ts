import { NextResponse } from 'next/server';
import { depotPositionen } from '@/data/depot';

export const dynamic = 'force-dynamic';

const UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36';

// Wechselkurse zu EUR (aktuelle ungefähre Werte)
const EXCHANGE_RATES: Record<string, number> = {
  'EUR': 1.0,
  'USD': 0.92,  // 1 USD = 0.92 EUR
  'GBP': 1.20,  // 1 GBP = 1.20 EUR
  'DKK': 0.134, // 1 DKK = 0.134 EUR
};

interface PriceData {
  ticker: string;
  price: number;
  name: string;
  currency: string;
  originalPrice: number;
  originalCurrency: string;
}

async function fetchSinglePrice(ticker: string): Promise<PriceData | null> {
  try {
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), 5000); // 5 Sekunden Timeout
    
    const url = `https://query1.finance.yahoo.com/v8/finance/chart/${encodeURIComponent(ticker)}?interval=1d&range=1d`;
    const res = await fetch(url, {
      headers: { 'User-Agent': UA },
      cache: 'no-store',
      signal: controller.signal
    });
    
    clearTimeout(timeout);
    
    if (!res.ok) {
      console.log(`[DepotPrices] Failed for ${ticker}: ${res.status}`);
      return null;
    }
    
    const json = await res.json();
    const meta = json?.chart?.result?.[0]?.meta;
    
    if (!meta) {
      console.log(`[DepotPrices] No meta for ${ticker}`);
      return null;
    }
    
    const originalPrice = meta.regularMarketPrice;
    const originalCurrency = meta.currency || 'EUR';
    
    // In EUR umrechnen
    const exchangeRate = EXCHANGE_RATES[originalCurrency] || 1.0;
    const priceInEur = originalPrice * exchangeRate;
    
    return {
      ticker,
      price: priceInEur,
      originalPrice,
      originalCurrency,
      name: meta.longName || meta.shortName || ticker,
      currency: 'EUR'
    };
  } catch (err: any) {
    if (err.name === 'AbortError') {
      console.log(`[DepotPrices] Timeout for ${ticker}`);
    } else {
      console.log(`[DepotPrices] Error for ${ticker}:`, err?.message);
    }
    return null;
  }
}

export async function GET() {
  console.log('[DepotPrices] Fetching all depot prices...');
  
  const startTime = Date.now();
  
  // Alle Kurse parallel holen
  const pricePromises = depotPositionen.map(pos => fetchSinglePrice(pos.ticker));
  const results = await Promise.all(pricePromises);
  
  const endTime = Date.now();
  console.log(`[DepotPrices] Fetched ${results.filter(r => r !== null).length}/${depotPositionen.length} prices in ${endTime - startTime}ms`);
  
  // Ergebnisse in Map umwandeln
  const priceMap: Record<string, PriceData> = {};
  results.forEach((result, index) => {
    if (result) {
      priceMap[result.ticker] = result;
    } else {
      // Fallback zu statischem Kurs
      const pos = depotPositionen[index];
      priceMap[pos.ticker] = {
        ticker: pos.ticker,
        price: pos.kursProStueck,
        originalPrice: pos.kursProStueck,
        originalCurrency: 'EUR',
        name: pos.name,
        currency: 'EUR'
      };
    }
  });
  
  return NextResponse.json({
    prices: priceMap,
    timestamp: new Date().toISOString(),
    count: Object.keys(priceMap).length
  });
}
