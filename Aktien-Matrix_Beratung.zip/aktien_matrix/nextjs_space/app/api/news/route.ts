import { NextRequest, NextResponse } from 'next/server';
import { NewsItem } from '@/lib/fundamental-types';

// Cache-Mechanismus
interface CacheEntry {
  data: NewsItem[];
  timestamp: number;
}

const CACHE_DURATION = 5 * 60 * 1000; // 5 Minuten in Millisekunden
const newsCache: Map<string, CacheEntry> = new Map();

// Hilfsfunktion: XML zu JSON parsen (für RSS)
async function parseRSSFeed(xmlText: string, source: string): Promise<NewsItem[]> {
  const items: NewsItem[] = [];
  
  try {
    // Einfacher XML-Parser mit Regex
    const itemRegex = /<item>([\s\S]*?)<\/item>/g;
    const matches = xmlText.matchAll(itemRegex);
    
    for (const match of matches) {
      const itemContent = match[1];
      
      const titleMatch = itemContent.match(/<title><!\[CDATA\[(.*?)\]\]><\/title>/) || 
                        itemContent.match(/<title>(.*?)<\/title>/);
      const linkMatch = itemContent.match(/<link>(.*?)<\/link>/);
      const pubDateMatch = itemContent.match(/<pubDate>(.*?)<\/pubDate>/);
      const descriptionMatch = itemContent.match(/<description><!\[CDATA\[(.*?)\]\]><\/description>/) ||
                              itemContent.match(/<description>(.*?)<\/description>/);
      
      if (titleMatch && linkMatch) {
        const pubDate = pubDateMatch ? new Date(pubDateMatch[1]) : new Date();
        
        items.push({
          id: `${source}-${pubDate.getTime()}-${items.length}`,
          title: titleMatch[1].replace(/&lt;.*?&gt;/g, '').trim(),
          description: descriptionMatch ? 
            descriptionMatch[1].replace(/&lt;.*?&gt;/g, '').replace(/<[^\u003e]*>/g, '').trim() : 
            undefined,
          source,
          publishedAt: pubDate,
          url: linkMatch[1].trim(),
        });
      }
    }
  } catch (error) {
    console.error(`Error parsing RSS from ${source}:`, error);
  }
  
  return items;
}

// Yahoo Finance RSS Feed
async function fetchYahooFinanceNews(ticker?: string): Promise<NewsItem[]> {
  try {
    let url: string;
    
    if (ticker) {
      // Ticker-spezifische News
      url = `https://feeds.finance.yahoo.com/rss/2.0/headline?s=${ticker}&region=US&lang=en-US`;
    } else {
      // Allgemeine Markt-News
      url = 'https://feeds.finance.yahoo.com/rss/2.0/headline?s=%5EDJI,&region=US&lang=en-US';
    }
    
    const response = await fetch(url, {
      headers: {
        'User-Agent': 'Mozilla/5.0 (compatible; NewsBot/1.0)',
      },
      next: { revalidate: 300 }
    });
    
    if (!response.ok) {
      throw new Error(`Yahoo Finance RSS error: ${response.status}`);
    }
    
    const xmlText = await response.text();
    const items = await parseRSSFeed(xmlText, 'Yahoo Finance');
    
    // Füge Ticker zu jeder News hinzu wenn spezifiziert
    return items.map(item => ({
      ...item,
      ticker: ticker || 'MARKET'
    }));
  } catch (error) {
    console.error('Yahoo Finance fetch error:', error);
    return [];
  }
}

// Google News API (über RSS)
async function fetchGoogleNews(query?: string): Promise<NewsItem[]> {
  try {
    // Google News RSS Feed
    // Hinweis: In Produktion sollte hier eine echte Google News API verwendet werden
    // oder ein Proxy-Server für CORS
    const searchQuery = query || 'Aktien Börse DAX';
    const encodedQuery = encodeURIComponent(searchQuery);
    
    // Mock-Daten für Demo (da Google News RSS oft CORS-Probleme hat)
    const mockNews: NewsItem[] = [
      {
        id: `google-${Date.now()}-1`,
        title: `${searchQuery}: Aktuelle Marktentwicklungen und Analysen`,
        description: 'Die aktuellen Entwicklungen am Markt zeigen interessante Trends für Investoren.',
        source: 'Google News',
        publishedAt: new Date(Date.now() - 2 * 60 * 60 * 1000),
        url: `https://news.google.com/search?q=${encodedQuery}`,
        ticker: query
      },
      {
        id: `google-${Date.now()}-2`,
        title: 'Experten prognostizieren Kursbewegungen für die kommende Woche',
        description: 'Analysten erwarten volatile Märkte mit Chancen für langfristige Anleger.',
        source: 'Google News',
        publishedAt: new Date(Date.now() - 4 * 60 * 60 * 1000),
        url: 'https://news.google.com',
        ticker: query
      },
      {
        id: `google-${Date.now()}-3`,
        title: 'Zentralbank-Entscheidungen beeinflussen Anlegerstimmung',
        description: 'Die jüngsten geldpolitischen Entscheidungen haben Auswirkungen auf globale Märkte.',
        source: 'Google News',
        publishedAt: new Date(Date.now() - 6 * 60 * 60 * 1000),
        url: 'https://news.google.com',
        ticker: query
      }
    ];
    
    return mockNews;
  } catch (error) {
    console.error('Google News fetch error:', error);
    return [];
  }
}

// Finanzen.net RSS (deutsch)
async function fetchFinanzenNetNews(): Promise<NewsItem[]> {
  try {
    // Mock-Daten für deutsche Finanz-News
    const mockNews: NewsItem[] = [
      {
        id: `fn-${Date.now()}-1`,
        title: 'DAX startet mit Gewinnen in den Handel',
        description: 'Der Deutsche Aktienindex konnte am Morgen zulegen, unterstützt von starken Quartalszahlen.',
        source: 'Finanzen.net',
        publishedAt: new Date(Date.now() - 1 * 60 * 60 * 1000),
        url: 'https://www.finanzen.net',
      },
      {
        id: `fn-${Date.now()}-2`,
        title: 'Inflationsdaten aus der Eurozone fallen positiv aus',
        description: 'Die Verbraucherpreise entwickeln sich besser als erwartet, was die Märkte beflügelt.',
        source: 'Finanzen.net',
        publishedAt: new Date(Date.now() - 3 * 60 * 60 * 1000),
        url: 'https://www.finanzen.net',
      },
      {
        id: `fn-${Date.now()}-3`,
        title: 'Tech-Aktien im Fokus: Diese Werte überzeugen',
        description: 'Technologieunternehmen zeigen sich robust angesichts makroökonomischer Unsicherheiten.',
        source: 'Finanzen.net',
        publishedAt: new Date(Date.now() - 5 * 60 * 60 * 1000),
        url: 'https://www.finanzen.net',
      }
    ];
    
    return mockNews;
  } catch (error) {
    console.error('Finanzen.net fetch error:', error);
    return [];
  }
}

// Hauptfunktion zum Abrufen aller News
async function fetchAllNews(ticker?: string): Promise<NewsItem[]> {
  const cacheKey = ticker || 'general';
  const cached = newsCache.get(cacheKey);
  
  // Prüfe Cache
  if (cached && Date.now() - cached.timestamp < CACHE_DURATION) {
    return cached.data;
  }
  
  // Parallel fetching von allen Quellen
  const [yahooNews, googleNews, finanzenNews] = await Promise.all([
    fetchYahooFinanceNews(ticker),
    fetchGoogleNews(ticker ? `${ticker} Aktie` : undefined),
    fetchFinanzenNetNews()
  ]);
  
  // Kombiniere und sortiere nach Datum
  const allNews = [...yahooNews, ...googleNews, ...finanzenNews]
    .sort((a, b) => new Date(b.publishedAt).getTime() - new Date(a.publishedAt).getTime());
  
  // Entferne Duplikate (basierend auf Titel-Ähnlichkeit)
  const uniqueNews: NewsItem[] = [];
  const titles = new Set<string>();
  
  for (const news of allNews) {
    const normalizedTitle = news.title.toLowerCase().slice(0, 50);
    if (!titles.has(normalizedTitle)) {
      titles.add(normalizedTitle);
      uniqueNews.push(news);
    }
  }
  
  // Speichere in Cache
  newsCache.set(cacheKey, {
    data: uniqueNews,
    timestamp: Date.now()
  });
  
  return uniqueNews;
}

// GET Handler
export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const ticker = searchParams.get('ticker') || undefined;
    const limit = parseInt(searchParams.get('limit') || '20', 10);
    
    const news = await fetchAllNews(ticker);
    
    // Paginierung
    const paginatedNews = news.slice(0, limit);
    
    return NextResponse.json({
      success: true,
      data: paginatedNews,
      meta: {
        total: news.length,
        returned: paginatedNews.length,
        ticker: ticker || null,
        cached: false
      }
    }, {
      headers: {
        'Cache-Control': 'public, max-age=300', // 5 Minuten Browser-Cache
      }
    });
    
  } catch (error) {
    console.error('News API Error:', error);
    
    return NextResponse.json({
      success: false,
      error: 'Failed to fetch news',
      message: error instanceof Error ? error.message : 'Unknown error'
    }, { status: 500 });
  }
}

// POST Handler für spezifische News-Anfragen
export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { tickers, categories } = body;
    
    // Hier könnte komplexere Logik für mehrere Tickers implementiert werden
    const allNews: NewsItem[] = [];
    
    if (Array.isArray(tickers)) {
      for (const ticker of tickers) {
        const news = await fetchAllNews(ticker);
        allNews.push(...news);
      }
    }
    
    // Sortiere und entferne Duplikate
    const uniqueNews = allNews
      .sort((a, b) => new Date(b.publishedAt).getTime() - new Date(a.publishedAt).getTime())
      .filter((news, index, self) => 
        index === self.findIndex(n => n.title.slice(0, 30) === news.title.slice(0, 30))
      );
    
    return NextResponse.json({
      success: true,
      data: uniqueNews,
      meta: {
        total: uniqueNews.length,
        tickers: tickers || []
      }
    });
    
  } catch (error) {
    console.error('News API POST Error:', error);
    
    return NextResponse.json({
      success: false,
      error: 'Failed to process news request',
      message: error instanceof Error ? error.message : 'Unknown error'
    }, { status: 500 });
  }
}