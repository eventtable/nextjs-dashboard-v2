export const dynamic = 'force-dynamic';

import { NextRequest, NextResponse } from 'next/server';
import { INDEX_STOCKS, SECTOR_LABELS, getStockInfo } from '@/lib/stock-index-data';

export async function GET(request: NextRequest) {
  const ticker = request.nextUrl.searchParams.get('ticker')?.toUpperCase() ?? '';
  if (!ticker) {
    return NextResponse.json({ error: 'Ticker fehlt' }, { status: 400 });
  }

  const stock = getStockInfo(ticker);
  if (!stock) {
    // Unknown stock - return empty, but try to find by sector if provided
    return NextResponse.json({ sector: null, sectorLabel: null, peers: [], hedgingPairs: [] });
  }

  const sectorPeers = INDEX_STOCKS.filter(s => s.sector === stock.sector && s.ticker !== stock.ticker);
  const sectorLabel = SECTOR_LABELS[stock.sector] ?? stock.sector;

  // Hedging pairs: stocks in related/inverse sectors
  const hedgingMap: Record<string, string[]> = {
    tech: ['utility', 'consumer', 'food'],
    software: ['utility', 'consumer', 'food'],
    semiconductor: ['utility', 'consumer', 'food'],
    auto: ['energy', 'defense', 'utility'],
    energy: ['tech', 'software', 'consumer'],
    pharma: ['tech', 'defense'],
    health: ['tech', 'defense'],
    finance: ['utility', 'consumer', 'food'],
    banking: ['utility', 'consumer', 'food'],
    defense: ['consumer', 'food', 'luxury'],
    luxury: ['utility', 'defense', 'energy'],
    retail: ['utility', 'energy'],
    consumer: ['tech', 'energy'],
    food: ['tech', 'semiconductor'],
    telecom: ['tech', 'consumer'],
    utility: ['tech', 'software'],
    industrial: ['utility', 'consumer'],
    insurance: ['tech', 'consumer'],
    chemical: ['tech', 'software'],
    media: ['utility', 'consumer'],
    materials: ['tech', 'software'],
    realestate: ['tech', 'energy'],
  };

  const hedgingSectors = hedgingMap[stock.sector] ?? ['utility', 'consumer'];
  const hedgingPairs = hedgingSectors.flatMap(hs => {
    const stocks = INDEX_STOCKS.filter(s => s.sector === hs).slice(0, 2);
    return stocks.map(s => ({
      ...s,
      sectorLabel: SECTOR_LABELS[s.sector] ?? s.sector,
      reason: `${sectorLabel}-Aktien und ${SECTOR_LABELS[hs] ?? hs}-Aktien bewegen sich oft gegenl\u00e4ufig. Wenn ${stock.name} schw\u00e4chelt, k\u00f6nnte ${s.name} profitieren.`,
    }));
  }).slice(0, 6);

  return NextResponse.json({
    sector: stock.sector,
    sectorLabel,
    peers: sectorPeers.map(s => ({ ...s, sectorLabel: SECTOR_LABELS[s.sector] ?? s.sector })),
    hedgingPairs,
  });
}