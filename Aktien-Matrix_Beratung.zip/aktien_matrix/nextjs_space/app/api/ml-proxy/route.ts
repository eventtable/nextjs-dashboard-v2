import { NextResponse } from 'next/server';

export const dynamic = 'force-dynamic';

export async function GET() {
  try {
    const response = await fetch('http://srv1516918.hstgr.cloud:5000/api/ml-predictions', {
      method: 'GET',
      headers: {
        'Content-Type': 'application/json',
      },
      cache: 'no-store',
    });

    if (!response.ok) {
      throw new Error(`API responded with ${response.status}`);
    }

    const data = await response.json();
    return NextResponse.json(data);
  } catch (error) {
    console.error('ML API Proxy Error:', error);
    return NextResponse.json(
      { error: 'Failed to fetch ML data', predictions: [], summary: { total: 0, winRate: 0 } },
      { status: 500 }
    );
  }
}