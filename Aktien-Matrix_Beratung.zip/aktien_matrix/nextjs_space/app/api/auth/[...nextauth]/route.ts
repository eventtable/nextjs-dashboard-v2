import NextAuth from 'next-auth'
import CredentialsProvider from 'next-auth/providers/credentials'

// Rate-Limiting: Max 5 Versuche pro IP/Email in 15 Minuten
const loginAttempts = new Map<string, { count: number; firstAttempt: number }>();
const RATE_LIMIT_MAX = 5;
const RATE_LIMIT_WINDOW = 15 * 60 * 1000; // 15 Minuten

function checkRateLimit(key: string): boolean {
  cleanupRateLimits();
  const now = Date.now();
  const record = loginAttempts.get(key);
  
  if (!record || (now - record.firstAttempt) > RATE_LIMIT_WINDOW) {
    loginAttempts.set(key, { count: 1, firstAttempt: now });
    return true;
  }
  
  if (record.count >= RATE_LIMIT_MAX) {
    return false; // Blockiert
  }
  
  record.count++;
  return true;
}

function resetRateLimit(key: string) {
  loginAttempts.delete(key);
}

// Cleanup alte Einträge bei jeder Prüfung (lazy cleanup)
function cleanupRateLimits() {
  const now = Date.now();
  for (const [key, record] of loginAttempts.entries()) {
    if ((now - record.firstAttempt) > RATE_LIMIT_WINDOW) {
      loginAttempts.delete(key);
    }
  }
}

// In-memory cache
let friendsCache: any = null;

// Get friends data from environment variable or cache
const getFriendsData = () => {
  // Return cached data if available
  if (friendsCache) {
    return friendsCache;
  }
  
  // Load from env var
  try {
    const envData = process.env.FRIENDS_DATA;
    if (envData) {
      friendsCache = JSON.parse(envData);
      return friendsCache;
    }
  } catch (e) {
    console.error('Error parsing FRIENDS_DATA:', e);
  }
  
  return { friends: [], inviteCodes: [] };
};

// Umgebungsvariablen für Credentials
const ADMIN_EMAIL = process.env.ADMIN_EMAIL || 'frank@dashboard.local'
const ADMIN_PASSWORD = process.env.ADMIN_PASSWORD || 'Frank2024!'

// Additional admin accounts from environment (optional)
// Set EXTRA_ADMIN_EMAIL and EXTRA_ADMIN_PASSWORD in .env for additional admins
const EXTRA_ADMIN_EMAIL = process.env.EXTRA_ADMIN_EMAIL?.toLowerCase();
const EXTRA_ADMIN_PASSWORD = process.env.EXTRA_ADMIN_PASSWORD;

const handler = NextAuth({
  secret: process.env.NEXTAUTH_SECRET,
  providers: [
    CredentialsProvider({
      name: 'credentials',
      credentials: {
        email: { label: 'Email', type: 'email' },
        password: { label: 'Password', type: 'password' }
      },
      async authorize(credentials) {
        if (!credentials?.email || !credentials?.password) {
          throw new Error('Email und Passwort erforderlich')
        }

        const normalizedEmail = credentials.email.toLowerCase().trim();
        const password = credentials.password;

        // Rate-Limiting prüfen
        if (!checkRateLimit(normalizedEmail)) {
          throw new Error('Zu viele Anmeldeversuche. Bitte warten Sie 15 Minuten.')
        }

        // Check if admin
        if (normalizedEmail === ADMIN_EMAIL.toLowerCase() && password === ADMIN_PASSWORD) {
          resetRateLimit(normalizedEmail);
          return {
            id: 'admin_1',
            email: normalizedEmail,
            name: 'Frank Müller',
            isAdmin: true,
            isFriend: false,
            permissions: {
              canViewDepot: true,
              canViewTrading: true,
              canViewML: true,
              canEdit: true
            }
          }
        }

        // Check if friend from cache or env var
        const friendsData = getFriendsData();
        const friend = friendsData.friends?.find((f: any) =>
          f.email === normalizedEmail && f.password === password && f.isActive
        );

        if (friend) {
          resetRateLimit(normalizedEmail);
          return {
            id: friend.id,
            email: friend.email,
            name: friend.name,
            isAdmin: false,
            isFriend: true,
            permissions: friend.permissions || {
              canViewDepot: true,
              canViewTrading: true,
              canViewML: false,
              canEdit: false
            }
          }
        }

        // Check extra admin from environment
        if (EXTRA_ADMIN_EMAIL && EXTRA_ADMIN_PASSWORD && normalizedEmail === EXTRA_ADMIN_EMAIL && password === EXTRA_ADMIN_PASSWORD) {
          resetRateLimit(normalizedEmail);
          return {
            id: 'admin_extra',
            email: normalizedEmail,
            name: 'Admin',
            isAdmin: true,
            isFriend: false,
            permissions: {
              canViewDepot: true,
              canViewTrading: true,
              canViewML: true,
              canEdit: true
            }
          }
        }

        throw new Error('Ungültige Anmeldedaten')
      }
    })
  ],
  session: {
    strategy: 'jwt'
  },
  jwt: {
    maxAge: 30 * 24 * 60 * 60
  },
  callbacks: {
    async jwt({ token, user }) {
      if (user) {
        token.id = user.id
        token.isAdmin = user.isAdmin || false
        token.isFriend = user.isFriend || false
        token.permissions = user.permissions || {}
        token.name = user.name || ''
      }
      return token
    },
    async session({ session, token }) {
      if (token) {
        session.user.id = token.id as string
        session.user.isAdmin = token.isAdmin as boolean
        session.user.isFriend = token.isFriend as boolean
        session.user.permissions = token.permissions as any
        session.user.name = token.name as string
      }
      return session
    }
  },
  pages: {
    signIn: '/login',
    error: '/login'
  }
})

export { handler as GET, handler as POST }