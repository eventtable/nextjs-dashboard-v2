import { NextRequest, NextResponse } from 'next/server'
import { PrismaClient } from '@prisma/client'
import bcrypt from 'bcryptjs'

const prisma = new PrismaClient()

export async function POST(req: NextRequest) {
  try {
    const { email, newPassword, adminToken } = await req.json()

    // Admin-Token Check (einfacher Schutz)
    if (adminToken !== process.env.ADMIN_RESET_TOKEN) {
      // Normaler User-Flow: Email + altes Passwort + neues Passwort
      const { oldPassword } = await req.json().catch(() => ({}))
      
      const user = await prisma.user.findUnique({ where: { email } })
      if (!user) return NextResponse.json({ error: 'User nicht gefunden' }, { status: 404 })
      
      const valid = await bcrypt.compare(oldPassword, user.password)
      if (!valid) return NextResponse.json({ error: 'Altes Passwort falsch' }, { status: 401 })
      
      const hash = await bcrypt.hash(newPassword, 12)
      await prisma.user.update({ where: { email }, data: { password: hash } })
      return NextResponse.json({ success: true })
    }

    // Admin-Reset: direkt ohne altes Passwort
    const user = await prisma.user.findUnique({ where: { email } })
    if (!user) return NextResponse.json({ error: 'User nicht gefunden' }, { status: 404 })

    const hash = await bcrypt.hash(newPassword, 12)
    await prisma.user.update({ where: { email }, data: { password: hash } })
    return NextResponse.json({ success: true })

  } catch (e) {
    return NextResponse.json({ error: 'Fehler' }, { status: 500 })
  }
}
