import { NextResponse } from 'next/server';
import { DEPOT_POSITIONS, DEPOT_TOTAL_REPORTED } from '@/lib/depot-data';

export const dynamic = 'force-dynamic';

const UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36';

interface LivePrice {
  ticker: string;
  price: number | null;
  changePercent: number | null;
  currency: string;
}

async function fetchLivePrices(tickers: string[]): Promise<Record<string, LivePrice>> {
  const validTickers = tickers.filter(Boolean);
  if (validTickers.length === 0) return {};

  const result: Record<string, LivePrice> = {};

  // Use v8 chart API (no auth needed) for quick price fetch
  const fetches = validTickers.map(async (ticker) => {
    try {
      const url = `https://query1.finance.yahoo.com/v8/finance/chart/${encodeURIComponent(ticker)}?range=5d&interval=1d&includePrePost=false`;
      const res = await fetch(url, { headers: { 'User-Agent': UA } });
      if (!res.ok) return;
      const json = await res.json();
      const meta = json?.chart?.result?.[0]?.meta;
      if (meta) {
        const price = meta.regularMarketPrice ?? null;
        const prevClose = meta.chartPreviousClose ?? meta.previousClose ?? null;
        const changePercent = price && prevClose ? ((price - prevClose) / prevClose) * 100 : null;
        result[ticker] = {
          ticker,
          price,
          changePercent,
          currency: meta.currency ?? 'EUR',
        };
      }
    } catch {
      // Skip failed ticker
    }
  });

  await Promise.all(fetches);
  return result;
}

export async function GET() {
  try {
    const tickers = DEPOT_POSITIONS.map(p => p.ticker).filter(Boolean);
    const livePrices = await fetchLivePrices(tickers);

    // EUR/USD for conversion
    let eurUsdRate = 1.0;
    try {
      const fxRes = await fetch('https://query1.finance.yahoo.com/v8/finance/chart/EURUSD=X?range=1d&interval=1d', {
        headers: { 'User-Agent': UA },
      });
      const fxJson = await fxRes.json();
      eurUsdRate = fxJson?.chart?.result?.[0]?.meta?.regularMarketPrice ?? 1.08;
    } catch {
      eurUsdRate = 1.08; // fallback
    }

    // EUR/GBP
    let eurGbpRate = 1.0;
    try {
      const fxRes = await fetch('https://query1.finance.yahoo.com/v8/finance/chart/EURGBP=X?range=1d&interval=1d', {
        headers: { 'User-Agent': UA },
      });
      const fxJson = await fxRes.json();
      eurGbpRate = fxJson?.chart?.result?.[0]?.meta?.regularMarketPrice ?? 0.84;
    } catch {
      eurGbpRate = 0.84;
    }

    // EUR/HKD
    let eurHkdRate = 1.0;
    try {
      const fxRes = await fetch('https://query1.finance.yahoo.com/v8/finance/chart/EURHKD=X?range=1d&interval=1d', {
        headers: { 'User-Agent': UA },
      });
      const fxJson = await fxRes.json();
      eurHkdRate = fxJson?.chart?.result?.[0]?.meta?.regularMarketPrice ?? 8.40;
    } catch {
      eurHkdRate = 8.40;
    }

    // EUR/DKK
    let eurDkkRate = 1.0;
    try {
      const fxRes = await fetch('https://query1.finance.yahoo.com/v8/finance/chart/EURDKK=X?range=1d&interval=1d', {
        headers: { 'User-Agent': UA },
      });
      const fxJson = await fxRes.json();
      eurDkkRate = fxJson?.chart?.result?.[0]?.meta?.regularMarketPrice ?? 7.46;
    } catch {
      eurDkkRate = 7.46;
    }

    const positions = DEPOT_POSITIONS.map(pos => {
      const live = pos.ticker ? livePrices[pos.ticker] : null;
      let livePrice = live?.price ?? null;
      let livePriceEur = pos.kaufkurs; // Fallback: reported price
      let liveChangePercent = live?.changePercent ?? null;
      const liveCurrency = live?.currency ?? 'EUR';

      if (livePrice !== null) {
        // Convert to EUR if needed
        if (liveCurrency === 'USD') {
          livePriceEur = livePrice / eurUsdRate;
        } else if (liveCurrency === 'GBp' || liveCurrency === 'GBX') {
          // GBp = pence, convert to GBP first
          livePriceEur = (livePrice / 100) / eurGbpRate;
        } else if (liveCurrency === 'GBP') {
          livePriceEur = livePrice / eurGbpRate;
        } else if (liveCurrency === 'HKD') {
          livePriceEur = livePrice / eurHkdRate;
        } else if (liveCurrency === 'DKK') {
          livePriceEur = livePrice / eurDkkRate;
        } else {
          livePriceEur = livePrice; // EUR or same
        }
      }

      const currentValue = pos.stueck * livePriceEur;
      const gainLoss = currentValue - pos.kaufwert;
      const gainLossPercent = pos.kaufwert > 0 ? (gainLoss / pos.kaufwert) * 100 : 0;

      return {
        ...pos,
        livePrice,
        livePriceEur,
        liveCurrency,
        liveChangePercent,
        currentValue,
        gainLoss,
        gainLossPercent,
      };
    });

    const totalValue = positions.reduce((sum, p) => sum + p.currentValue, 0);

    return NextResponse.json({
      positions,
      totalValue,
      totalReported: DEPOT_TOTAL_REPORTED,
      eurUsdRate,
      eurGbpRate,
      eurHkdRate,
      eurDkkRate,
      lastUpdate: new Date().toISOString(),
    });
  } catch (err: any) {
    return NextResponse.json({ error: err?.message ?? 'Fehler' }, { status: 500 });
  }
}
