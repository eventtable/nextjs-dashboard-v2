'use client';

import { LineChart, Line, XAxis, YAxis, ResponsiveContainer, Tooltip } from 'recharts';
import SharedHeader from '@/components/shared-header';

// HARTKODIERTE Test-Daten - KEINE Berechnung!
const debugData = [
  { day: '1', price: 100, ema: 100 },
  { day: '2', price: 105, ema: 102 },
  { day: '3', price: 98, ema: 101 },
  { day: '4', price: 110, ema: 104 },
  { day: '5', price: 115, ema: 107 },
  { day: '6', price: 108, ema: 108 },
  { day: '7', price: 120, ema: 112 },
  { day: '8', price: 125, ema: 116 },
  { day: '9', price: 118, ema: 118 },
  { day: '10', price: 130, ema: 123 },
];

export default function DebugChart() {
  return (
    <div className="min-h-screen bg-[#0a0e1a] text-white">
      <SharedHeader />
      
      <main className="pt-24 pb-12 px-4 max-w-4xl mx-auto">
        <h1 className="text-2xl font-bold mb-4">DEBUG: Hartkodierte Daten</h1>
        
        <div className="bg-[#1a1f37] p-6 rounded-lg">
          <h2 className="text-lg mb-4">Preis vs EMA (hartkodiert)</h2>
          
          <div style={{ height: 400 }}>
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={debugData} margin={{ top: 20, right: 30, left: 20, bottom: 20 }}>
                <XAxis dataKey="day" tick={{ fill: '#888' }} />
                <YAxis tick={{ fill: '#888' }} />
                <Tooltip 
                  contentStyle={{ backgroundColor: '#1a1f37', border: '1px solid #333' }}
                  itemStyle={{ color: '#fff' }}
                />
                
                {/* ZWEI LINIEN - beide müssen sichtbar sein! */}
                <Line 
                  type="monotone" 
                  dataKey="price" 
                  stroke="#ffffff" 
                  strokeWidth={3}
                  dot={{ r: 5, fill: '#fff' }}
                  name="Preis"
                />
                
                <Line 
                  type="monotone" 
                  dataKey="ema" 
                  stroke="#ff0000" 
                  strokeWidth={5}
                  dot={{ r: 8, fill: '#ff0000', stroke: '#fff', strokeWidth: 2 }}
                  name="EMA"
                />
              </LineChart>
            </ResponsiveContainer>
          </div>
          
          <div className="mt-4 p-4 bg-[#0d1220] rounded">
            <p className="text-yellow-400 font-bold">Erwartung:</p>
            <ul className="list-disc list-inside mt-2 text-gray-300">
              <li>Weiße Linie mit weißen Punkten = Preis</li>
              <li>🔴 ROTE dicke Linie mit roten Punkten = EMA</li>
              <li>Zwei getrennte Linien!</li>
            </ul>
          </div>
        </div>
      </main>
    </div>
  );
}