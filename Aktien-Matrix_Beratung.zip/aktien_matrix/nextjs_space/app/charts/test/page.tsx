'use client';

import StockChartTest from '@/components/depot/stock-chart-test';
import SharedHeader from '@/components/shared-header';

export default function ChartTestPage() {
  return (
    <div className="min-h-screen bg-[#0a0e1a] text-white">
      <SharedHeader />
      
      <main className="pt-24 pb-12 px-4 max-w-4xl mx-auto">
        <h1 className="text-2xl font-bold mb-6">EMA Test Chart</h1>
        
        <StockChartTest
          ticker="SAP.DE"
          name="SAP SE"
          currentPrice={186.20}
          fiftyTwoWeekHigh={220.00}
          fiftyTwoWeekLow={135.50}
        />
        
        <div className="mt-8 p-4 bg-[#1a1f37] rounded-lg text-sm text-gray-300">
          <p className="font-semibold text-white mb-2">Debug Info:</p>
          <p>• Klicke die EMA-Buttons oben rechts</p>
          <p>• EMA 50 = Grüne Linie</p>
          <p>• EMA 100 = Gelbe Linie</p>
          <p>• EMA 200 = Rote Linie</p>
          <p>• Weiße Linie = Aktueller Kurs</p>
        </div>
      </main>
    </div>
  );
}
