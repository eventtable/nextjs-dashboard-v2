'use client';

import { LineChart } from 'lucide-react';
import SharedHeader from '@/components/shared-header';
import TradingViewChart from '@/components/depot/tradingview-chart';
import { depotPositionen } from '@/data/depot';

// 52W High/Low Daten (geschätzt basierend auf aktuellen Kursen)
const aktienMit52W = [
  { ticker: 'SAP.DE', name: 'SAP SE', currentPrice: 186.20, fiftyTwoWeekHigh: 220.00, fiftyTwoWeekLow: 135.50 },
  { ticker: 'MSFT', name: 'Microsoft Corp.', currentPrice: 420.55, fiftyTwoWeekHigh: 468.35, fiftyTwoWeekLow: 362.90 },
  { ticker: 'BYD6.DE', name: 'BYD Co. Ltd.', currentPrice: 28.45, fiftyTwoWeekHigh: 35.20, fiftyTwoWeekLow: 22.10 },
  { ticker: 'ALV.DE', name: 'Allianz SE', currentPrice: 245.30, fiftyTwoWeekHigh: 265.00, fiftyTwoWeekLow: 210.50 },
  { ticker: 'MUV2.DE', name: 'Münchener Rück', currentPrice: 520.80, fiftyTwoWeekHigh: 580.00, fiftyTwoWeekLow: 450.00 },
  { ticker: 'NVO', name: 'Novo Nordisk', currentPrice: 82.15, fiftyTwoWeekHigh: 140.00, fiftyTwoWeekLow: 65.00 },
  { ticker: 'GOLD', name: 'Barrick Gold', currentPrice: 32.61, fiftyTwoWeekHigh: 38.00, fiftyTwoWeekLow: 24.50 },
  { ticker: 'MBB.DE', name: 'MBB SE', currentPrice: 42.80, fiftyTwoWeekHigh: 55.00, fiftyTwoWeekLow: 35.00 },
  // ETFs
  { ticker: 'EUN3.DE', name: 'iShares Core MSCI World', currentPrice: 98.50, fiftyTwoWeekHigh: 110.00, fiftyTwoWeekLow: 85.00 },
  { ticker: 'EXS1.DE', name: 'iShares Core DAX', currentPrice: 185.20, fiftyTwoWeekHigh: 210.00, fiftyTwoWeekLow: 160.00 },
  { ticker: '2B7F.DE', name: 'iShares NASDAQ 100', currentPrice: 145.30, fiftyTwoWeekHigh: 175.00, fiftyTwoWeekLow: 125.00 },
  { ticker: 'QDVA.DE', name: 'iShares S&P 500', currentPrice: 455.80, fiftyTwoWeekHigh: 520.00, fiftyTwoWeekLow: 400.00 },
  { ticker: 'A12GPV.DE', name: 'iShares STOXX Europe', currentPrice: 42.15, fiftyTwoWeekHigh: 48.00, fiftyTwoWeekLow: 38.00 },
  { ticker: 'EUNH.DE', name: 'iShares Core EUR Gov', currentPrice: 118.50, fiftyTwoWeekHigh: 125.00, fiftyTwoWeekLow: 112.00 },
  { ticker: 'EUNL.DE', name: 'iShares Core MSCI EM', currentPrice: 28.40, fiftyTwoWeekHigh: 32.00, fiftyTwoWeekLow: 24.50 },
  { ticker: 'SG0A.DE', name: 'iShares MSCI China', currentPrice: 5.85, fiftyTwoWeekHigh: 7.20, fiftyTwoWeekLow: 4.80 },
];

export default function ChartsPage() {
  return (
    <div className="min-h-screen bg-[#0a0e1a] text-white">
      <SharedHeader />
      
      <main className="pt-24 pb-12 px-4 sm:px-6 max-w-7xl mx-auto">
        <div className="mb-6">
          <h1 className="text-2xl font-bold flex items-center gap-2">
            <LineChart className="w-6 h-6 text-[#f0b90b]" />
            Erweiterte Charts
          </h1>
          <p className="text-gray-400 text-sm mt-1">
            Alle {aktienMit52W.length} Depot-Positionen mit EMA-Linien, Fibonacci-Levels und technischen Indikatoren
          </p>
        </div>

        <div className="space-y-6">
          {aktienMit52W.map((aktie) => (
            <div key={aktie.ticker} className="bg-[#0d1220] border border-[#1a1f37] rounded-xl p-6">
              <TradingViewChart
                ticker={aktie.ticker}
                name={aktie.name}
                currentPrice={aktie.currentPrice}
                fiftyTwoWeekHigh={aktie.fiftyTwoWeekHigh}
                fiftyTwoWeekLow={aktie.fiftyTwoWeekLow}
              />
            </div>
          ))}
        </div>
      </main>
    </div>
  );
}