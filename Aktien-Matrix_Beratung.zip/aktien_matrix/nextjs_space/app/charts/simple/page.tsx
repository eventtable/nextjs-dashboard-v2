'use client';

import { useState } from 'react';
import { LineChart, Line, XAxis, YAxis, ResponsiveContainer } from 'recharts';
import SharedHeader from '@/components/shared-header';

// Test-Daten OHNE null-Werte
const testData = [
  { day: '1', price: 100, ema: 100 },
  { day: '2', price: 105, ema: 101 },
  { day: '3', price: 98, ema: 100.2 },
  { day: '4', price: 110, ema: 102.16 },
  { day: '5', price: 115, ema: 104.73 },
  { day: '6', price: 108, ema: 105.38 },
  { day: '7', price: 120, ema: 108.31 },
  { day: '8', price: 125, ema: 111.65 },
  { day: '9', price: 118, ema: 112.92 },
  { day: '10', price: 130, ema: 116.33 },
  { day: '11', price: 135, ema: 120.07 },
  { day: '12', price: 128, ema: 121.65 },
  { day: '13', price: 140, ema: 125.32 },
  { day: '14', price: 145, ema: 129.26 },
  { day: '15', price: 138, ema: 131.01 },
];

export default function SimpleChartTest() {
  const [showEMA, setShowEMA] = useState(true);

  return (
    <div className="min-h-screen bg-[#0a0e1a] text-white">
      <SharedHeader />
      
      <main className="pt-24 pb-12 px-4 max-w-4xl mx-auto">
        <h1 className="text-2xl font-bold mb-6">TEST: EMA ohne null-Werte</h1>
        
        <button 
          onClick={() => setShowEMA(!showEMA)}
          className={`mb-4 px-4 py-2 rounded font-bold ${showEMA ? 'bg-red-500' : 'bg-gray-600'}`}
        >
          {showEMA ? 'EMA AUS' : 'EMA AN'}
        </button>

        <div className="bg-[#1a1f37] p-4 rounded-lg">
          <div style={{ height: 300 }}>
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={testData} margin={{ top: 20, right: 30, left: 20, bottom: 20 }}>
                <XAxis dataKey="day" tick={{ fill: '#888' }} />
                <YAxis tick={{ fill: '#888' }} />
                
                {/* EMA LINIE - DICK UND ROT */}
                {showEMA && (
                  <Line 
                    type="monotone" 
                    dataKey="ema" 
                    stroke="#ff0000" 
                    strokeWidth={5}
                    dot={{ r: 4, fill: '#ff0000' }}
                  />
                )}
                
                {/* HAUPT-PREIS - WEISS */}
                <Line 
                  type="monotone" 
                  dataKey="price" 
                  stroke="#ffffff" 
                  strokeWidth={2}
                  dot={{ r: 3, fill: '#fff' }}
                />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>
        
        <div className="mt-6 p-4 bg-[#1a1f37] rounded text-sm">
          <p className="text-yellow-400 font-bold mb-2">Was du sehen solltest:</p>
          <ul className="list-disc list-inside space-y-1 text-gray-300">
            <li>🔴 ROTE dicke Linie = EMA (etwas tiefer als Preis)</li>
            <li>⚪ Weiße Linie = Preis (oben)</li>
            <li>Zwei getrennte Linien!</li>
          </ul>
          <p className="mt-4 text-white">Status: EMA ist {showEMA ? 'EINGESCHALTET' : 'AUSGESCHALTET'}</p>
        </div>
      </main>
    </div>
  );
}