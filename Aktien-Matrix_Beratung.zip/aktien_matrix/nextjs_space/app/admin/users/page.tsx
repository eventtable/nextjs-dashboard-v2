'use client';

import { useState, useEffect } from 'react';
import { useSession } from 'next-auth/react';
import { useRouter } from 'next/navigation';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Users, Shield, Loader2 } from 'lucide-react';

interface User {
  id: string;
  email: string;
  name: string | null;
  isAdmin: boolean;
  isActive: boolean;
  createdAt: string;
}

export default function AdminUsersPage() {
  const { data: session, status } = useSession();
  const router = useRouter();
  const [users, setUsers] = useState<User[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (status === 'unauthenticated') {
      router.push('/login');
      return;
    }
    if (status === 'authenticated') {
      fetchUsers();
    }
  }, [status]);

  const fetchUsers = async () => {
    setLoading(true);
    try {
      const res = await fetch('/api/admin/users');
      if (res.ok) {
        const data = await res.json();
        setUsers(data.users || []);
      } else if (res.status === 401 || res.status === 403) {
        router.push('/login');
      }
    } catch (e) {
      console.error('Fehler beim Laden der User:', e);
    }
    setLoading(false);
  };

  if (status === 'loading' || loading) {
    return (
      <div className="min-h-screen bg-[#0a0e1a] p-6 flex items-center justify-center">
        <Loader2 className="w-8 h-8 animate-spin text-[#f0b90b]" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#0a0e1a] p-6">
      <h1 className="text-3xl font-bold text-white mb-8 flex items-center gap-3">
        <Users className="w-8 h-8 text-[#f0b90b]" />
        User-\u00dcbersicht ({users.length})
      </h1>
      
      <div className="grid gap-4">
        {users.map((user) => (
          <Card key={user.id} className="bg-[#131722] border-gray-700/50">
            <CardContent className="p-4 flex justify-between items-center">
              <div>
                <p className="font-semibold text-white">{user.name || user.email}</p>
                <p className="text-sm text-gray-400">{user.email}</p>
                <p className="text-xs text-gray-500">
                  {user.isAdmin ? 'Admin' : 'User'} \u2022 {new Date(user.createdAt).toLocaleDateString('de-DE')}
                  {!user.isActive && <span className="ml-2 text-red-400">(Deaktiviert)</span>}
                </p>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
}
