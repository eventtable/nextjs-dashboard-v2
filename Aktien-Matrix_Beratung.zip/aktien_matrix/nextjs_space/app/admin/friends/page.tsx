"use client";

import { useState, useEffect } from "react";
import { useSession } from "next-auth/react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import { 
  Users, 
  Plus, 
  Trash2, 
  Copy, 
  CheckCircle2, 
  XCircle,
  UserCog,
  Key,
  Download,
  AlertTriangle
} from "lucide-react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";

interface Friend {
  id: string;
  email: string;
  name: string;
  inviteCode: string;
  createdAt: string;
  isActive: boolean;
  permissions: {
    canViewDepot: boolean;
    canViewTrading: boolean;
    canViewML: boolean;
    canEdit: boolean;
  };
}

interface InviteCode {
  code: string;
  usedBy: string | null;
  createdAt: string;
  permissions: {
    canViewDepot: boolean;
    canViewTrading: boolean;
    canViewML: boolean;
    canEdit: boolean;
  };
}

export default function FriendsManagementPage() {
  const { data: session } = useSession();
  const [friends, setFriends] = useState<Friend[]>([]);
  const [inviteCodes, setInviteCodes] = useState<InviteCode[]>([]);
  const [loading, setLoading] = useState(true);
  const [adminEmail, setAdminEmail] = useState("");
  const [adminPassword, setAdminPassword] = useState("");
  const [showAuth, setShowAuth] = useState(true);
  const [copiedCode, setCopiedCode] = useState<string | null>(null);
  
  // New friend form
  const [newFriend, setNewFriend] = useState({
    email: "",
    name: "",
    password: "",
    permissions: {
      canViewDepot: true,
      canViewTrading: true,
      canViewML: false,
      canEdit: false
    }
  });

  const [exportData, setExportData] = useState("");
  const [showExport, setShowExport] = useState(false);

  // Load friends data
  const loadData = async () => {
    if (!adminEmail || !adminPassword) return;
    
    try {
      setLoading(true);
      const res = await fetch(`/api/friends?email=${encodeURIComponent(adminEmail)}&password=${encodeURIComponent(adminPassword)}`);
      if (res.ok) {
        const data = await res.json();
        setFriends(data.friends || []);
        setInviteCodes(data.inviteCodes || []);
        setShowAuth(false);
      }
    } catch (e) {
      console.error("Error loading friends:", e);
    } finally {
      setLoading(false);
    }
  };

  const exportFriendsData = () => {
    const data = { friends, inviteCodes };
    const compact = JSON.stringify(data);
    setExportData(compact);
    setShowExport(true);
  };

  const copyExportData = () => {
    navigator.clipboard.writeText(exportData);
    setCopiedCode('EXPORT');
    setTimeout(() => setCopiedCode(null), 2000);
  };
  const createInviteCode = async () => {
    try {
      const res = await fetch("/api/friends", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          email: adminEmail,
          password: adminPassword,
          action: "create_invite",
          permissions: {
            canViewDepot: true,
            canViewTrading: true,
            canViewML: false,
            canEdit: false
          }
        })
      });
      
      if (res.ok) {
        loadData();
      }
    } catch (e) {
      console.error("Error creating invite:", e);
    }
  };

  // Add friend directly
  const addFriend = async (e: React.FormEvent) => {
    e.preventDefault();
    
    try {
      const res = await fetch("/api/friends", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          email: adminEmail,
          password: adminPassword,
          action: "add_friend",
          friendEmail: newFriend.email,
          name: newFriend.name,
          friendPassword: newFriend.password,
          permissions: newFriend.permissions
        })
      });
      
      if (res.ok) {
        setNewFriend({
          email: "",
          name: "",
          password: "",
          permissions: {
            canViewDepot: true,
            canViewTrading: true,
            canViewML: false,
            canEdit: false
          }
        });
        loadData();
      }
    } catch (e) {
      console.error("Error adding friend:", e);
    }
  };

  // Toggle friend active status
  const toggleFriend = async (friendId: string, isActive: boolean) => {
    try {
      const res = await fetch("/api/friends", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          email: adminEmail,
          password: adminPassword,
          action: isActive ? "deactivate_friend" : "reactivate_friend",
          friendId
        })
      });
      
      if (res.ok) {
        loadData();
      }
    } catch (e) {
      console.error("Error toggling friend:", e);
    }
  };

  // Delete friend
  const deleteFriend = async (friendId: string) => {
    if (!confirm("Freund wirklich löschen?")) return;
    
    try {
      const res = await fetch(`/api/friends?email=${encodeURIComponent(adminEmail)}&password=${encodeURIComponent(adminPassword)}&friendId=${friendId}`, {
        method: "DELETE"
      });
      
      if (res.ok) {
        loadData();
      }
    } catch (e) {
      console.error("Error deleting friend:", e);
    }
  };

  // Copy code to clipboard
  const copyCode = (code: string) => {
    navigator.clipboard.writeText(code);
    setCopiedCode(code);
    setTimeout(() => setCopiedCode(null), 2000);
  };

  // Auth check first
  if (showAuth) {
    return (
      <div className="min-h-screen bg-[#0a0e1a] p-6">
        <Card className="max-w-md mx-auto bg-[#131722] border-gray-700/50">
          <CardHeader>
            <CardTitle className="text-xl font-bold text-white flex items-center gap-2">
              <UserCog className="w-5 h-5" />
              Admin Login
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div>
                <Label>Admin E-Mail</Label>
                <Input
                  type="email"
                  value={adminEmail}
                  onChange={(e) => setAdminEmail(e.target.value)}
                  className="bg-[#1a1f2e] border-gray-600 text-white"
                  placeholder="frank@dashboard.local"
                />
              </div>
              <div>
                <Label>Admin Passwort</Label>
                <Input
                  type="password"
                  value={adminPassword}
                  onChange={(e) => setAdminPassword(e.target.value)}
                  className="bg-[#1a1f2e] border-gray-600 text-white"
                  placeholder="••••••••"
                />
              </div>
              <Button 
                onClick={loadData}
                className="w-full bg-emerald-500 hover:bg-emerald-600"
              >
                Einloggen
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#0a0e1a] p-6">
      <div className="max-w-7xl mx-auto">
        <h1 className="text-3xl font-bold text-white mb-8 flex items-center gap-3">
          <Users className="w-8 h-8" />
          Freunde Verwaltung
          <Dialog open={showExport} onOpenChange={setShowExport}>
            <DialogTrigger asChild>
              <Button 
                variant="outline" 
                size="sm"
                onClick={exportFriendsData}
                className="ml-auto bg-amber-500/20 border-amber-500/50 text-amber-400 hover:bg-amber-500/30"
              >
                <Download className="w-4 h-4 mr-2" />
                Export für Vercel
              </Button>
            </DialogTrigger>
            <DialogContent className="bg-[#131722] border-gray-700 max-w-2xl">
              <DialogHeader>
                <DialogTitle className="text-white flex items-center gap-2">
                  <AlertTriangle className="w-5 h-5 text-amber-400" />
                  FRIENDS_DATA Environment Variable
                </DialogTitle>
              </DialogHeader>
              <div className="space-y-4">
                <p className="text-gray-400 text-sm">
                  Kopiere diesen Wert und füge ihn in deine Vercel Environment Variables ein:
                </p>
                <div className="bg-gray-900 p-4 rounded-lg overflow-auto max-h-40">
                  <code className="text-xs text-emerald-400 break-all">{exportData}</code>
                </div>
                <div className="bg-amber-500/10 border border-amber-500/30 p-4 rounded-lg">
                  <p className="text-amber-400 text-sm">
                    <strong>⚠️ Wichtig:</strong> Ohne diesen Schritt gehen die Daten beim nächsten Deploy verloren!
                  </p>
                  <ol className="text-gray-400 text-xs mt-2 list-decimal list-inside space-y-1">
                    <li>Gehe zu Vercel Dashboard → Project Settings → Environment Variables</li>
                    <li>Name: <code className="text-white">FRIENDS_DATA</code></li>
                    <li>Value: Den obigen Wert kopieren</li>
                    <li>"Save" klicken und neu deployen</li>
                  </ol>
                </div>
                <Button 
                  onClick={copyExportData}
                  className="w-full bg-emerald-500 hover:bg-emerald-600"
                >
                  {copiedCode === 'EXPORT' ? (
                    <><CheckCircle2 className="w-4 h-4 mr-2" /> Kopiert!</>
                  ) : (
                    <><Copy className="w-4 h-4 mr-2" /> In Zwischenablage kopieren</>
                  )}
                </Button>
              </div>
            </DialogContent>
          </Dialog>
        </h1>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Invite Codes */}
          <Card className="bg-[#131722] border-gray-700/50">
            <CardHeader>
              <CardTitle className="text-xl font-bold text-white flex items-center gap-2">
                <Key className="w-5 h-5" />
                Invite Codes
                <Button 
                  onClick={createInviteCode}
                  size="sm"
                  className="ml-auto bg-emerald-500 hover:bg-emerald-600"
                >
                  <Plus className="w-4 h-4 mr-1" />
                  Neu
                </Button>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {inviteCodes.map((code) => (
                  <div 
                    key={code.code}
                    className={`p-3 rounded-lg border ${
                      code.usedBy 
                        ? 'bg-gray-800/30 border-gray-700' 
                        : 'bg-emerald-500/10 border-emerald-500/30'
                    }`}
                  >
                    <div className="flex items-center justify-between">
                      <div className="font-mono text-lg text-white">{code.code}</div>
                      {!code.usedBy && (
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => copyCode(code.code)}
                          className="text-emerald-400 hover:text-emerald-300"
                        >
                          {copiedCode === code.code ? (
                            <CheckCircle2 className="w-4 h-4" />
                          ) : (
                            <Copy className="w-4 h-4" />
                          )}
                        </Button>
                      )}
                    </div>
                    <div className="text-sm text-gray-400 mt-1">
                      {code.usedBy ? (
                        <span>Verwendet von: {code.usedBy}</span>
                      ) : (
                        <span className="text-emerald-400">✓ Verfügbar</span>
                      )}
                    </div>
                    
                    <div className="flex gap-2 mt-2 text-xs">
                      {code.permissions.canViewDepot && <span className="px-2 py-1 bg-blue-500/20 rounded">Depot</span>}
                      {code.permissions.canViewTrading && <span className="px-2 py-1 bg-emerald-500/20 rounded">Trading</span>}
                      {code.permissions.canViewML && <span className="px-2 py-1 bg-purple-500/20 rounded">ML</span>}
                    </div>
                  </div>
                ))}
                {inviteCodes.length === 0 && (
                  <p className="text-gray-500 text-center py-4">Keine Invite Codes</p>
                )}
              </div>
            </CardContent>
          </Card>

          {/* Add Friend Form */}
          <Card className="bg-[#131722] border-gray-700/50">
            <CardHeader>
              <CardTitle className="text-xl font-bold text-white flex items-center gap-2">
                <UserCog className="w-5 h-5" />
                Freund hinzufügen
              </CardTitle>
            </CardHeader>
            <CardContent>
              <form onSubmit={addFriend} className="space-y-4">
                <div>
                  <Label>Name</Label>
                  <Input
                    value={newFriend.name}
                    onChange={(e) => setNewFriend(p => ({ ...p, name: e.target.value }))}
                    className="bg-[#1a1f2e] border-gray-600 text-white"
                    placeholder="Max Mustermann"
                    required
                  />
                </div>
                
                <div>
                  <Label>E-Mail</Label>
                  <Input
                    type="email"
                    value={newFriend.email}
                    onChange={(e) => setNewFriend(p => ({ ...p, email: e.target.value }))}
                    className="bg-[#1a1f2e] border-gray-600 text-white"
                    placeholder="max@beispiel.de"
                    required
                  />
                </div>
                
                <div>
                  <Label>Passwort</Label>
                  <Input
                    type="password"
                    value={newFriend.password}
                    onChange={(e) => setNewFriend(p => ({ ...p, password: e.target.value }))}
                    className="bg-[#1a1f2e] border-gray-600 text-white"
                    placeholder="••••••••"
                    required
                  />
                </div>

                <div className="space-y-2">
                  <Label>Berechtigungen</Label>
                  <div className="flex items-center gap-2">
                    <Checkbox
                      checked={newFriend.permissions.canViewDepot}
                      onCheckedChange={(c) => 
                        setNewFriend(p => ({ ...p, permissions: { ...p.permissions, canViewDepot: c as boolean } }))
                      }
                    />
                    <span className="text-gray-300 text-sm">Depot ansehen</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Checkbox
                      checked={newFriend.permissions.canViewTrading}
                      onCheckedChange={(c) => 
                        setNewFriend(p => ({ ...p, permissions: { ...p.permissions, canViewTrading: c as boolean } }))
                      }
                    />
                    <span className="text-gray-300 text-sm">Trading Signale</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Checkbox
                      checked={newFriend.permissions.canViewML}
                      onCheckedChange={(c) => 
                        setNewFriend(p => ({ ...p, permissions: { ...p.permissions, canViewML: c as boolean } }))
                      }
                    />
                    <span className="text-gray-300 text-sm">ML Performance</span>
                  </div>
                </div>

                <Button type="submit" className="w-full bg-emerald-500 hover:bg-emerald-600">
                  <Plus className="w-4 h-4 mr-1" />
                  Freund hinzufügen
                </Button>
              </form>
            </CardContent>
          </Card>
        </div>

        {/* Friends List */}
        <Card className="mt-6 bg-[#131722] border-gray-700/50">
          <CardHeader>
            <CardTitle className="text-xl font-bold text-white">
              Aktive Freunde ({friends.length})
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {friends.map((friend) => (
                <div 
                  key={friend.id}
                  className={`p-4 rounded-lg border ${
                    friend.isActive 
                      ? 'bg-emerald-500/10 border-emerald-500/30' 
                      : 'bg-gray-800/30 border-gray-700'
                  }`}
                >
                  <div className="flex items-start justify-between">
                    <div>
                      <div className="font-bold text-white">{friend.name}</div>
                      <div className="text-sm text-gray-400">{friend.email}</div>
                      <div className="text-xs text-gray-500 mt-1">
                        Seit: {friend.createdAt}
                      </div>
                    </div>
                    
                    <div className="flex gap-2">
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => toggleFriend(friend.id, friend.isActive)}
                        className={friend.isActive ? "text-yellow-400" : "text-emerald-400"}
                      >
                        {friend.isActive ? <XCircle className="w-4 h-4" /> : <CheckCircle2 className="w-4 h-4" />}
                      </Button>
                      
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => deleteFriend(friend.id)}
                        className="text-red-400"
                      >
                        <Trash2 className="w-4 h-4" />
                      </Button>
                    </div>
                  </div>
                  
                  <div className="flex flex-wrap gap-1 mt-3">
                    {friend.permissions.canViewDepot && <span className="px-2 py-0.5 bg-blue-500/20 rounded text-xs">Depot</span>}
                    {friend.permissions.canViewTrading && <span className="px-2 py-0.5 bg-emerald-500/20 rounded text-xs">Trading</span>}
                    {friend.permissions.canViewML && <span className="px-2 py-0.5 bg-purple-500/20 rounded text-xs">ML</span>}
                    {!friend.isActive && <span className="px-2 py-0.5 bg-red-500/20 rounded text-xs">Deaktiviert</span>}
                  </div>
                </div>
              ))}
              {friends.length === 0 && (
                <p className="text-gray-500 text-center py-4">Noch keine Freunde hinzugefügt</p>
              )}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}