export default function AdminPage() {
  return (
    <div className="min-h-screen bg-[#0a0e1a] text-white p-8">
      <h1 className="text-3xl font-bold mb-6">Admin Dashboard</h1>
      <p className="text-gray-400 mb-4">Wähle einen Bereich:</p>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <a 
          href="/admin/friends-manual" 
          className="glass-card p-6 rounded-xl border border-[#1a1f37] hover:border-[#f0b90b]/50 transition-all"
        >
          <h2 className="text-xl font-semibold mb-2">👥 Freunde Verwalten</h2>
          <p className="text-gray-400">Invite Codes und Registrierungen verwalten</p>
        </a>
        
        <a 
          href="/ai-trading" 
          className="glass-card p-6 rounded-xl border border-[#1a1f37] hover:border-[#f0b90b]/50 transition-all"
        >
          <h2 className="text-xl font-semibold mb-2">🤖 AI Trading</h2>
          <p className="text-gray-400">Trading Signale und ML Performance</p>
        </a>
      </div>
      
      <div className="mt-8 p-6 bg-[#131722] rounded-xl border border-[#1a1f37]">
        <h2 className="text-xl font-semibold mb-4">📋 Verfügbare Invite Codes</h2>
        <div className="grid grid-cols-2 md:grid-cols-5 gap-3">
          {[
            'FRIEND-001-ALPHA', 'FRIEND-002-BETA', 'FRIEND-003-GAMMA',
            'FRIEND-004-DELTA', 'FRIEND-005-ECHO', 'FRIEND-006-FOXTROT',
            'FRIEND-007-GOLF', 'FRIEND-008-HOTEL', 'FRIEND-009-INDIA',
            'FRIEND-010-JULIET'
          ].map(code => (
            <div key={code} className="bg-[#0d1220] p-3 rounded-lg text-center font-mono text-sm">
              {code}
            </div>
          ))}
        </div>
        <p className="text-gray-400 mt-4 text-sm">... und 40 weitere Codes verfügbar</p>
      </div>
    </div>
  );
}
