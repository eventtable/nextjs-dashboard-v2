'use client'

import { useState, useEffect } from 'react'

export default function AdminInvitesPage() {
  const [invites, setInvites] = useState<any[]>([])
  const [newCode, setNewCode] = useState('')
  const [maxUses, setMaxUses] = useState(5)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')
  const [copied, setCopied] = useState('')

  useEffect(() => {
    fetchInvites()
  }, [])

  const fetchInvites = async () => {
    const res = await fetch('/api/admin/invites')
    const data = await res.json()
    setInvites(data)
  }

  const createInvite = async (unlimited = false) => {
    setLoading(true)
    setError('')

    try {
      const res = await fetch('/api/admin/invites', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ maxUses: unlimited ? null : maxUses })
      })

      const data = await res.json()

      if (!res.ok) {
        throw new Error(data.error)
      }

      setNewCode(data.code)
      fetchInvites()
    } catch (err: any) {
      setError(err.message)
    } finally {
      setLoading(false)
    }
  }

  const toggleActive = async (id: string, current: boolean) => {
    await fetch('/api/admin/invites', {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ id, isActive: !current })
    })
    fetchInvites()
  }

  const copyToClipboard = (code: string) => {
    navigator.clipboard.writeText(`${window.location.origin}/register?invite=${code}`)
    setCopied(code)
    setTimeout(() => setCopied(''), 2000)
  }

  return (
    <div className="min-h-screen bg-[#0a0e1a] text-white p-8">
      <h1 className="text-3xl font-bold mb-8">Admin: Invite-Codes</h1>

      <div className="bg-[#1a1f37] rounded-xl p-6 border border-[#2a2f47] mb-8">
        <h2 className="text-xl font-semibold mb-4">Neuen Invite-Code erstellen</h2>

        {error && (
          <div className="bg-red-500/20 border border-red-500/30 text-red-400 px-4 py-3 rounded-lg mb-4">{error}</div>
        )}

        {newCode && (
          <div className="bg-emerald-500/20 border border-emerald-500/30 text-emerald-400 px-4 py-3 rounded-lg mb-4">
            <p>Neuer Code erstellt: <strong>{newCode}</strong></p>
            <p className="text-sm mt-1">Link: {window.location.origin}/register?invite={newCode}</p>
          </div>
        )}

        <div className="flex items-center gap-4 mb-4">
          <div>
            <label className="block text-gray-400 mb-2">Max. Nutzungen</label>
            <input
              type="number"
              value={maxUses}
              onChange={(e) => setMaxUses(parseInt(e.target.value))}
              min={1}
              max={100}
              className="bg-[#0a0e1a] border border-[#2a2f47] rounded-lg px-4 py-2 text-white"
            />
          </div>
        </div>

        <div className="flex gap-3">
          <button
            onClick={() => createInvite(false)}
            disabled={loading}
            className="bg-[#f0b90b] hover:bg-[#d4a009] text-black font-semibold px-6 py-3 rounded-lg transition-colors disabled:opacity-50"
          >
            {loading ? 'Wird erstellt...' : 'Code erstellen'}
          </button>
          
          <button
            onClick={() => createInvite(true)}
            disabled={loading}
            className="bg-emerald-600 hover:bg-emerald-700 text-white font-semibold px-6 py-3 rounded-lg transition-colors disabled:opacity-50"
          >
            {loading ? 'Wird erstellt...' : 'Unbegrenzter Code'}
          </button>
        </div>
      </div>

      <div className="bg-[#1a1f37] rounded-xl p-6 border border-[#2a2f47]">
        <h2 className="text-xl font-semibold mb-4">Aktive Codes</h2>

        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="border-b border-[#2a2f47]">
                <th className="text-left py-3 text-gray-400">Code</th>
                <th className="text-left py-3 text-gray-400">Verwendet</th>
                <th className="text-left py-3 text-gray-400">Max</th>
                <th className="text-left py-3 text-gray-400">Status</th>
                <th className="text-left py-3 text-gray-400">Aktionen</th>
              </tr>
            </thead>
            <tbody>
              {invites.map((invite) => (
                <tr key={invite.id} className="border-b border-[#2a2f47]/50">
                  <td className="py-3 font-mono">{invite.code}</td>
                  <td className="py-3">{invite.usedCount}</td>
                  <td className="py-3">{invite.maxUses === null ? '∞' : invite.maxUses}</td>
                  <td className="py-3">
                    <span className={`px-2 py-1 rounded text-sm ${invite.isActive ? 'bg-emerald-500/20 text-emerald-400' : 'bg-red-500/20 text-red-400'}`}>
                      {invite.isActive ? 'Aktiv' : 'Deaktiviert'}
                    </span>
                  </td>
                  <td className="py-3">
                    <div className="flex gap-2">
                      <button
                        onClick={() => copyToClipboard(invite.code)}
                        className="text-sm text-[#f0b90b] hover:underline"
                      >
                        {copied === invite.code ? 'Kopiert!' : 'Kopieren'}
                      </button>
                      <button
                        onClick={() => toggleActive(invite.id, invite.isActive)}
                        className="text-sm text-gray-400 hover:text-white"
                      >
                        {invite.isActive ? 'Deaktivieren' : 'Aktivieren'}
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  )
}
