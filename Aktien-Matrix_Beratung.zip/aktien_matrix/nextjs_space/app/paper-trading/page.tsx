'use client';

import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { 
  DollarSign, 
  TrendingUp, 
  TrendingDown, 
  Wallet,
  History,
  Target,
  ArrowLeft,
  Bot,
  Activity,
  Brain
} from 'lucide-react';
import Link from 'next/link';
import SharedHeader from '@/components/shared-header';
import { depotPositionen } from '@/data/depot';
import { berechneNachkaufEmpfehlungen } from '@/data/empfehlungen';

interface VirtualPosition {
  ticker: string;
  name: string;
  buyPrice: number;
  currentPrice: number;
  shares: number;
  buyDate: string;
  type: 'long' | 'short';
}

interface Trade {
  id: string;
  ticker: string;
  name: string;
  type: 'buy' | 'sell' | 'short' | 'cover';
  price: number;
  shares: number;
  date: string;
  reason: string;
}

interface AutoTradeSettings {
  enabled: boolean;
  minScore: number;
  maxTradesPerDay: number;
  positionSize: number;
  stopLoss: number;
  takeProfit: number;
  allowShort: boolean;
  shortThreshold: number; // Score unter dem geshortet wird
}

export default function PaperTradingPage() {
  const [cash, setCash] = useState(10000);
  const [positions, setPositions] = useState<VirtualPosition[]>([]);
  const [trades, setTrades] = useState<Trade[]>([]);
  const [selectedStock, setSelectedStock] = useState<string>('');
  
  // Auto-Trade Settings
  const [autoTrade, setAutoTrade] = useState<AutoTradeSettings>({
    enabled: false,
    minScore: 60,
    maxTradesPerDay: 3,
    positionSize: 20,
    stopLoss: 10,
    takeProfit: 20,
    allowShort: true,
    shortThreshold: 35
  });
  
  const [dailyTrades, setDailyTrades] = useState(0);
  const [lastTradeDate, setLastTradeDate] = useState('');
  const [autoTradeLog, setAutoTradeLog] = useState<string[]>([]);

  // Load from localStorage on mount
  useEffect(() => {
    const savedCash = localStorage.getItem('paperTrading_cash');
    const savedPositions = localStorage.getItem('paperTrading_positions');
    const savedTrades = localStorage.getItem('paperTrading_trades');
    const savedAutoTrade = localStorage.getItem('paperTrading_autotrade');
    const savedDailyTrades = localStorage.getItem('paperTrading_dailytrades');
    const savedLastDate = localStorage.getItem('paperTrading_lastdate');
    
    if (savedCash) setCash(parseFloat(savedCash));
    if (savedPositions) setPositions(JSON.parse(savedPositions));
    if (savedTrades) setTrades(JSON.parse(savedTrades));
    if (savedAutoTrade) setAutoTrade(JSON.parse(savedAutoTrade));
    if (savedDailyTrades) setDailyTrades(parseInt(savedDailyTrades));
    if (savedLastDate) setLastTradeDate(savedLastDate);
    
    // Reset daily counter if new day
    const today = new Date().toISOString().split('T')[0];
    if (savedLastDate !== today) {
      setDailyTrades(0);
      setLastTradeDate(today);
      localStorage.setItem('paperTrading_dailytrades', '0');
      localStorage.setItem('paperTrading_lastdate', today);
    }
  }, []);

  // Save to localStorage
  useEffect(() => {
    localStorage.setItem('paperTrading_cash', cash.toString());
    localStorage.setItem('paperTrading_positions', JSON.stringify(positions));
    localStorage.setItem('paperTrading_trades', JSON.stringify(trades));
    localStorage.setItem('paperTrading_autotrade', JSON.stringify(autoTrade));
    localStorage.setItem('paperTrading_dailytrades', dailyTrades.toString());
    localStorage.setItem('paperTrading_lastdate', lastTradeDate);
  }, [cash, positions, trades, autoTrade, dailyTrades, lastTradeDate]);

  // Preis-Aktualisierung alle 60 Sekunden + Stop-Loss/Take-Profit Überwachung
  useEffect(() => {
    const updatePricesAndCheckStops = () => {
      if (positions.length === 0) return;

      const updatedPositions = positions.map(pos => {
        // Simuliere Preis-Update (in echt: API-Aufruf)
        const priceChange = (Math.random() - 0.5) * 0.02; // ±1% Schwankung
        const newPrice = pos.currentPrice * (1 + priceChange);
        
        return { ...pos, currentPrice: newPrice };
      });

      setPositions(updatedPositions);

      // Stop-Loss / Take-Profit Überprüfung
      updatedPositions.forEach((pos, index) => {
        const perfPercent = pos.type === 'long'
          ? ((pos.currentPrice - pos.buyPrice) / pos.buyPrice) * 100
          : ((pos.buyPrice - pos.currentPrice) / pos.buyPrice) * 100;

        // Stop-Loss erreicht
        if (perfPercent <= -autoTrade.stopLoss) {
          handleExit(index, pos, `Stop-Loss erreicht (-${autoTrade.stopLoss}%)`);
        }
        // Take-Profit erreicht
        else if (perfPercent >= autoTrade.takeProfit) {
          handleExit(index, pos, `Take-Profit erreicht (+${autoTrade.takeProfit}%)`);
        }
      });
    };

    const interval = setInterval(updatePricesAndCheckStops, 60000); // Jede Minute
    return () => clearInterval(interval);
  }, [positions, autoTrade.stopLoss, autoTrade.takeProfit]);

  // Position schließen (Exit)
  const handleExit = (index: number, pos: VirtualPosition, reason: string) => {
    const exitPrice = pos.currentPrice;
    const pnl = pos.type === 'long'
      ? (exitPrice - pos.buyPrice) * pos.shares
      : (pos.buyPrice - exitPrice) * pos.shares;

    const exitTrade: Trade = {
      id: Date.now().toString(),
      ticker: pos.ticker,
      name: pos.name,
      type: pos.type === 'long' ? 'sell' : 'cover',
      price: exitPrice,
      shares: pos.shares,
      date: new Date().toISOString().split('T')[0],
      reason: reason
    };

    setCash(cash + (pos.type === 'long' 
      ? pos.shares * exitPrice 
      : pos.shares * pos.buyPrice + pnl)); // Short: zurückzahlen + Gewinn
    setPositions(positions.filter((_, i) => i !== index));
    setTrades([exitTrade, ...trades]);
  };

  const empf = berechneNachkaufEmpfehlungen(depotPositionen);
  const totalValue = positions.reduce((sum, pos) => sum + (pos.currentPrice * pos.shares), 0) + cash;
  const initialValue = 10000;
  const performance = ((totalValue - initialValue) / initialValue) * 100;

  const handleBuy = (ticker: string, name: string, price: number) => {
    const emp = empf.find(e => e.ticker === ticker);
    if (!emp || emp.empfehlung !== 'nachkaufen' && emp.empfehlung !== 'stark-nachkaufen') {
      alert('Matrix sagt: Noch nicht kaufen!');
      return;
    }

    const maxShares = Math.floor(cash / price);
    if (maxShares < 1) {
      alert('Nicht genug Cash!');
      return;
    }

    const shares = Math.min(maxShares, 10); // Max 10 shares per trade
    const cost = shares * price;

    const newPosition: VirtualPosition = {
      ticker,
      name,
      buyPrice: price,
      currentPrice: price,
      shares,
      buyDate: new Date().toISOString().split('T')[0],
      type: 'long'
    };

    const newTrade: Trade = {
      id: Date.now().toString(),
      ticker,
      name,
      type: 'buy',
      price,
      shares,
      date: new Date().toISOString().split('T')[0],
      reason: `Matrix: ${emp.empfehlung} (${emp.gesamtScore}/100)`
    };

    setCash(cash - cost);
    setPositions([...positions, newPosition]);
    setTrades([newTrade, ...trades]);
    setDailyTrades(dailyTrades + 1);
  };

  // Auto-Trade Logik
  const runAutoTrade = () => {
    if (!autoTrade.enabled) {
      alert('Auto-Trade ist deaktiviert!');
      return;
    }

    if (dailyTrades >= autoTrade.maxTradesPerDay) {
      alert(`Maximale Trades für heute erreicht (${autoTrade.maxTradesPerDay})`);
      return;
    }

    const log: string[] = [];
    const tradeAmount = cash * (autoTrade.positionSize / 100);
    
    // LONG: Kauf-Empfehlungen
    const longOpportunities = empf.filter(e => {
      if (e.empfehlung !== 'nachkaufen' && e.empfehlung !== 'stark-nachkaufen') return false;
      if (e.gesamtScore < autoTrade.minScore) return false;
      return !positions.find(p => p.ticker === e.ticker && p.type === 'long');
    });

    // SHORT: Verkaufs-Empfehlungen (wenn erlaubt)
    let shortOpportunities: any[] = [];
    if (autoTrade.allowShort) {
      shortOpportunities = empf.filter(e => {
        if (e.empfehlung !== 'verkaufen') return false;
        if (e.gesamtScore > autoTrade.shortThreshold) return false;
        return !positions.find(p => p.ticker === e.ticker && p.type === 'short');
      });
    }

    log.push(`📈 Long-Chancen: ${longOpportunities.length} (Score ≥${autoTrade.minScore})`);
    if (autoTrade.allowShort) {
      log.push(`📉 Short-Chancen: ${shortOpportunities.length} (Score ≤${autoTrade.shortThreshold})`);
    }

    if (longOpportunities.length === 0 && shortOpportunities.length === 0) {
      alert('Keine passenden Trading-Chancen gefunden!');
      return;
    }

    // Beste Gelegenheit finden
    let bestTrade: any = null;
    let tradeType: 'long' | 'short' = 'long';

    if (longOpportunities.length > 0) {
      const sortedLong = longOpportunities.sort((a, b) => b.gesamtScore - a.gesamtScore);
      bestTrade = sortedLong[0];
      tradeType = 'long';
    }

    // Prüfe ob Short besser ist (niedrigerer Score = besser für Short)
    if (shortOpportunities.length > 0) {
      const sortedShort = shortOpportunities.sort((a, b) => a.gesamtScore - b.gesamtScore);
      if (!bestTrade || sortedShort[0].gesamtScore < 30) {
        bestTrade = sortedShort[0];
        tradeType = 'short';
      }
    }

    if (!bestTrade) {
      alert('Keine passende Trade-Chance gefunden!');
      return;
    }

    const price = bestTrade.aktuellerKurs;
    const maxShares = Math.floor(tradeAmount / price);
    
    if (maxShares < 1) {
      alert('Nicht genug Cash für Auto-Trade!');
      return;
    }

    const shares = Math.min(maxShares, 10);

    if (tradeType === 'long') {
      // LONG Trade
      const cost = shares * price;
      const newPosition: VirtualPosition = {
        ticker: bestTrade.ticker,
        name: bestTrade.name,
        buyPrice: price,
        currentPrice: price,
        shares,
        buyDate: new Date().toISOString().split('T')[0],
        type: 'long'
      };

      const newTrade: Trade = {
        id: Date.now().toString(),
        ticker: bestTrade.ticker,
        name: bestTrade.name,
        type: 'buy',
        price,
        shares,
        date: new Date().toISOString().split('T')[0],
        reason: `🤖 Auto-Trade LONG: ${bestTrade.empfehlung} (Score: ${bestTrade.gesamtScore})`
      };

      setCash(cash - cost);
      setPositions([...positions, newPosition]);
      setTrades([newTrade, ...trades]);
      log.push(`✅ LONG: ${shares}x ${bestTrade.name} @ ${price}€`);
    } else {
      // SHORT Trade
      const newPosition: VirtualPosition = {
        ticker: bestTrade.ticker,
        name: bestTrade.name,
        buyPrice: price,
        currentPrice: price,
        shares,
        buyDate: new Date().toISOString().split('T')[0],
        type: 'short'
      };

      const newTrade: Trade = {
        id: Date.now().toString(),
        ticker: bestTrade.ticker,
        name: bestTrade.name,
        type: 'short',
        price,
        shares,
        date: new Date().toISOString().split('T')[0],
        reason: `🤖 Auto-Trade SHORT: ${bestTrade.empfehlung} (Score: ${bestTrade.gesamtScore})`
      };

      setPositions([...positions, newPosition]);
      setTrades([newTrade, ...trades]);
      log.push(`🔻 SHORT: ${shares}x ${bestTrade.name} @ ${price}€ (Leerverkauf)`);
    }
    
    setDailyTrades(dailyTrades + 1);
    setAutoTradeLog(log);
  };

  return (
    <div className="min-h-screen bg-[#0a0e1a] text-white">
      <SharedHeader />
      
      <main className="pt-24 pb-12 px-4 max-w-7xl mx-auto">
        <div className="flex items-center justify-between mb-6">
          <Link href="/" className="flex items-center gap-2 text-gray-400 hover:text-white">
            <ArrowLeft className="w-5 h-5" />
            <span>Zurück</span>
          </Link>
          
          <div className="flex items-center gap-4">
            <Link href="/ai-trading" className="flex items-center gap-2 text-purple-400 hover:text-purple-300">
              <Brain className="w-5 h-5" />
              <span>AI Agent →</span>
            </Link>
            <Link href="/backtest" className="flex items-center gap-2 text-[#f0b90b] hover:text-[#d4a009]">
              <Activity className="w-5 h-5" />
              <span>Backtesting Lab →</span>
            </Link>
          </div>
        </div>

        <h1 className="text-3xl font-bold mb-2 flex items-center gap-3">
          <Target className="w-8 h-8 text-[#f0b90b]" />
          Paper-Trading (Virtuelles Depot)
        </h1>
        <p className="text-gray-400 mb-8">
          Teste Matrix 2.0 Strategie mit 10.000€ virtuellem Guthaben
        </p>

        {/* Portfolio Overview */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-8">
          <div className="bg-emerald-500/10 border border-emerald-500/30 rounded-xl p-4">
            <div className="flex items-center gap-2 mb-2">
              <Wallet className="w-5 h-5 text-emerald-400" />
              <span className="text-emerald-400">Cash</span>
            </div>
            <p className="text-2xl font-bold">{cash.toFixed(2)}€</p>
          </div>

          <div className="bg-blue-500/10 border border-blue-500/30 rounded-xl p-4">
            <div className="flex items-center gap-2 mb-2">
              <DollarSign className="w-5 h-5 text-blue-400" />
              <span className="text-blue-400">Depotwert</span>
            </div>
            <p className="text-2xl font-bold">{totalValue.toFixed(2)}€</p>
          </div>

          <div className={`border rounded-xl p-4 ${performance >= 0 ? 'bg-emerald-500/10 border-emerald-500/30' : 'bg-red-500/10 border-red-500/30'}`}>
            <div className="flex items-center gap-2 mb-2">
              {performance >= 0 ? <TrendingUp className="w-5 h-5 text-emerald-400" /> : <TrendingDown className="w-5 h-5 text-red-400" />}
              <span className={performance >= 0 ? 'text-emerald-400' : 'text-red-400'}>Performance</span>
            </div>
            <p className={`text-2xl font-bold ${performance >= 0 ? 'text-emerald-400' : 'text-red-400'}`}>
              {performance >= 0 ? '+' : ''}{performance.toFixed(2)}%
            </p>
          </div>

          <div className="bg-purple-500/10 border border-purple-500/30 rounded-xl p-4">
            <div className="flex items-center gap-2 mb-2">
              <History className="w-5 h-5 text-purple-400" />
              <span className="text-purple-400">Trades</span>
            </div>
            <p className="text-2xl font-bold">{trades.length}</p>
          </div>

          <div className="bg-orange-500/10 border border-orange-500/30 rounded-xl p-4">
            <div className="flex items-center gap-2 mb-2">
              <span className="text-orange-400">Heute</span>
            </div>
            <p className="text-2xl font-bold">{dailyTrades}/{autoTrade.maxTradesPerDay}</p>
            <p className="text-xs text-gray-400">Trades/Tag</p>
          </div>
        </div>

        {/* Auto-Trade Settings */}
        <div className="glass-card rounded-xl p-6 border border-[#1a1f37] mb-8">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-xl font-semibold flex items-center gap-2">
              <Bot className="w-6 h-6 text-[#f0b90b]" />
              Auto-Trader
              <span className={`px-2 py-0.5 rounded text-sm ${autoTrade.enabled ? 'bg-emerald-500/20 text-emerald-400' : 'bg-gray-500/20 text-gray-400'}`}>
                {autoTrade.enabled ? 'AKTIV' : 'INAKTIV'}
              </span>
            </h2>
            <button
              onClick={() => setAutoTrade({...autoTrade, enabled: !autoTrade.enabled})}
              className={`px-4 py-2 rounded-lg transition-colors ${autoTrade.enabled ? 'bg-red-500 hover:bg-red-600' : 'bg-emerald-500 hover:bg-emerald-600'}`}
            >
              {autoTrade.enabled ? 'Deaktivieren' : 'Aktivieren'}
            </button>
          </div>

          {autoTrade.enabled && (
            <>
              <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-4">
                <div>
                  <label className="block text-gray-400 mb-2 text-sm">Min. Score</label>
                  <input
                    type="number"
                    value={autoTrade.minScore}
                    onChange={(e) => setAutoTrade({...autoTrade, minScore: parseInt(e.target.value)})}
                    min="40"
                    max="100"
                    className="w-full bg-[#0a0e1a] border border-[#2a2f47] rounded-lg px-4 py-2 text-white"
                  />
                </div>
                <div>
                  <label className="block text-gray-400 mb-2 text-sm">Max Trades/Tag</label>
                  <input
                    type="number"
                    value={autoTrade.maxTradesPerDay}
                    onChange={(e) => setAutoTrade({...autoTrade, maxTradesPerDay: parseInt(e.target.value)})}
                    min="1"
                    max="10"
                    className="w-full bg-[#0a0e1a] border border-[#2a2f47] rounded-lg px-4 py-2 text-white"
                  />
                </div>
                <div>
                  <label className="block text-gray-400 mb-2 text-sm">Positionsgröße (%)</label>
                  <input
                    type="number"
                    value={autoTrade.positionSize}
                    onChange={(e) => setAutoTrade({...autoTrade, positionSize: parseInt(e.target.value)})}
                    min="5"
                    max="50"
                    className="w-full bg-[#0a0e1a] border border-[#2a2f47] rounded-lg px-4 py-2 text-white"
                  />
                </div>
                <div>
                  <label className="block text-gray-400 mb-2 text-sm">Stop-Loss (%)</label>
                  <input
                    type="number"
                    value={autoTrade.stopLoss}
                    onChange={(e) => setAutoTrade({...autoTrade, stopLoss: parseInt(e.target.value)})}
                    min="5"
                    max="30"
                    className="w-full bg-[#0a0e1a] border border-[#2a2f47] rounded-lg px-4 py-2 text-white"
                  />
                </div>
              </div>

              <div className="flex items-center gap-4 mb-4 p-4 bg-[#0d1220] rounded-lg border border-[#2a2f47]">
                <input
                  type="checkbox"
                  id="allowShort"
                  checked={autoTrade.allowShort}
                  onChange={(e) => setAutoTrade({...autoTrade, allowShort: e.target.checked})}
                  className="w-5 h-5 accent-[#f0b90b]"
                />
                <label htmlFor="allowShort" className="text-gray-300 cursor-pointer">
                  <strong>Short-Trading erlauben</strong> (Leerverkäufe bei schlechten Scores)
                </label>
              </div>

              {autoTrade.allowShort && (
                <div className="bg-red-500/10 border border-red-500/30 rounded-lg p-4 mb-4">
                  <h3 className="text-red-400 font-semibold mb-2">🔻 Short-Trading Einstellungen</h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-gray-400 mb-2 text-sm">Short-Threshold (Score ≤)</label>
                      <input
                        type="number"
                        value={autoTrade.shortThreshold}
                        onChange={(e) => setAutoTrade({...autoTrade, shortThreshold: parseInt(e.target.value)})}
                        min="10"
                        max="50"
                        className="w-full bg-[#0a0e1a] border border-red-500/30 rounded-lg px-4 py-2 text-white"
                      />
                      <p className="text-xs text-gray-500 mt-1">Geshortet wird bei Score ≤ {autoTrade.shortThreshold}</p>
                    </div>
                    <div className="flex items-center">
                      <div className="text-sm text-gray-400">
                        <p>📉 Short bei: <span className="text-red-400">verkaufen</span> Empfehlung</p>
                        <p>💡 Profit wenn Kurs fällt</p>
                      </div>
                    </div>
                  </div>
                </div>
              )}

              <div className="flex gap-4">
                <button
                  onClick={runAutoTrade}
                  disabled={dailyTrades >= autoTrade.maxTradesPerDay}
                  className="bg-[#f0b90b] hover:bg-[#d4a009] text-black font-semibold px-6 py-3 rounded-lg transition-colors disabled:opacity-50"
                >
                  🚀 Auto-Trade jetzt ausführen
                </button>
                <p className="text-gray-400 text-sm self-center">
                  Kauft automatisch beste Chance (Long: Score ≥{autoTrade.minScore} | Short: Score ≤{autoTrade.shortThreshold})
                </p>
              </div>

              {autoTradeLog.length > 0 && (
                <div className="mt-4 bg-[#0d1220] rounded-lg p-4 border border-[#1a1f37]">
                  <h3 className="text-sm font-semibold mb-2">Letzter Auto-Trade:</h3>
                  {autoTradeLog.map((log, i) => (
                    <p key={i} className="text-sm text-gray-400">{log}</p>
                  ))}
                </div>
              )}
            </>
          )}
        </div>

        {/* Buy Section */}
        <div className="glass-card rounded-xl p-6 border border-[#1a1f37] mb-8">
          <h2 className="text-xl font-semibold mb-4">Neuen Trade ausführen</h2>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {empf.filter(e => e.empfehlung === 'nachkaufen' || e.empfehlung === 'stark-nachkaufen').map(emp => (
              <motion.div
                key={emp.ticker}
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                className="bg-[#0d1220] rounded-lg p-4 border border-emerald-500/30"
              >
                <div className="flex justify-between items-start mb-2">
                  <span className="font-semibold">{emp.name}</span>
                  <span className={`text-xs px-2 py-0.5 rounded ${emp.empfehlung === 'stark-nachkaufen' ? 'bg-red-500/20 text-red-400' : 'bg-emerald-500/20 text-emerald-400'}`}>
                    {emp.empfehlung === 'stark-nachkaufen' ? '🚀 STARK' : '🟢 KAUFEN'}
                  </span>
                </div>
                <div className="text-sm text-gray-400 mb-2">
                  Score: {emp.gesamtScore}/100 | {emp.abstandProzent.toFixed(1)}%
                </div>
                <div className="text-lg font-bold mb-3">
                  {emp.aktuellerKurs}€
                </div>
                <button
                  onClick={() => handleBuy(emp.ticker, emp.name, emp.aktuellerKurs)}
                  className="w-full bg-emerald-500 hover:bg-emerald-600 text-white py-2 rounded-lg transition-colors"
                >
                  Kaufen
                </button>
              </motion.div>
            ))}
          </div>

          {empf.filter(e => e.empfehlung === 'nachkaufen' || e.empfehlung === 'stark-nachkaufen').length === 0 && (
            <div className="text-center text-gray-500 py-8">
              Momentan keine Kauf-Empfehlungen. Warte auf bessere Einstiege...
            </div>
          )}
        </div>

        {/* Positions */}
        <div className="glass-card rounded-xl p-6 border border-[#1a1f37] mb-8">
          <h2 className="text-xl font-semibold mb-4">Aktuelle Positionen</h2>
          
          {positions.length === 0 ? (
            <div className="text-center text-gray-500 py-8">
              Noch keine Positionen. Starte mit einem Kauf oben!
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="border-b border-[#1a1f37]">
                    <th className="text-left py-2 text-gray-400">Name</th>
                    <th className="text-left py-2 text-gray-400">Typ</th>
                    <th className="text-right py-2 text-gray-400">Shares</th>
                    <th className="text-right py-2 text-gray-400">Buy-In</th>
                    <th className="text-right py-2 text-gray-400">Aktuell</th>
                    <th className="text-right py-2 text-gray-400">Performance</th>
                    <th className="text-right py-2 text-gray-400">Action</th>
                  </tr>
                </thead>
                <tbody>
                  {positions.map((pos, idx) => {
                    // Performance Berechnung: Long = normal, Short = invertiert
                    const perfPercent = pos.type === 'long' 
                      ? ((pos.currentPrice - pos.buyPrice) / pos.buyPrice) * 100
                      : ((pos.buyPrice - pos.currentPrice) / pos.buyPrice) * 100;
                    
                    return (
                      <tr key={idx} className="border-b border-[#1a1f37]/50">
                        <td className="py-3">{pos.name}</td>
                        <td className="py-3">
                          <span className={`text-xs px-2 py-0.5 rounded ${pos.type === 'long' ? 'bg-emerald-500/20 text-emerald-400' : 'bg-red-500/20 text-red-400'}`}>
                            {pos.type === 'long' ? '📈 LONG' : '🔻 SHORT'}
                          </span>
                        </td>
                        <td className="text-right">{pos.shares}</td>
                        <td className="text-right">{pos.buyPrice.toFixed(2)}€</td>
                        <td className="text-right">{pos.currentPrice.toFixed(2)}€</td>
                        <td className={`text-right ${perfPercent >= 0 ? 'text-emerald-400' : 'text-red-400'}`}>
                          {perfPercent >= 0 ? '+' : ''}{perfPercent.toFixed(1)}%
                        </td>
                        <td className="text-right py-2">
                          <button
                            onClick={() => handleExit(idx, pos, 'Manueller Exit')}
                            className={`text-xs px-3 py-1 rounded transition-colors ${
                              pos.type === 'long' 
                                ? 'bg-red-500/20 text-red-400 hover:bg-red-500/40' 
                                : 'bg-blue-500/20 text-blue-400 hover:bg-blue-500/40'
                            }`}
                          >
                            {pos.type === 'long' ? 'Verkaufen' : 'Cover'}
                          </button>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          )}
        </div>

        {/* Trade History */}
        <div className="glass-card rounded-xl p-6 border border-[#1a1f37]">
          <h2 className="text-xl font-semibold mb-4">Trade History</h2>
          
          {trades.length === 0 ? (
            <div className="text-center text-gray-500 py-8">
              Noch keine Trades durchgeführt.
            </div>
          ) : (
            <div className="space-y-2">
              {trades.map(trade => (
                <div key={trade.id} className="bg-[#0d1220] rounded-lg p-3 border border-[#1a1f37]">
                  <div className="flex justify-between items-center">
                    <div>
                      <span className="font-semibold">{trade.name}</span>
                      <span className={`ml-2 text-xs px-2 py-0.5 rounded ${
                        trade.type === 'buy' ? 'bg-emerald-500/20 text-emerald-400' : 
                        trade.type === 'short' ? 'bg-red-500/20 text-red-400' :
                        trade.type === 'cover' ? 'bg-blue-500/20 text-blue-400' :
                        'bg-gray-500/20 text-gray-400'
                      }`}>
                        {trade.type === 'buy' ? '📈 KAUF' : 
                         trade.type === 'short' ? '🔻 SHORT' :
                         trade.type === 'cover' ? '✅ COVER' :
                         'VERKAUF'}
                      </span>
                    </div>
                    <div className="text-right text-sm text-gray-400">
                      {trade.date}
                    </div>
                  </div>
                  <div className="text-sm text-gray-400 mt-1">
                    {trade.shares} Shares @ {trade.price.toFixed(2)}€ | {trade.reason}
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </main>
    </div>
  );
}