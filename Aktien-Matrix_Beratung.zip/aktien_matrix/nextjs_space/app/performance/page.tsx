'use client';

import { useState } from 'react';
import Link from 'next/link';
import { 
  TrendingUp, 
  TrendingDown, 
  Activity,
  Calendar,
  BarChart3,
  Target,
  Globe,
  Zap
} from 'lucide-react';
import SharedHeader from '@/components/shared-header';
import { 
  depotPositionen, 
  berechneDepotSummen 
} from '@/data/depot';

// Performance-Daten für verschiedene Zeitrahmen
type TimeFrame = '1W' | '1M' | '3M' | '6M' | 'YTD';

interface PerformanceData {
  depot: number;
  dax: number;
  sp500: number;
  nasdaq: number;
}

const performanceDaten: Record<TimeFrame, PerformanceData> = {
  '1W': { depot: 2.3, dax: 1.2, sp500: 1.5, nasdaq: 2.1 },
  '1M': { depot: 5.8, dax: 3.2, sp500: 4.1, nasdaq: 6.2 },
  '3M': { depot: 8.4, dax: 6.1, sp500: 7.3, nasdaq: 9.8 },
  '6M': { depot: 12.1, dax: 8.5, sp500: 10.2, nasdaq: 14.5 },
  'YTD': { depot: 15.3, dax: 11.2, sp500: 13.8, nasdaq: 17.9 }
};

// Historische Daten für Charts (simuliert)
const generateChartData = (timeFrame: TimeFrame) => {
  const basePoints = {
    '1W': 7,
    '1M': 30,
    '3M': 90,
    '6M': 180,
    'YTD': 365
  };
  
  const points = basePoints[timeFrame];
  const depotData = [];
  const daxData = [];
  const sp500Data = [];
  const nasdaqData = [];
  
  let depotValue = 100;
  let daxValue = 100;
  let sp500Value = 100;
  let nasdaqValue = 100;
  
  for (let i = 0; i < points; i++) {
    const volatility = timeFrame === '1W' ? 0.5 : timeFrame === '1M' ? 1 : 2;
    
    depotValue += (Math.random() - 0.4) * volatility;
    daxValue += (Math.random() - 0.45) * volatility * 0.8;
    sp500Value += (Math.random() - 0.42) * volatility * 0.9;
    nasdaqValue += (Math.random() - 0.38) * volatility * 1.2;
    
    depotData.push(depotValue);
    daxData.push(daxValue);
    sp500Data.push(sp500Value);
    nasdaqData.push(nasdaqValue);
  }
  
  return {
    depot: depotData,
    dax: daxData,
    sp500: sp500Data,
    nasdaq: nasdaqData
  };
};

// SVG Line Chart Component
function SimpleLineChart({ 
  data, 
  color, 
  width = 600, 
  height = 150 
}: { 
  data: number[]; 
  color: string; 
  width?: number; 
  height?: number;
}) {
  const min = Math.min(...data);
  const max = Math.max(...data);
  const range = max - min || 1;
  
  const points = data.map((value, index) => {
    const x = (index / (data.length - 1)) * width;
    const y = height - ((value - min) / range) * height;
    return `${x},${y}`;
  }).join(' ');
  
  return (
    <svg width="100%" height={height} viewBox={`0 0 ${width} ${height}`} className="overflow-visible">
      <defs>
        <linearGradient id={`gradient-${color.replace('#', '')}`} x1="0%" y1="0%" x2="0%" y2="100%">
          <stop offset="0%" stopColor={color} stopOpacity="0.3" />
          <stop offset="100%" stopColor={color} stopOpacity="0" />
        </linearGradient>
      </defs>
      <polygon 
        points={`0,${height} ${points} ${width},${height}`} 
        fill={`url(#gradient-${color.replace('#', '')})`}
      />
      <polyline 
        points={points} 
        fill="none" 
        stroke={color} 
        strokeWidth="2"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
    </svg>
  );
}

// Performance Bar Component
function PerformanceBar({ 
  label, 
  value, 
  color, 
  icon: Icon 
}: { 
  label: string; 
  value: number; 
  color: string;
  icon: any;
}) {
  const isPositive = value >= 0;
  
  return (
    <div className="flex items-center gap-4 py-3 border-b border-[#1a1f37] last:border-0">
      <div className={`w-10 h-10 rounded-lg flex items-center justify-center`} style={{ backgroundColor: `${color}20` }}>
        <Icon className="w-5 h-5" style={{ color }} />
      </div>
      <div className="flex-1">
        <div className="flex items-center justify-between mb-1">
          <span className="text-sm text-gray-300">{label}</span>
          <span className={`text-sm font-semibold ${isPositive ? 'text-emerald-400' : 'text-red-400'}`}>
            {isPositive ? '+' : ''}{value.toFixed(2)}%
          </span>
        </div>
        <div className="h-2 bg-[#1a1f37] rounded-full overflow-hidden">
          <div 
            className="h-full rounded-full transition-all duration-500"
            style={{ 
              width: `${Math.min(Math.abs(value) * 3, 100)}%`,
              backgroundColor: isPositive ? '#22c55e' : '#ef4444'
            }}
          />
        </div>
      </div>
    </div>
  );
}

export default function PerformancePage() {
  const [timeFrame, setTimeFrame] = useState<TimeFrame>('YTD');
  const summen = berechneDepotSummen();
  const chartData = generateChartData(timeFrame);
  const currentPerf = performanceDaten[timeFrame];

  return (
    <div className="min-h-screen bg-[#0a0e1a] text-white">
      {/* Shared Header */}
      <SharedHeader />

      {/* Main Content */}
      <main className="pt-24 pb-12 px-4 sm:px-6 max-w-7xl mx-auto">
        {/* Page Title */}
        <div className="mb-6">
          <h1 className="text-2xl font-bold flex items-center gap-2">
            <Activity className="w-6 h-6 text-[#f0b90b]" />
            Performance
          </h1>
          <p className="text-gray-400 text-sm mt-1">Depot vs. Indizes - Zeitraum-Vergleich</p>
        </div>
        {/* Zeitrahmen Selector */}
        <div className="flex items-center justify-center mb-8">
          <div className="bg-[#0d1220] border border-[#1a1f37] rounded-xl p-1 flex gap-1">
            {(['1W', '1M', '3M', '6M', 'YTD'] as TimeFrame[]).map((tf) => (
              <button
                key={tf}
                onClick={() => setTimeFrame(tf)}
                className={`px-4 py-2 text-sm rounded-lg transition-all ${
                  timeFrame === tf
                    ? 'bg-[#f0b90b] text-black font-medium'
                    : 'text-gray-400 hover:text-white hover:bg-[#1a1f37]'
                }`}
              >
                {tf}
              </button>
            ))}
          </div>
        </div>

        {/* Key Metrics Cards */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
          <div className="bg-[#0d1220] border border-[#1a1f37] rounded-xl p-5">
            <div className="flex items-center gap-2 mb-2">
              <Zap className="w-4 h-4 text-[#f0b90b]" />
              <span className="text-sm text-gray-400">Depot Performance</span>
            </div>
            <div className={`text-2xl font-bold ${currentPerf.depot >= 0 ? 'text-emerald-400' : 'text-red-400'}`}>
              {currentPerf.depot >= 0 ? '+' : ''}{currentPerf.depot}%
            </div>
            <div className="text-xs text-gray-500 mt-1">{timeFrame}</div>
          </div>

          <div className="bg-[#0d1220] border border-[#1a1f37] rounded-xl p-5">
            <div className="flex items-center gap-2 mb-2">
              <Globe className="w-4 h-4 text-[#60B5FF]" />
              <span className="text-sm text-gray-400">DAX</span>
            </div>
            <div className={`text-2xl font-bold ${currentPerf.dax >= 0 ? 'text-emerald-400' : 'text-red-400'}`}>
              {currentPerf.dax >= 0 ? '+' : ''}{currentPerf.dax}%
            </div>
            <div className="text-xs text-gray-500 mt-1">{timeFrame}</div>
          </div>

          <div className="bg-[#0d1220] border border-[#1a1f37] rounded-xl p-5">
            <div className="flex items-center gap-2 mb-2">
              <BarChart3 className="w-4 h-4 text-[#22c55e]" />
              <span className="text-sm text-gray-400">S&P 500</span>
            </div>
            <div className={`text-2xl font-bold ${currentPerf.sp500 >= 0 ? 'text-emerald-400' : 'text-red-400'}`}>
              {currentPerf.sp500 >= 0 ? '+' : ''}{currentPerf.sp500}%
            </div>
            <div className="text-xs text-gray-500 mt-1">{timeFrame}</div>
          </div>

          <div className="bg-[#0d1220] border border-[#1a1f37] rounded-xl p-5">
            <div className="flex items-center gap-2 mb-2">
              <Target className="w-4 h-4 text-purple-400" />
              <span className="text-sm text-gray-400">NASDAQ</span>
            </div>
            <div className={`text-2xl font-bold ${currentPerf.nasdaq >= 0 ? 'text-emerald-400' : 'text-red-400'}`}>
              {currentPerf.nasdaq >= 0 ? '+' : ''}{currentPerf.nasdaq}%
            </div>
            <div className="text-xs text-gray-500 mt-1">{timeFrame}</div>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Performance Chart */}
          <div className="bg-[#0d1220] border border-[#1a1f37] rounded-xl p-6">
            <h2 className="text-lg font-semibold mb-4 flex items-center gap-2">
              <TrendingUp className="w-5 h-5 text-[#f0b90b]" />
              Depot vs. Indizes
            </h2>
            <div className="space-y-4">
              <div>
                <div className="flex items-center justify-between mb-2">
                  <span className="text-sm text-gray-400">Mein Depot</span>
                  <span className="text-sm text-[#f0b90b] font-semibold">{currentPerf.depot}%</span>
                </div>
                <SimpleLineChart data={chartData.depot} color="#f0b90b" />
              </div>
              <div>
                <div className="flex items-center justify-between mb-2">
                  <span className="text-sm text-gray-400">DAX</span>
                  <span className="text-sm text-[#60B5FF] font-semibold">{currentPerf.dax}%</span>
                </div>
                <SimpleLineChart data={chartData.dax} color="#60B5FF" />
              </div>
              <div>
                <div className="flex items-center justify-between mb-2">
                  <span className="text-sm text-gray-400">S&P 500</span>
                  <span className="text-sm text-[#22c55e] font-semibold">{currentPerf.sp500}%</span>
                </div>
                <SimpleLineChart data={chartData.sp500} color="#22c55e" />
              </div>
              <div>
                <div className="flex items-center justify-between mb-2">
                  <span className="text-sm text-gray-400">NASDAQ</span>
                  <span className="text-sm text-purple-400 font-semibold">{currentPerf.nasdaq}%</span>
                </div>
                <SimpleLineChart data={chartData.nasdaq} color="#a855f7" />
              </div>
            </div>
          </div>

          {/* Performance Vergleich */}
          <div className="bg-[#0d1220] border border-[#1a1f37] rounded-xl p-6">
            <h2 className="text-lg font-semibold mb-4 flex items-center gap-2">
              <Calendar className="w-5 h-5 text-[#f0b90b]" />
              Performance Vergleich
            </h2>
            <PerformanceBar 
              label="Mein Depot" 
              value={currentPerf.depot} 
              color="#f0b90b"
              icon={Zap}
            />
            <PerformanceBar 
              label="DAX" 
              value={currentPerf.dax} 
              color="#60B5FF"
              icon={Globe}
            />
            <PerformanceBar 
              label="S&P 500" 
              value={currentPerf.sp500} 
              color="#22c55e"
              icon={BarChart3}
            />
            <PerformanceBar 
              label="NASDAQ" 
              value={currentPerf.nasdaq} 
              color="#a855f7"
              icon={Target}
            />

            {/* Outperformance */}
            <div className="mt-6 pt-6 border-t border-[#1a1f37]">
              <h3 className="text-sm font-medium text-gray-300 mb-4">Outperformance vs. Indizes</h3>
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-sm text-gray-400">vs. DAX</span>
                  <span className={`text-sm font-semibold ${currentPerf.depot - currentPerf.dax >= 0 ? 'text-emerald-400' : 'text-red-400'}`}>
                    {currentPerf.depot - currentPerf.dax >= 0 ? '+' : ''}{(currentPerf.depot - currentPerf.dax).toFixed(2)}%
                  </span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-sm text-gray-400">vs. S&P 500</span>
                  <span className={`text-sm font-semibold ${currentPerf.depot - currentPerf.sp500 >= 0 ? 'text-emerald-400' : 'text-red-400'}`}>
                    {currentPerf.depot - currentPerf.sp500 >= 0 ? '+' : ''}{(currentPerf.depot - currentPerf.sp500).toFixed(2)}%
                  </span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-sm text-gray-400">vs. NASDAQ</span>
                  <span className={`text-sm font-semibold ${currentPerf.depot - currentPerf.nasdaq >= 0 ? 'text-emerald-400' : 'text-red-400'}`}>
                    {currentPerf.depot - currentPerf.nasdaq >= 0 ? '+' : ''}{(currentPerf.depot - currentPerf.nasdaq).toFixed(2)}%
                  </span>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Top/Bottom Performer */}
        <div className="mt-6 grid grid-cols-1 lg:grid-cols-2 gap-6">
          <div className="bg-[#0d1220] border border-[#1a1f37] rounded-xl p-6">
            <h2 className="text-lg font-semibold mb-4 flex items-center gap-2">
              <TrendingUp className="w-5 h-5 text-emerald-400" />
              Top Performer
            </h2>
            <div className="space-y-3">
              {depotPositionen
                .sort((a, b) => b.performanceProzent - a.performanceProzent)
                .slice(0, 5)
                .map((pos) => (
                  <div key={pos.id} className="flex items-center justify-between py-2 border-b border-[#1a1f37] last:border-0">
                    <div>
                      <div className="font-medium text-white">{pos.name}</div>
                      <div className="text-xs text-gray-500">{pos.ticker}</div>
                    </div>
                    <div className="text-right">
                      <div className="text-emerald-400 font-semibold">+{pos.performanceProzent}%</div>
                      <div className="text-xs text-gray-500">{pos.typ}</div>
                    </div>
                  </div>
                ))}
            </div>
          </div>

          <div className="bg-[#0d1220] border border-[#1a1f37] rounded-xl p-6">
            <h2 className="text-lg font-semibold mb-4 flex items-center gap-2">
              <TrendingDown className="w-5 h-5 text-red-400" />
              Schwächste Performer
            </h2>
            <div className="space-y-3">
              {depotPositionen
                .sort((a, b) => a.performanceProzent - b.performanceProzent)
                .slice(0, 5)
                .map((pos) => (
                  <div key={pos.id} className="flex items-center justify-between py-2 border-b border-[#1a1f37] last:border-0">
                    <div>
                      <div className="font-medium text-white">{pos.name}</div>
                      <div className="text-xs text-gray-500">{pos.ticker}</div>
                    </div>
                    <div className="text-right">
                      <div className={`font-semibold ${pos.performanceProzent >= 0 ? 'text-emerald-400' : 'text-red-400'}`}>
                        {pos.performanceProzent >= 0 ? '+' : ''}{pos.performanceProzent}%
                      </div>
                      <div className="text-xs text-gray-500">{pos.typ}</div>
                    </div>
                  </div>
                ))}
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}