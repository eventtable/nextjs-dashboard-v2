"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { AlertCircle, CheckCircle2, Loader2, UserPlus } from "lucide-react";

export default function RegisterPage() {
  const router = useRouter();
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    password: "",
    confirmPassword: "",
    inviteCode: ""
  });
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [success, setSuccess] = useState("");
  const [codeValid, setCodeValid] = useState<boolean | null>(null);
  const [permissions, setPermissions] = useState<any>(null);

  // Validate invite code
  const validateCode = async (code: string) => {
    if (code.length < 8) return;
    
    try {
      const res = await fetch(`/api/friends/register?code=${encodeURIComponent(code)}`);
      const data = await res.json();
      
      if (data.valid) {
        setCodeValid(true);
        setPermissions(data.permissions);
        setError("");
      } else {
        setCodeValid(false);
        setPermissions(null);
      }
    } catch (e) {
      setCodeValid(null);
    }
  };

  const handleCodeChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const code = e.target.value.toUpperCase();
    setFormData(prev => ({ ...prev, inviteCode: code }));
    
    // Debounce validation
    setTimeout(() => validateCode(code), 500);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");
    setSuccess("");
    setLoading(true);

    // Validation
    if (formData.password !== formData.confirmPassword) {
      setError("Passwörter stimmen nicht überein");
      setLoading(false);
      return;
    }

    if (formData.password.length < 8) {
      setError("Passwort muss mindestens 8 Zeichen haben");
      setLoading(false);
      return;
    }

    try {
      const res = await fetch("/api/friends/register", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          email: formData.email,
          password: formData.password,
          name: formData.name,
          inviteCode: formData.inviteCode
        })
      });

      const data = await res.json();

      if (res.ok) {
        setSuccess("Registrierung erfolgreich! Du kannst dich jetzt einloggen.");
        setTimeout(() => {
          router.push("/login");
        }, 2000);
      } else {
        setError(data.error || "Registrierung fehlgeschlagen");
      }
    } catch (e) {
      setError("Ein Fehler ist aufgetreten");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-[#0a0e1a] flex items-center justify-center p-4">
      <Card className="w-full max-w-md bg-[#131722] border-gray-700/50">
        <CardHeader className="text-center">
          <CardTitle className="text-2xl font-bold text-white flex items-center justify-center gap-2">
            <UserPlus className="w-6 h-6" />
            Registrierung
          </CardTitle>
          <p className="text-gray-400 mt-2">
            Erstelle ein Konto mit Invite Code
          </p>
        </CardHeader>
        
        <CardContent>
          {error && (
            <div className="mb-4 p-3 bg-red-500/20 border border-red-500/50 rounded-lg flex items-center gap-2 text-red-400">
              <AlertCircle className="w-5 h-5" />
              {error}
            </div>
          )}
          
          {success && (
            <div className="mb-4 p-3 bg-emerald-500/20 border border-emerald-500/50 rounded-lg flex items-center gap-2 text-emerald-400">
              <CheckCircle2 className="w-5 h-5" />
              {success}
            </div>
          )}
          
          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <Label htmlFor="inviteCode" className="text-gray-300">
                Invite Code *
              </Label>
              <div className="relative">
                <Input
                  id="inviteCode"
                  type="text"
                  value={formData.inviteCode}
                  onChange={handleCodeChange}
                  className={`mt-1 bg-[#1a1f2e] border-gray-600 text-white uppercase ${
                    codeValid === true ? 'border-emerald-500' : 
                    codeValid === false ? 'border-red-500' : ''
                  }`}
                  placeholder="FRIEND-XXXX-XXXX"
                  required
                />
                {codeValid === true && (
                  <CheckCircle2 className="absolute right-3 top-1/2 -translate-y-1/2 w-5 h-5 text-emerald-400" />
                )}
                {codeValid === false && (
                  <AlertCircle className="absolute right-3 top-1/2 -translate-y-1/2 w-5 h-5 text-red-400" />
                )}
              </div>
              {codeValid === false && (
                <p className="text-red-400 text-sm mt-1">Ungültiger oder bereits verwendeter Code</p>
              )}
              {permissions && (
                <div className="mt-2 p-2 bg-emerald-500/10 border border-emerald-500/30 rounded text-sm text-emerald-400">
                  <p>✅ Code gültig! Deine Berechtigungen:</p>
                  <ul className="mt-1 space-y-1">
                    {permissions.canViewDepot && <li>• Depot ansehen</li>}
                    {permissions.canViewTrading && <li>• Trading Signale</li>}
                    {permissions.canViewML && <li>• ML Performance</li>}
                  </ul>
                </div>
              )}
            </div>

            <div>
              <Label htmlFor="name" className="text-gray-300">
                Name *
              </Label>
              <Input
                id="name"
                type="text"
                value={formData.name}
                onChange={(e) => setFormData(prev => ({ ...prev, name: e.target.value }))}
                className="mt-1 bg-[#1a1f2e] border-gray-600 text-white"
                placeholder="Max Mustermann"
                required
              />
            </div>

            <div>
              <Label htmlFor="email" className="text-gray-300">
                E-Mail *
              </Label>
              <Input
                id="email"
                type="email"
                value={formData.email}
                onChange={(e) => setFormData(prev => ({ ...prev, email: e.target.value }))}
                className="mt-1 bg-[#1a1f2e] border-gray-600 text-white"
                placeholder="max@beispiel.de"
                required
              />
            </div>

            <div>
              <Label htmlFor="password" className="text-gray-300">
                Passwort *
              </Label>
              <Input
                id="password"
                type="password"
                value={formData.password}
                onChange={(e) => setFormData(prev => ({ ...prev, password: e.target.value }))}
                className="mt-1 bg-[#1a1f2e] border-gray-600 text-white"
                placeholder="Mindestens 8 Zeichen"
                required
              />
            </div>

            <div>
              <Label htmlFor="confirmPassword" className="text-gray-300">
                Passwort bestätigen *
              </Label>
              <Input
                id="confirmPassword"
                type="password"
                value={formData.confirmPassword}
                onChange={(e) => setFormData(prev => ({ ...prev, confirmPassword: e.target.value }))}
                className="mt-1 bg-[#1a1f2e] border-gray-600 text-white"
                placeholder="Passwort wiederholen"
                required
              />
            </div>

            <Button
              type="submit"
              disabled={loading || codeValid !== true}
              className="w-full bg-emerald-500 hover:bg-emerald-600 disabled:bg-gray-600"
            >
              {loading ? (
                <>
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  Registriere...
                </>
              ) : (
                "Konto erstellen"
              )}
            </Button>
          </form>

          <div className="mt-6 text-center">
            <p className="text-gray-400 text-sm">
              Bereits ein Konto?{" "}
              <Link href="/login" className="text-emerald-400 hover:text-emerald-300">
                Jetzt einloggen
              </Link>
            </p>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}