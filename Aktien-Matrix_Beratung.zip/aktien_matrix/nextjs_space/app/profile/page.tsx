"use client";

import { useState } from "react";
import { useSession } from "next-auth/react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { User, Lock, Mail, CheckCircle2, AlertCircle, Loader2, Save } from "lucide-react";

export default function ProfilePage() {
  const { data: session, update } = useSession();
  const [loading, setLoading] = useState(false);
  const [message, setMessage] = useState({ type: "", text: "" });
  
  const [formData, setFormData] = useState({
    name: session?.user?.name || "",
    email: session?.user?.email || "",
    currentPassword: "",
    newPassword: "",
    confirmPassword: ""
  });

  const handleUpdateProfile = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setMessage({ type: "", text: "" });

    try {
      const res = await fetch("/api/friends/update-profile", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          email: session?.user?.email,
          name: formData.name
        })
      });

      if (res.ok) {
        await update({ name: formData.name });
        setMessage({ type: "success", text: "Profil erfolgreich aktualisiert!" });
      } else {
        setMessage({ type: "error", text: "Fehler beim Aktualisieren" });
      }
    } catch (e) {
      setMessage({ type: "error", text: "Ein Fehler ist aufgetreten" });
    } finally {
      setLoading(false);
    }
  };

  const handleChangePassword = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setMessage({ type: "", text: "" });

    if (formData.newPassword !== formData.confirmPassword) {
      setMessage({ type: "error", text: "Passwoerter stimmen nicht ueberein" });
      setLoading(false);
      return;
    }

    if (formData.newPassword.length < 8) {
      setMessage({ type: "error", text: "Passwort muss mindestens 8 Zeichen haben" });
      setLoading(false);
      return;
    }

    try {
      const res = await fetch("/api/friends/change-password", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          email: session?.user?.email,
          currentPassword: formData.currentPassword,
          newPassword: formData.newPassword
        })
      });

      if (res.ok) {
        setMessage({ type: "success", text: "Passwort erfolgreich geaendert!" });
        setFormData(prev => ({ ...prev, currentPassword: "", newPassword: "", confirmPassword: "" }));
      } else {
        const data = await res.json();
        setMessage({ type: "error", text: data.error || "Fehler beim Aendern" });
      }
    } catch (e) {
      setMessage({ type: "error", text: "Ein Fehler ist aufgetreten" });
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-[#0a0e1a] p-6">
      <div className="max-w-2xl mx-auto">
        <h1 className="text-3xl font-bold text-white mb-8 flex items-center gap-3">
          <User className="w-8 h-8" />
          Mein Profil
        </h1>

        {message.text && (
          <div className={`mb-6 p-4 rounded-lg flex items-center gap-2 ${
            message.type === "success" 
              ? "bg-emerald-500/20 border border-emerald-500/50 text-emerald-400" 
              : "bg-red-500/20 border border-red-500/50 text-red-400"
          }`}>
            {message.type === "success" ? <CheckCircle2 className="w-5 h-5" /> : <AlertCircle className="w-5 h-5" />}
            {message.text}
          </div>
        )}

        <Card className="bg-[#131722] border-gray-700/50 mb-6">
          <CardHeader>
            <CardTitle className="text-xl font-bold text-white flex items-center gap-2">
              <User className="w-5 h-5" />
              Profil bearbeiten
            </CardTitle>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleUpdateProfile} className="space-y-4">
              <div>
                <Label className="text-gray-300 flex items-center gap-2">
                  <User className="w-4 h-4" />
                  Name
                </Label>
                <Input
                  value={formData.name}
                  onChange={(e) => setFormData(prev => ({ ...prev, name: e.target.value }))}
                  className="mt-1 bg-[#1a1f2e] border-gray-600 text-white"
                  placeholder="Dein Name"
                  required
                />
              </div>

              <div>
                <Label className="text-gray-300 flex items-center gap-2">
                  <Mail className="w-4 h-4" />
                  E-Mail
                </Label>
                <Input
                  value={formData.email}
                  disabled
                  className="mt-1 bg-gray-800 border-gray-600 text-gray-400 cursor-not-allowed"
                />
                <p className="text-xs text-gray-500 mt-1">E-Mail kann nicht geaendert werden</p>
              </div>

              <Button type="submit" disabled={loading} className="bg-emerald-500 hover:bg-emerald-600">
                {loading ? (
                  <>
                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                    Speichern...
                  </>
                ) : (
                  <>
                    <Save className="w-4 h-4 mr-2" />
                    Profil speichern
                  </>
                )}
              </Button>
            </form>
          </CardContent>
        </Card>

        <Card className="bg-[#131722] border-gray-700/50">
          <CardHeader>
            <CardTitle className="text-xl font-bold text-white flex items-center gap-2">
              <Lock className="w-5 h-5" />
              Passwort aendern
            </CardTitle>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleChangePassword} className="space-y-4">
              <div>
                <Label className="text-gray-300 flex items-center gap-2">
                  <Lock className="w-4 h-4" />
                  Aktuelles Passwort
                </Label>
                <Input
                  type="password"
                  value={formData.currentPassword}
                  onChange={(e) => setFormData(prev => ({ ...prev, currentPassword: e.target.value }))}
                  className="mt-1 bg-[#1a1f2e] border-gray-600 text-white"
                  placeholder="••••••••"
                  required
                />
              </div>

              <div>
                <Label className="text-gray-300 flex items-center gap-2">
                  <Lock className="w-4 h-4" />
                  Neues Passwort
                </Label>
                <Input
                  type="password"
                  value={formData.newPassword}
                  onChange={(e) => setFormData(prev => ({ ...prev, newPassword: e.target.value }))}
                  className="mt-1 bg-[#1a1f2e] border-gray-600 text-white"
                  placeholder="Mindestens 8 Zeichen"
                  required
                />
              </div>

              <div>
                <Label className="text-gray-300 flex items-center gap-2">
                  <Lock className="w-4 h-4" />
                  Neues Passwort bestaetigen
                </Label>
                <Input
                  type="password"
                  value={formData.confirmPassword}
                  onChange={(e) => setFormData(prev => ({ ...prev, confirmPassword: e.target.value }))}
                  className="mt-1 bg-[#1a1f2e] border-gray-600 text-white"
                  placeholder="••••••••"
                  required
                />
              </div>

              <Button type="submit" disabled={loading} className="bg-emerald-500 hover:bg-emerald-600">
                {loading ? (
                  <>
                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                    Aendern...
                  </>
                ) : (
                  <>
                    <Save className="w-4 h-4 mr-2" />
                    Passwort aendern
                  </>
                )}
              </Button>
            </form>
          </CardContent>
        </Card>

        <Card className="bg-[#131722] border-gray-700/50 mt-6">
          <CardHeader>
            <CardTitle className="text-xl font-bold text-white">
              Meine Berechtigungen
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              <div className="flex items-center justify-between p-3 rounded-lg bg-gray-800/30">
                <span className="text-gray-300">Depot ansehen</span>
                <span className="text-emerald-400">{session?.user?.permissions?.canViewDepot ? "✅" : "❌"}</span>
              </div>
              <div className="flex items-center justify-between p-3 rounded-lg bg-gray-800/30">
                <span className="text-gray-300">Trading Signale</span>
                <span className="text-emerald-400">{session?.user?.permissions?.canViewTrading ? "✅" : "❌"}</span>
              </div>
              <div className="flex items-center justify-between p-3 rounded-lg bg-gray-800/30">
                <span className="text-gray-300">ML Performance</span>
                <span className="text-emerald-400">{session?.user?.permissions?.canViewML ? "✅" : "❌"}</span>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}