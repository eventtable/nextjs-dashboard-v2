'use client';

import { useState } from 'react';
import Link from 'next/link';
import { 
  Bell, 
  TrendingUp, 
  TrendingDown, 
  AlertTriangle,
  CheckCircle,
  Clock,
  ShoppingCart,
  Eye,
  Calendar,
  Target,
  Filter,
  BellRing,
  Zap,
  Plus,
  ChevronRight,
  Activity
} from 'lucide-react';
import SharedHeader from '@/components/shared-header';
import { 
  depotPositionen
} from '@/data/depot';

// Alert Interface
interface Alert {
  id: string;
  type: 'stop-loss' | 'target' | 'buy-signal' | 'sell-signal' | 'news';
  severity: 'high' | 'medium' | 'low';
  title: string;
  message: string;
  ticker: string;
  name: string;
  date: string;
  isRead: boolean;
}

// Nachkauf Interface
interface Nachkauf {
  id: string;
  ticker: string;
  name: string;
  aktuellerPreis: number;
  empfohlenerPreis: number;
  strategie: 'Dip-Kauf' | 'Durchschnitt' | 'Breakout';
  begruendung: string;
  dringlichkeit: 'sofort' | 'bald' | 'beobachten';
}

// Watchlist Interface
interface WatchlistEntry {
  id: string;
  ticker: string;
  name: string;
  sektor: string;
  kurs: number;
  changePercent: number;
  kgv?: number;
  notiz: string;
}

// Trade Kalender Interface
interface TradeEvent {
  id: string;
  date: string;
  type: 'earnings' | 'dividend' | 'split' | 'economic' | 'meeting';
  title: string;
  ticker?: string;
  name?: string;
  description: string;
}

// Simulierte Daten
const aktiveAlerts: Alert[] = [
  {
    id: '1',
    type: 'stop-loss',
    severity: 'high',
    title: 'Stop-Loss erreicht',
    message: 'Kurs fiel unter den definierten Stop-Loss von 145€',
    ticker: 'NOVO-B.CO',
    name: 'Novo Nordisk',
    date: '2026-03-27',
    isRead: false
  },
  {
    id: '2',
    type: 'target',
    severity: 'medium',
    title: 'Kursziel erreicht',
    message: 'Barrick Gold hat das Kursziel von 28$ überschritten',
    ticker: 'GOLD',
    name: 'Barrick Mining',
    date: '2026-03-26',
    isRead: false
  },
  {
    id: '3',
    type: 'buy-signal',
    severity: 'medium',
    title: 'Kaufsignal',
    message: 'RSI unter 30 - Überverkauftes Niveau erreicht',
    ticker: 'MSFT',
    name: 'Microsoft',
    date: '2026-03-25',
    isRead: true
  },
  {
    id: '4',
    type: 'news',
    severity: 'low',
    title: 'Quartalsbericht veröffentlicht',
    message: 'SAP übertrifft Erwartungen - Umsatz +12%',
    ticker: 'SAP.DE',
    name: 'SAP',
    date: '2026-03-24',
    isRead: true
  }
];

const nachkaufEmpfehlungen: Nachkauf[] = [
  {
    id: '1',
    ticker: 'MSFT',
    name: 'Microsoft',
    aktuellerPreis: 385.0,
    empfohlenerPreis: 375.0,
    strategie: 'Dip-Kauf',
    begruendung: 'Technische Überverkauftheit bei intakten Fundamenten',
    dringlichkeit: 'bald'
  },
  {
    id: '2',
    ticker: 'NOVO-B.CO',
    name: 'Novo Nordisk',
    aktuellerPreis: 142.5,
    empfohlenerPreis: 138.0,
    strategie: 'Durchschnitt',
    begruendung: 'Günstigerer Durchschnittseinstieg nach Korrektur',
    dringlichkeit: 'beobachten'
  },
  {
    id: '3',
    ticker: 'MBBK.DE',
    name: 'MBB',
    aktuellerPreis: 85.2,
    empfohlenerPreis: 82.0,
    strategie: 'Breakout',
    begruendung: 'Aufwärtstrend bestätigt - technischer Einstieg',
    dringlichkeit: 'sofort'
  }
];

const watchlist: WatchlistEntry[] = [
  {
    id: '1',
    ticker: 'NVDA',
    name: 'NVIDIA',
    sektor: 'Technology',
    kurs: 892.5,
    changePercent: 3.2,
    kgv: 65.4,
    notiz: 'KI-Leader, aber zu teuer momentan'
  },
  {
    id: '2',
    ticker: 'RHM.DE',
    name: 'Rheinmetall',
    sektor: 'Defense',
    kurs: 485.0,
    changePercent: 2.8,
    kgv: 28.5,
    notiz: 'Geopolitischer Tailwind'
  },
  {
    id: '3',
    ticker: 'LLY',
    name: 'Eli Lilly',
    sektor: 'Pharma',
    kurs: 720.3,
    changePercent: -1.2,
    kgv: 125.8,
    notiz: 'Novo-Alternative, KGV zu hoch'
  },
  {
    id: '4',
    ticker: 'TSLA',
    name: 'Tesla',
    sektor: 'Automotive',
    kurs: 275.8,
    changePercent: -0.5,
    kgv: 68.2,
    notiz: 'Warte auf besseren Einstieg'
  },
  {
    id: '5',
    ticker: 'AAPL',
    name: 'Apple',
    sektor: 'Technology',
    kurs: 178.5,
    changePercent: 0.8,
    kgv: 28.3,
    notiz: 'Solide Dividende'
  }
];

const tradeKalender: TradeEvent[] = [
  {
    id: '1',
    date: '2026-04-02',
    type: 'earnings',
    title: 'Q1 Earnings',
    ticker: 'MSFT',
    name: 'Microsoft',
    description: 'Vor Börsenöffnung - Umsatz und Guidance im Fokus'
  },
  {
    id: '2',
    date: '2026-04-15',
    type: 'dividend',
    title: 'Dividend Ex-Date',
    ticker: 'ALV.DE',
    name: 'Allianz',
    description: 'Quartalsdividende: ~3,40€ pro Aktie'
  },
  {
    id: '3',
    date: '2026-04-28',
    type: 'earnings',
    title: 'Q1 Earnings',
    ticker: 'SAP.DE',
    name: 'SAP',
    description: 'Cloud-Wachstum und Prognose im Fokus'
  },
  {
    id: '4',
    date: '2026-05-06',
    type: 'economic',
    title: 'Fed Zinsentscheid',
    description: 'Erwartung: Keine Veränderung, aber Guidance wichtig'
  },
  {
    id: '5',
    date: '2026-05-12',
    type: 'dividend',
    title: 'Dividend Ex-Date',
    ticker: 'MUV2.DE',
    name: 'Munich Re',
    description: 'Jahresdividende: ~15€ pro Aktie'
  }
];

// Alert Badge
function AlertBadge({ type }: { type: Alert['type'] }) {
  const config = {
    'stop-loss': { color: '#ef4444', label: 'Stop-Loss' },
    'target': { color: '#22c55e', label: 'Ziel' },
    'buy-signal': { color: '#22c55e', label: 'Kauf' },
    'sell-signal': { color: '#ef4444', label: 'Verkauf' },
    'news': { color: '#60B5FF', label: 'News' }
  };
  
  const c = config[type];
  return (
    <span 
      className="text-[10px] px-2 py-0.5 rounded-full font-medium"
      style={{ backgroundColor: `${c.color}20`, color: c.color }}
    >
      {c.label}
    </span>
  );
}

// Severity Indicator
function SeverityIndicator({ severity }: { severity: Alert['severity'] }) {
  const colors = {
    high: '#ef4444',
    medium: '#f97316',
    low: '#60B5FF'
  };
  
  return (
    <div className="flex items-center gap-1">
      <div 
        className="w-2 h-2 rounded-full"
        style={{ backgroundColor: colors[severity] }}
      />
    </div>
  );
}

// Dringlichkeit Badge
function DringlichkeitBadge({ level }: { level: Nachkauf['dringlichkeit'] }) {
  const config = {
    sofort: { color: '#ef4444', label: '⚡ Sofort' },
    bald: { color: '#f0b90b', label: '📅 Bald' },
    beobachten: { color: '#60B5FF', label: '👁 Beobachten' }
  };
  
  const c = config[level];
  return (
    <span 
      className="text-[10px] px-2 py-0.5 rounded-full font-medium"
      style={{ backgroundColor: `${c.color}20`, color: c.color }}
    >
      {c.label}
    </span>
  );
}

// Event Type Badge
function EventTypeBadge({ type }: { type: TradeEvent['type'] }) {
  const config = {
    earnings: { icon: TrendingUp, color: '#f0b90b', label: 'Earnings' },
    dividend: { icon: ShoppingCart, color: '#22c55e', label: 'Dividende' },
    split: { icon: Zap, color: '#a855f7', label: 'Split' },
    economic: { icon: AlertTriangle, color: '#f97316', label: 'Ökonomisch' },
    meeting: { icon: Calendar, color: '#60B5FF', label: 'Meeting' }
  };
  
  const c = config[type];
  const Icon = c.icon;
  
  return (
    <span 
      className="inline-flex items-center gap-1 text-[10px] px-2 py-0.5 rounded-full font-medium"
      style={{ backgroundColor: `${c.color}20`, color: c.color }}
    >
      <Icon className="w-3 h-3" />
      {c.label}
    </span>
  );
}

export default function SignalsPage() {
  const [activeTab, setActiveTab] = useState<'alerts' | 'nachkauf' | 'watchlist' | 'kalender'>('alerts');
  const [unreadFilter, setUnreadFilter] = useState(false);
  
  const filteredAlerts = unreadFilter 
    ? aktiveAlerts.filter(a => !a.isRead)
    : aktiveAlerts;
  
  const unreadCount = aktiveAlerts.filter(a => !a.isRead).length;

  return (
    <div className="min-h-screen bg-[#0a0e1a] text-white">
      {/* Shared Header */}
      <SharedHeader />

      {/* Main Content */}
      <main className="pt-24 pb-12 px-4 sm:px-6 max-w-7xl mx-auto">
        {/* Page Title with Unread Badge */}
        <div className="mb-6 flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold flex items-center gap-2">
              <BellRing className="w-6 h-6 text-[#f0b90b]" />
              Signale & Alerts
            </h1>
            <p className="text-gray-400 text-sm mt-1">Alerts, Nachkauf-Empfehlungen und Watchlist</p>
          </div>
          
          {unreadCount > 0 && (
            <span className="bg-red-500/20 text-red-400 text-sm px-3 py-1.5 rounded-full font-medium flex items-center gap-1">
              <span className="w-2 h-2 bg-red-400 rounded-full animate-pulse"></span>
              {unreadCount} ungelesen
            </span>
          )}
        </div>
        {/* Tab Navigation */}
        <div className="flex flex-wrap gap-1 mb-6">
          <button
            onClick={() => setActiveTab('alerts')}
            className={`flex items-center gap-2 px-4 py-2 text-sm rounded-lg transition-all ${
              activeTab === 'alerts'
                ? 'bg-[#f0b90b] text-black font-medium'
                : 'bg-[#0d1220] text-gray-400 hover:text-white border border-[#1a1f37]'
            }`}
          >
            <Bell className="w-4 h-4" />
            Aktive Alerts
            {unreadCount > 0 && (
              <span className="bg-red-500 text-white text-[10px] px-1.5 py-0.5 rounded-full">
                {unreadCount}
              </span>
            )}
          </button>
          
          <button
            onClick={() => setActiveTab('nachkauf')}
            className={`flex items-center gap-2 px-4 py-2 text-sm rounded-lg transition-all ${
              activeTab === 'nachkauf'
                ? 'bg-[#f0b90b] text-black font-medium'
                : 'bg-[#0d1220] text-gray-400 hover:text-white border border-[#1a1f37]'
            }`}
          >
            <ShoppingCart className="w-4 h-4" />
            Nachkauf
            <span className="bg-emerald-500/20 text-emerald-400 text-[10px] px-1.5 py-0.5 rounded-full">
              {nachkaufEmpfehlungen.length}
            </span>
          </button>
          
          <button
            onClick={() => setActiveTab('watchlist')}
            className={`flex items-center gap-2 px-4 py-2 text-sm rounded-lg transition-all ${
              activeTab === 'watchlist'
                ? 'bg-[#f0b90b] text-black font-medium'
                : 'bg-[#0d1220] text-gray-400 hover:text-white border border-[#1a1f37]'
            }`}
          >
            <Eye className="w-4 h-4" />
            Watchlist
            <span className="bg-[#60B5FF]/20 text-[#60B5FF] text-[10px] px-1.5 py-0.5 rounded-full">
              {watchlist.length}
            </span>
          </button>
          
          <button
            onClick={() => setActiveTab('kalender')}
            className={`flex items-center gap-2 px-4 py-2 text-sm rounded-lg transition-all ${
              activeTab === 'kalender'
                ? 'bg-[#f0b90b] text-black font-medium'
                : 'bg-[#0d1220] text-gray-400 hover:text-white border border-[#1a1f37]'
            }`}
          >
            <Calendar className="w-4 h-4" />
            Trade-Kalender
          </button>
        </div>

        {/* Alerts Tab */}
        {activeTab === 'alerts' && (
          <>
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-lg font-semibold flex items-center gap-2">
                <Bell className="w-5 h-5 text-[#f0b90b]" />
                Aktive Alerts
              </h2>
              <button
                onClick={() => setUnreadFilter(!unreadFilter)}
                className={`flex items-center gap-2 px-3 py-1.5 text-xs rounded-lg transition-all ${
                  unreadFilter
                    ? 'bg-[#f0b90b]/20 text-[#f0b90b]'
                    : 'bg-[#1a1f37] text-gray-400 hover:text-white'
                }`}
              >
                <Filter className="w-3 h-3" />
                {unreadFilter ? 'Nur Ungelesene' : 'Alle anzeigen'}
              </button>
            </div>

            <div className="space-y-3">
              {filteredAlerts.map((alert) => (
                <div 
                  key={alert.id}
                  className={`bg-[#0d1220] border rounded-xl p-4 transition-all ${
                    alert.isRead 
                      ? 'border-[#1a1f37]' 
                      : 'border-[#f0b90b]/50 bg-[#f0b90b]/5'
                  }`}
                >
                  <div className="flex items-start justify-between">
                    <div className="flex items-start gap-3">
                      <SeverityIndicator severity={alert.severity} />
                      <div>
                        <div className="flex items-center gap-2 mb-1">
                          <AlertBadge type={alert.type} />
                          <span className="text-xs text-gray-400">{alert.date}</span>
                          {!alert.isRead && (
                            <span className="bg-[#f0b90b] text-black text-[10px] px-1.5 py-0.5 rounded-full font-medium">
                              Neu
                            </span>
                          )}
                        </div>
                        <h3 className="font-semibold text-white">{alert.title}</h3>
                        <p className="text-sm text-gray-400">{alert.message}</p>
                        <div className="flex items-center gap-2 mt-2">
                          <span className="font-mono text-xs text-[#f0b90b] bg-[#f0b90b]/10 px-2 py-0.5 rounded">{alert.ticker}</span>
                          <span className="text-xs text-gray-500">{alert.name}</span>
                        </div>
                      </div>
                    </div>
                    
                    <button className="text-gray-400 hover:text-white">
                      <ChevronRight className="w-5 h-5" />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </>
        )}

        {/* Nachkauf Tab */}
        {activeTab === 'nachkauf' && (
          <>
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-lg font-semibold flex items-center gap-2">
                <ShoppingCart className="w-5 h-5 text-[#f0b90b]" />
                Nachkauf-Empfehlungen
              </h2>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
              {nachkaufEmpfehlungen.map((emp) => (
                <div key={emp.id} className="bg-[#0d1220] border border-[#1a1f37] rounded-xl p-5 hover:bg-[#111827] transition-colors">
                  <div className="flex items-start justify-between mb-3">
                    <div>
                      <h3 className="font-semibold text-white">{emp.name}</h3>
                      <span className="font-mono text-xs text-[#f0b90b]">{emp.ticker}</span>
                    </div>
                    <DringlichkeitBadge level={emp.dringlichkeit} />
                  </div>
                  
                  <div className="space-y-2 mb-4">
                    <div className="flex items-center justify-between">
                      <span className="text-xs text-gray-400">Aktuell</span>
                      <span className="text-sm font-medium">{emp.aktuellerPreis.toFixed(2)}€</span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-xs text-gray-400">Empfohlen</span>
                      <span className="text-sm font-medium text-emerald-400">{emp.empfohlenerPreis.toFixed(2)}€</span>
                    </div>
                    
                    <div className="flex items-center justify-between">
                      <span className="text-xs text-gray-400">Strategie</span>
                      <span className="text-xs px-2 py-0.5 rounded-full bg-[#60B5FF]/20 text-[#60B5FF]">{emp.strategie}</span>
                    </div>
                  </div>
                  
                  <p className="text-xs text-gray-400 border-t border-[#1a1f37] pt-3">{emp.begruendung}</p>
                </div>
              ))}
            </div>
          </>
        )}

        {/* Watchlist Tab */}
        {activeTab === 'watchlist' && (
          <>
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-lg font-semibold flex items-center gap-2">
                <Eye className="w-5 h-5 text-[#f0b90b]" />
                Watchlist
              </h2>
              <button className="flex items-center gap-2 px-3 py-1.5 text-xs rounded-lg bg-[#1a1f37] text-gray-400 hover:text-white transition-colors">
                <Plus className="w-3 h-3" />
                Hinzufügen
              </button>
            </div>

            <div className="bg-[#0d1220] border border-[#1a1f37] rounded-xl overflow-hidden">
              <table className="w-full">
                <thead>
                  <tr className="border-b border-[#1a1f37]">
                    <th className="text-left py-3 px-4 text-sm text-gray-400 font-medium">Name</th>
                    <th className="text-left py-3 px-4 text-sm text-gray-400 font-medium">Ticker</th>
                    <th className="text-left py-3 px-4 text-sm text-gray-400 font-medium">Sektor</th>
                    <th className="text-right py-3 px-4 text-sm text-gray-400 font-medium">Kurs</th>
                    <th className="text-right py-3 px-4 text-sm text-gray-400 font-medium">24h</th>
                    <th className="text-right py-3 px-4 text-sm text-gray-400 font-medium">KGV</th>
                    <th className="text-left py-3 px-4 text-sm text-gray-400 font-medium">Notiz</th>
                  </tr>
                </thead>
                <tbody>
                  {watchlist.map((item) => (
                    <tr key={item.id} className="border-b border-[#1a1f37] hover:bg-[#111827] transition-colors">
                      <td className="py-3 px-4 font-medium">{item.name}</td>
                      <td className="py-3 px-4 font-mono text-xs text-[#f0b90b]">{item.ticker}</td>
                      <td className="py-3 px-4 text-sm text-gray-400">{item.sektor}</td>
                      <td className="py-3 px-4 text-right">{item.kurs.toFixed(2)}€</td>
                      <td className={`py-3 px-4 text-right ${item.changePercent >= 0 ? 'text-emerald-400' : 'text-red-400'}`}>
                        {item.changePercent >= 0 ? '+' : ''}{item.changePercent}%
                      </td>
                      <td className="py-3 px-4 text-right text-sm text-gray-400">{item.kgv?.toFixed(1) || '-'}</td>
                      <td className="py-3 px-4 text-sm text-gray-400">{item.notiz}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </>
        )}

        {/* Kalender Tab */}
        {activeTab === 'kalender' && (
          <>
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-lg font-semibold flex items-center gap-2">
                <Calendar className="w-5 h-5 text-[#f0b90b]" />
                Trade-Kalender
              </h2>
            </div>

            <div className="space-y-3">
              {tradeKalender.map((event) => (
                <div key={event.id} className="bg-[#0d1220] border border-[#1a1f37] rounded-xl p-4 hover:bg-[#111827] transition-colors">
                  <div className="flex items-start gap-4">
                    <div className="text-center min-w-[60px]">
                      <div className="text-xs text-gray-400 uppercase">
                        {new Date(event.date).toLocaleDateString('de-DE', { month: 'short' })}
                      </div>
                      <div className="text-2xl font-bold text-[#f0b90b]">
                        {new Date(event.date).getDate()}
                      </div>
                    </div>
                    
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-1">
                        <EventTypeBadge type={event.type} />
                        <span className="text-xs text-gray-400">{event.date}</span>
                      </div>
                      
                      <h3 className="font-semibold text-white">{event.title}</h3>
                      
                      {event.ticker && (
                        <div className="flex items-center gap-2 mt-1">
                          <span className="font-mono text-xs text-[#f0b90b] bg-[#f0b90b]/10 px-2 py-0.5 rounded">{event.ticker}</span>
                          <span className="text-xs text-gray-400">{event.name}</span>
                        </div>
                      )}
                      
                      <p className="text-sm text-gray-400 mt-2">{event.description}</p>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </>
        )}
      </main>
    </div>
  );
}