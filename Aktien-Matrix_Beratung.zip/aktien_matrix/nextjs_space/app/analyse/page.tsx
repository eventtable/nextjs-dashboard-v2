'use client';

import { motion } from 'framer-motion';
import Link from 'next/link';
import { 
  PieChart, 
  Globe, 
  Target, 
  ArrowLeft,
  CheckCircle,
  AlertTriangle,
  Info,
  TrendingUp,
  Shield,
  Wallet,
  AlertCircle
} from 'lucide-react';
import SharedHeader from '@/components/shared-header';
import { berechneDepotSummen } from '@/data/depot';
import { 
  sektorenDaten, 
  laenderDaten, 
  balanceCheck,
  rebalanceEmpfehlungen,
  VERTEILUNG_ZUSAMMENFASSUNG 
} from '@/data/depot_analyse';
import {
  PieChart as RePieChart,
  Pie,
  Cell,
  ResponsiveContainer,
  Tooltip,
  Legend,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  ReferenceLine
} from 'recharts';

export default function DepotAnalysePage() {
  const summen = berechneDepotSummen();

  const CustomPieTooltip = ({ active, payload }: any) => {
    if (active && payload && payload.length) {
      const data = payload[0].payload;
      return (
        <div className="bg-[#0d1220] border border-[#1a1f37] rounded-lg p-3 shadow-xl">
          <p className="font-semibold text-white">{data.sektor || data.land}</p>
          <p className="text-[#60B5FF]">{data.wert.toLocaleString('de-DE')} €</p>
          <p className="text-gray-400">{data.prozent}%</p>
        </div>
      );
    }
    return null;
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'optimal':
        return <CheckCircle className="w-5 h-5 text-emerald-400" />;
      case 'ok':
        return <Info className="w-5 h-5 text-blue-400" />;
      case 'warning':
        return <AlertTriangle className="w-5 h-5 text-yellow-400" />;
      case 'critical':
        return <AlertCircle className="w-5 h-5 text-red-400" />;
      default:
        return null;
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'optimal':
        return 'text-emerald-400 bg-emerald-500/20 border-emerald-500/30';
      case 'ok':
        return 'text-blue-400 bg-blue-500/20 border-blue-500/30';
      case 'warning':
        return 'text-yellow-400 bg-yellow-500/20 border-yellow-500/30';
      case 'critical':
        return 'text-red-400 bg-red-500/20 border-red-500/30';
      default:
        return 'text-gray-400';
    }
  };

  return (
    <div className="min-h-screen bg-[#0a0e1a] text-white">
      <SharedHeader />

      <main className="pt-24 pb-12 px-4 sm:px-6 max-w-7xl mx-auto">
        {/* Header */}
        <div className="flex items-center gap-4 mb-6">
          <Link 
            href="/" 
            className="flex items-center gap-2 text-gray-400 hover:text-white transition-colors"
          >
            <ArrowLeft className="w-5 h-5" />
            <span>Zurück</span>
          </Link>
        </div>

        <div className="mb-8">
          <h1 className="text-3xl font-bold mb-2 flex items-center gap-3">
            <PieChart className="w-8 h-8 text-[#f0b90b]" />
            Depot-Analyse
          </h1>
          <p className="text-gray-400">
            Sektoren, Länder & Balance-Check nach der Matrix 2.0 Strategie
          </p>
        </div>

        {/* Quick Stats */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-8">
          <div className="bg-[#0d1220] border border-[#1a1f37] rounded-xl p-4">
            <div className="flex items-center gap-3 mb-2">
              <PieChart className="w-5 h-5 text-[#60B5FF]" />
              <span className="text-gray-400">Sektoren</span>
            </div>
            <p className="text-2xl font-bold">{VERTEILUNG_ZUSAMMENFASSUNG.sektoren.anzahl}</p>
            <p className="text-sm text-gray-500">Unterschiedliche Bereiche</p>
          </div>

          <div className="bg-[#0d1220] border border-[#1a1f37] rounded-xl p-4">
            <div className="flex items-center gap-3 mb-2">
              <Globe className="w-5 h-5 text-[#f0b90b]" />
              <span className="text-gray-400">Länder</span>
            </div>
            <p className="text-2xl font-bold">{VERTEILUNG_ZUSAMMENFASSUNG.laender.anzahl}</p>
            <p className="text-sm text-gray-500">Geografische Verteilung</p>
          </div>

          <div className="bg-[#0d1220] border border-[#1a1f37] rounded-xl p-4">
            <div className="flex items-center gap-3 mb-2">
              <Target className="w-5 h-5 text-emerald-400" />
              <span className="text-gray-400">Balance</span>
            </div>
            <p className="text-2xl font-bold">{VERTEILUNG_ZUSAMMENFASSUNG.balance.status}</p>
            <p className="text-sm text-gray-500">1/3 Strategie</p>
          </div>
        </div>

        {/* Balance Check - 1/3 Strategie */}
        <div className="glass-card rounded-xl p-6 mb-8 border border-[#f0b90b]/30">
          <h2 className="text-xl font-semibold mb-6 flex items-center gap-2">
            <Target className="w-6 h-6 text-[#f0b90b]" />
            Balance-Check: 1/3 Strategie
          </h2>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
            {balanceCheck.map((item, index) => (
              <motion.div
                key={item.kategorie}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1 }}
                className={`bg-[#0d1220] rounded-xl p-4 border ${getStatusColor(item.status)}`}
              >
                <div className="flex items-start justify-between mb-3">
                  <div>
                    <p className="text-sm font-medium">{item.kategorie.split(' ')[0]}</p>
                    <p className="text-xs text-gray-400 mt-1">{item.kategorie.split(' ').slice(1).join(' ')}</p>
                  </div>
                  {getStatusIcon(item.status)}
                </div>
                
                <div className="space-y-2">
                  <div className="flex justify-between text-sm">
                    <span className="text-gray-400">Ist:</span>
                    <span className="font-semibold">{item.ist.toFixed(1)}%</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span className="text-gray-400">Soll:</span>
                    <span className="text-gray-500">{item.ziel.toFixed(1)}%</span>
                  </div>
                  <div className="h-2 bg-[#1a1f37] rounded-full overflow-hidden">
                    <motion.div 
                      initial={{ width: 0 }}
                      animate={{ width: `${(item.ist / item.ziel) * 100}%` }}
                      transition={{ duration: 1, delay: 0.5 }}
                      className={`h-full rounded-full ${
                        item.status === 'optimal' ? 'bg-emerald-400' :
                        item.status === 'ok' ? 'bg-blue-400' :
                        item.status === 'warning' ? 'bg-yellow-400' : 'bg-red-400'
                      }`}
                    />
                  </div>
                  <p className={`text-xs ${item.differenz > 0 ? 'text-emerald-400' : 'text-red-400'}`}>
                    {item.differenz > 0 ? '+' : ''}{item.differenz.toFixed(1)}% Abweichung
                  </p>
                </div>
              </motion.div>
            ))}
          </div>

          {/* Rebalance Empfehlungen */}
          <div className="bg-[#0d1220] rounded-xl p-4 border border-[#1a1f37]">
            <h3 className="text-lg font-semibold mb-4 flex items-center gap-2">
              <TrendingUp className="w-5 h-5 text-[#f0b90b]" />
              Rebalance Empfehlungen
            </h3>
            <div className="space-y-3">
              {rebalanceEmpfehlungen.map((empf, index) => (
                <div 
                  key={index}
                  className={`flex items-start gap-3 p-3 rounded-lg ${
                    empf.typ === 'success' ? 'bg-emerald-500/10 border border-emerald-500/20' :
                    empf.typ === 'warning' ? 'bg-yellow-500/10 border border-yellow-500/20' :
                    'bg-blue-500/10 border border-blue-500/20'
                  }`}
                >
                  {empf.typ === 'success' ? <CheckCircle className="w-5 h-5 text-emerald-400 mt-0.5" /> :
                   empf.typ === 'warning' ? <AlertTriangle className="w-5 h-5 text-yellow-400 mt-0.5" /> :
                   <Info className="w-5 h-5 text-blue-400 mt-0.5" />}
                  <div>
                    <p className={`font-medium ${
                      empf.typ === 'success' ? 'text-emerald-400' :
                      empf.typ === 'warning' ? 'text-yellow-400' :
                      'text-blue-400'
                    }`}>{empf.titel}</p>
                    <p className="text-sm text-gray-400 mt-1">{empf.beschreibung}</p>
                    <p className="text-xs text-gray-500 mt-1">Priorität: {empf.prioritaet}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Sektoren & Länder Charts */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-8">
          {/* Sektoren Pie Chart */}
          <div className="glass-card rounded-xl p-6 border border-[#1a1f37]">
            <h2 className="text-xl font-semibold mb-4 flex items-center gap-2">
              <PieChart className="w-6 h-6 text-[#60B5FF]" />
              Sektoren-Verteilung
            </h2>
            <div className="h-[350px]">
              <ResponsiveContainer width="100%" height="100%">
                <RePieChart>
                  <Pie
                    data={sektorenDaten}
                    cx="50%"
                    cy="50%"
                    innerRadius={60}
                    outerRadius={120}
                    paddingAngle={2}
                    dataKey="prozent"
                    nameKey="sektor"
                  >
                    {sektorenDaten.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.farbe} />
                    ))}
                  </Pie>
                  <Tooltip content={<CustomPieTooltip />} />
                  <Legend 
                    layout="vertical" 
                    align="right" 
                    verticalAlign="middle"
                    wrapperStyle={{ fontSize: '12px', color: '#9CA3AF' }}
                  />
                </RePieChart>
              </ResponsiveContainer>
            </div>
            <div className="mt-4 grid grid-cols-2 gap-2 text-sm">
              <div className="text-gray-400">
                Top 3 Sektoren:
              </div>
              <div className="text-right">
                {sektorenDaten.slice(0, 3).map((s, i) => (
                  <div key={i} className="text-white">{s.sektor}: {s.prozent}%</div>
                ))}
              </div>
            </div>
          </div>

          {/* Länder Bar Chart */}
          <div className="glass-card rounded-xl p-6 border border-[#1a1f37]">
            <h2 className="text-xl font-semibold mb-4 flex items-center gap-2">
              <Globe className="w-6 h-6 text-[#f0b90b]" />
              Länder-Verteilung
            </h2>
            <div className="h-[350px]">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart
                  data={laenderDaten}
                  layout="vertical"
                  margin={{ top: 5, right: 30, left: 100, bottom: 5 }}
                >
                  <CartesianGrid strokeDasharray="3 3" stroke="#1a1f37" horizontal={false} />
                  <XAxis 
                    type="number" 
                    stroke="#4B5563"
                    tick={{ fill: '#9CA3AF', fontSize: 11 }}
                    tickFormatter={(value) => `${value}%`}
                  />
                  <YAxis 
                    dataKey="land" 
                    type="category" 
                    stroke="#4B5563"
                    tick={{ fill: '#9CA3AF', fontSize: 11 }}
                    width={95}
                  />
                  <Tooltip 
                    content={({ active, payload }) => {
                      if (active && payload && payload.length) {
                        const data = payload[0].payload;
                        return (
                          <div className="bg-[#0d1220] border border-[#1a1f37] rounded-lg p-3 shadow-xl">
                            <p className="font-semibold text-white">{data.land}</p>
                            <p className="text-[#60B5FF]">{data.wert.toLocaleString('de-DE')} €</p>
                            <p className="text-gray-400">{data.prozent}%</p>
                          </div>
                        );
                      }
                      return null;
                    }}
                  />
                  <Bar dataKey="prozent" radius={[0, 4, 4, 0]}>
                    {laenderDaten.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.farbe} />
                    ))}
                  </Bar>
                </BarChart>
              </ResponsiveContainer>
            </div>
            <div className="mt-4 text-sm">
              <p className="text-gray-400">
                Höchste Konzentration: <span className="text-white">Irland (ETF-Domicil)</span> mit 32.3%
              </p>
            </div>
          </div>
        </div>

        {/* Zusammenfassung */}
        <div className="glass-card rounded-xl p-6 border border-[#1a1f37]">
          <h2 className="text-xl font-semibold mb-4 flex items-center gap-2">
            <Shield className="w-6 h-6 text-emerald-400" />
            Zusammenfassung & Empfehlung
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <h3 className="text-lg font-medium mb-3 text-[#f0b90b]">Aktuelle Situation</h3>
              <ul className="space-y-2 text-gray-400">
                <li className="flex items-center gap-2">
                  <CheckCircle className="w-4 h-4 text-emerald-400" />
                  Performance-Block: Optimal (33.3%)
                </li>
                <li className="flex items-center gap-2">
                  <Info className="w-4 h-4 text-blue-400" />
                  Defensiv-Block: Leicht übergewichtet (37.8%)
                </li>
                <li className="flex items-center gap-2">
                  <AlertTriangle className="w-4 h-4 text-yellow-400" />
                  Absicherung: Untergewichtet (28.9%)
                </li>
                <li className="flex items-center gap-2">
                  <Globe className="w-4 h-4 text-[#60B5FF]" />
                  Stark diversifiziert über 10 Länder
                </li>
              </ul>
            </div>
            <div>
              <h3 className="text-lg font-medium mb-3 text-emerald-400">Handlungsempfehlung</h3>
              <div className="bg-[#0d1220] rounded-lg p-4 border border-[#1a1f37]">
                <p className="text-gray-300 leading-relaxed">
                  {VERTEILUNG_ZUSAMMENFASSUNG.balance.empfehlung}. Die Absicherung sollte auf 
                  ca. 33% erhöht werden. Optionen: Nachkauf von Gold-ETF oder defensive Positionen.
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* Bottom Navigation */}
        <div className="flex gap-4 mt-8">
          <Link 
            href="/entwicklung" 
            className="flex-1 bg-[#0d1220] border border-[#1a1f37] hover:border-[#f0b90b]/50 rounded-xl p-4 text-center transition-all"
          >
            <TrendingUp className="w-6 h-6 mx-auto mb-2 text-[#f0b90b]" />
            <p className="font-semibold">Entwicklung</p>
            <p className="text-sm text-gray-400">Depot-Verlauf ansehen</p>
          </Link>
          <Link 
            href="/depot" 
            className="flex-1 bg-[#0d1220] border border-[#1a1f37] hover:border-[#f0b90b]/50 rounded-xl p-4 text-center transition-all"
          >
            <Wallet className="w-6 h-6 mx-auto mb-2 text-[#f0b90b]" />
            <p className="font-semibold">Depot-Details</p>
            <p className="text-sm text-gray-400">Alle Positionen</p>
          </Link>
        </div>
      </main>
    </div>
  );
}