'use client';

import { useMemo } from 'react';
import { motion } from 'framer-motion';
import Link from 'next/link';
import { 
  TrendingUp, 
  TrendingDown, 
  Wallet, 
  Calendar,
  ArrowLeft,
  ArrowUpRight,
  ArrowDownRight,
  Target,
  AlertTriangle
} from 'lucide-react';
import SharedHeader from '@/components/shared-header';
import { depotPositionen, berechneDepotSummen, depotHistorie } from '@/data/depot';
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  ReferenceLine,
  Area,
  AreaChart,
  Legend
} from 'recharts';

export default function DepotEntwicklungPage() {
  const summen = berechneDepotSummen();
  
  // Chart-Daten vorbereiten
  const chartData = useMemo(() => {
    return depotHistorie.map(eintrag => ({
      ...eintrag,
      datumShort: new Date(eintrag.datum).toLocaleDateString('de-DE', { 
        month: 'short', 
        year: '2-digit' 
      }),
      gewinnVerlust: eintrag.depotwert - eintrag.investiert,
      performanceProzent: ((eintrag.depotwert - eintrag.investiert) / eintrag.investiert) * 100
    }));
  }, []);
  
  // Statistiken
  const stats = {
    hoch: Math.max(...depotHistorie.map(d => d.depotwert)),
    tief: Math.min(...depotHistorie.map(d => d.depotwert)),
    start: depotHistorie[0]?.depotwert || 0,
    aktuell: depotHistorie[depotHistorie.length - 1]?.depotwert || 0,
  };

  const CustomTooltip = ({ active, payload, label }: any) => {
    if (active && payload && payload.length) {
      const data = payload[0].payload;
      return (
        <div className="bg-[#0d1220] border border-[#1a1f37] rounded-lg p-4 shadow-xl">
          <p className="text-gray-400 text-sm mb-2">{new Date(data.datum).toLocaleDateString('de-DE', { 
            day: '2-digit', 
            month: 'long', 
            year: 'numeric' 
          })}</p>
          <div className="space-y-1">
            <p className="text-white">
              <span className="text-[#60B5FF]">Depotwert:</span> {data.depotwert.toLocaleString('de-DE')} €
            </p>
            <p className="text-gray-400">
              <span className="text-gray-500">Investiert:</span> {data.investiert.toLocaleString('de-DE')} €
            </p>
            <p className={data.gewinnVerlust >= 0 ? 'text-emerald-400' : 'text-red-400'}>
              <span className={data.gewinnVerlust >= 0 ? 'text-emerald-400' : 'text-red-400'}>
                {data.gewinnVerlust >= 0 ? '+' : ''}{data.gewinnVerlust.toLocaleString('de-DE')} €
              </span>
              <span className="text-gray-500 text-sm ml-2">
                ({data.performanceProzent >= 0 ? '+' : ''}{data.performanceProzent.toFixed(2)}%)
              </span>
            </p>
          </div>
        </div>
      );
    }
    return null;
  };

  return (
    <div className="min-h-screen bg-[#0a0e1a] text-white">
      <SharedHeader />

      <main className="pt-24 pb-12 px-4 sm:px-6 max-w-7xl mx-auto">
        {/* Header */}
        <div className="flex items-center gap-4 mb-6">
          <Link 
            href="/" 
            className="flex items-center gap-2 text-gray-400 hover:text-white transition-colors"
          >
            <ArrowLeft className="w-5 h-5" />
            <span>Zurück</span>
          </Link>
        </div>

        <div className="mb-8">
          <h1 className="text-3xl font-bold mb-2 flex items-center gap-3">
            <TrendingUp className="w-8 h-8 text-[#f0b90b]" />
            Depot-Entwicklung
          </h1>
          <p className="text-gray-400">
            Verlauf deines Depotwerts über die Zeit
          </p>
        </div>

        {/* Stats Overview */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-8">
          <div className="bg-[#0d1220] border border-[#1a1f37] rounded-xl p-4">
            <p className="text-xs text-gray-400 mb-1">Aktueller Wert</p>
            <p className="text-2xl font-bold text-white">{summen.gesamtWert.toLocaleString('de-DE')} €</p>
            <div className={`flex items-center gap-1 mt-1 ${summen.performanceProzent >= 0 ? 'text-emerald-400' : 'text-red-400'}`}>
              {summen.performanceProzent >= 0 ? <ArrowUpRight className="w-4 h-4" /> : <ArrowDownRight className="w-4 h-4" />}
              <span className="text-sm font-medium">{summen.performanceProzent >= 0 ? '+' : ''}{summen.performanceProzent}%</span>
            </div>
          </div>
          
          <div className="bg-[#0d1220] border border-[#1a1f37] rounded-xl p-4">
            <p className="text-xs text-gray-400 mb-1">Investiert</p>
            <p className="text-2xl font-bold text-white">{summen.investiert.toLocaleString('de-DE')} €</p>
            <p className="text-gray-500 text-sm mt-1">Gesamteinlage</p>
          </div>
          
          <div className="bg-[#0d1220] border border-[#1a1f37] rounded-xl p-4">
            <p className="text-xs text-gray-400 mb-1">Gewinn/Verlust</p>
            <p className={`text-2xl font-bold ${summen.gesamtGewinn >= 0 ? 'text-emerald-400' : 'text-red-400'}`}>
              {summen.gesamtGewinn >= 0 ? '+' : ''}{summen.gesamtGewinn.toLocaleString('de-DE')} €
            </p>
            <p className="text-gray-500 text-sm mt-1">Seit Kauf</p>
          </div>
          
          <div className="bg-[#0d1220] border border-[#1a1f37] rounded-xl p-4">
            <p className="text-xs text-gray-400 mb-1">Positionen</p>
            <p className="text-2xl font-bold text-white">{summen.anzahlPositionen}</p>
            <p className="text-gray-500 text-sm mt-1">Aktive Investments</p>
          </div>
        </div>

        {/* Main Chart */}
        <div className="glass-card rounded-xl p-6 mb-8 border border-[#1a1f37]">
          <div className="flex items-center justify-between mb-6">
            <div>
              <h2 className="text-xl font-semibold flex items-center gap-2">
                <Calendar className="w-6 h-6 text-[#f0b90b]" />
                Depot-Verlauf
              </h2>
              <p className="text-gray-400 text-sm mt-1">
                Depotwert vs. Investiertes Kapital
              </p>
            </div>
            <div className="flex items-center gap-4">
              <div className="flex items-center gap-2">
                <div className="w-3 h-3 rounded-full bg-[#60B5FF]" />
                <span className="text-sm text-gray-400">Depotwert</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-3 h-3 rounded-full bg-gray-500" />
                <span className="text-sm text-gray-400">Investiert</span>
              </div>
            </div>
          </div>
          
          <div className="h-[400px] w-full">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={chartData} margin={{ top: 10, right: 30, left: 0, bottom: 0 }}>
                <defs>
                  <linearGradient id="colorDepot" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#60B5FF" stopOpacity={0.3}/>
                    <stop offset="95%" stopColor="#60B5FF" stopOpacity={0}/>
                  </linearGradient>
                  <linearGradient id="colorInvest" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#9CA3AF" stopOpacity={0.1}/>
                    <stop offset="95%" stopColor="#9CA3AF" stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="#1a1f37" />
                <XAxis 
                  dataKey="datumShort" 
                  stroke="#4B5563"
                  tick={{ fill: '#9CA3AF', fontSize: 12 }}
                />
                <YAxis 
                  stroke="#4B5563"
                  tick={{ fill: '#9CA3AF', fontSize: 12 }}
                  tickFormatter={(value) => `${(value / 1000).toFixed(0)}k €`}
                  domain={['dataMin - 500', 'dataMax + 500']}
                />
                <Tooltip content={<CustomTooltip />} />
                <ReferenceLine y={summen.investiert} stroke="#9CA3AF" strokeDasharray="3 3" />
                <Area 
                  type="monotone" 
                  dataKey="depotwert" 
                  stroke="#60B5FF" 
                  strokeWidth={3}
                  fillOpacity={1} 
                  fill="url(#colorDepot)" 
                  name="Depotwert"
                />
                <Area 
                  type="monotone" 
                  dataKey="investiert" 
                  stroke="#9CA3AF" 
                  strokeWidth={2}
                  strokeDasharray="5 5"
                  fillOpacity={1} 
                  fill="url(#colorInvest)" 
                  name="Investiert"
                />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Performance Stats */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
          <div className="glass-card rounded-xl p-6 border border-[#1a1f37]">
            <h3 className="text-lg font-semibold mb-4 flex items-center gap-2">
              <Target className="w-5 h-5 text-[#f0b90b]" />
              Performance-Highlights
            </h3>
            <div className="space-y-4">
              <div className="flex justify-between items-center">
                <span className="text-gray-400">Höchster Depotwert</span>
                <span className="font-semibold text-emerald-400">{stats.hoch.toLocaleString('de-DE')} €</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-gray-400">Tiefster Depotwert</span>
                <span className="font-semibold text-red-400">{stats.tief.toLocaleString('de-DE')} €</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-gray-400">Startwert</span>
                <span className="font-semibold text-white">{stats.start.toLocaleString('de-DE')} €</span>
              </div>
              <div className="border-t border-[#1a1f37] pt-4">
                <div className="flex justify-between items-center">
                  <span className="text-gray-400">Max. Drawdown</span>
                  <span className="font-semibold text-red-400">
                    -{(((stats.hoch - stats.tief) / stats.hoch) * 100).toFixed(1)}%
                  </span>
                </div>
              </div>
            </div>
          </div>

          <div className="glass-card rounded-xl p-6 border border-[#1a1f37]">
            <h3 className="text-lg font-semibold mb-4 flex items-center gap-2">
              <AlertTriangle className="w-5 h-5 text-orange-400" />
              Risk Indicators
            </h3>
            <div className="space-y-4">
              <div>
                <div className="flex justify-between mb-2">
                  <span className="text-gray-400">Volatilität</span>
                  <span className="text-yellow-400">Mittel</span>
                </div>
                <div className="h-2 bg-[#1a1f37] rounded-full overflow-hidden">
                  <div className="h-full bg-yellow-400 rounded-full" style={{ width: '60%' }} />
                </div>
              </div>
              <div>
                <div className="flex justify-between mb-2">
                  <span className="text-gray-400">Verlustquote</span>
                  <span className="text-red-400">Hoch</span>
                </div>
                <div className="h-2 bg-[#1a1f37] rounded-full overflow-hidden">
                  <div className="h-full bg-red-400 rounded-full" style={{ width: '75%' }} />
                </div>
              </div>
              <div>
                <div className="flex justify-between mb-2">
                  <span className="text-gray-400">Diversifikation</span>
                  <span className="text-emerald-400">Gut</span>
                </div>
                <div className="h-2 bg-[#1a1f37] rounded-full overflow-hidden">
                  <div className="h-full bg-emerald-400 rounded-full" style={{ width: '80%' }} />
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Bottom Navigation */}
        <div className="flex gap-4">
          <Link 
            href="/depot" 
            className="flex-1 bg-[#0d1220] border border-[#1a1f37] hover:border-[#f0b90b]/50 rounded-xl p-4 text-center transition-all"
          >
            <Wallet className="w-6 h-6 mx-auto mb-2 text-[#f0b90b]" />
            <p className="font-semibold">Depot-Details</p>
            <p className="text-sm text-gray-400">Alle Positionen ansehen</p>
          </Link>
          <Link 
            href="/matrix" 
            className="flex-1 bg-[#0d1220] border border-[#1a1f37] hover:border-[#f0b90b]/50 rounded-xl p-4 text-center transition-all"
          >
            <TrendingUp className="w-6 h-6 mx-auto mb-2 text-[#f0b90b]" />
            <p className="font-semibold">Matrix 2.0</p>
            <p className="text-sm text-gray-400">Empfehlungen checken</p>
          </Link>
        </div>
      </main>
    </div>
  );
}