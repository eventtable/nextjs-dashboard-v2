'use client';

import { useState, useEffect, Suspense } from 'react';
import { useSearchParams } from 'next/navigation';
import Link from 'next/link';
import { 
  Search, 
  TrendingUp, 
  Activity,
  LayoutGrid,
  CheckSquare,
  Users,
  DollarSign,
  AlertTriangle,
  ArrowLeft,
  Zap
} from 'lucide-react';
import SharedHeader from '@/components/shared-header';
import MatrixAmpel from '@/components/matrix-ampel';
import FundamentalAnalysis from '@/components/fundamental-analysis';
import TechnicalAnalysis from '@/components/technical-analysis';
import PeerComparison from '@/components/peer-comparison';
import DividendAnalysis from '@/components/dividend-analysis';
import MatrixChecklist from '@/components/matrix-checklist';
import BlackSwanSimulation from '@/components/black-swan-simulation';
import StockChart from '@/components/stock-chart';
import StockOverview from '@/components/stock-overview';
import EarlyWarnings from '@/components/early-warnings';
import type { StockData } from '@/lib/types';

// Tabs für die Analyse
const tabs = [
  { id: 'overview', label: 'Übersicht', icon: Activity },
  { id: 'fundamental', label: 'Fundamental', icon: DollarSign },
  { id: 'technical', label: 'Technisch', icon: TrendingUp },
  { id: 'peers', label: 'Aktienpaare', icon: Users },
  { id: 'dividend', label: 'Dividenden', icon: DollarSign },
  { id: 'checklist', label: 'Checkliste', icon: CheckSquare },
  { id: 'blackswan', label: 'Black Swan', icon: AlertTriangle },
];

// Schnellauswahl Aktien - REDUZIERT: Depot + Indizes
const quickStocks = [
  // === INDEZES ===
  { ticker: '^GDAXI', name: '🇩🇪 DAX' },
  { ticker: '^GSPC', name: '🇺🇸 S&P 500' },
  { ticker: '^IXIC', name: '🇺🇸 NASDAQ' },
  
  // === DEPOT AKTIV (Frank's Positionen) ===
  { ticker: 'SAP.DE', name: 'SAP' },
  { ticker: 'MSF.DE', name: 'Microsoft' },
  { ticker: 'ALV.DE', name: 'Allianz' },
  { ticker: 'MUV2.DE', name: 'Munich Re' },
  { ticker: 'NOVO-B.CO', name: 'Novo Nordisk' },
  { ticker: 'MBK.DE', name: 'MBB SE' },
  { ticker: 'ABX.TO', name: 'Barrick Gold' },
  { ticker: 'BYD', name: 'BYD' },
  
  // === DEPOT ETFs ===
  { ticker: 'EXS1.DE', name: 'iShares DAX' },
  { ticker: 'EUNL.DE', name: 'MSCI World' },
  { ticker: 'SXRV.DE', name: 'NASDAQ 100' },
  { ticker: 'QDVC.F', name: 'Dividenden Arist.' },
];

function MatrixContent() {
  const searchParams = useSearchParams();
  const initialTicker = searchParams.get('ticker') || searchParams.get('search') || '';
  
  const [ticker, setTicker] = useState(initialTicker);
  const [activeTab, setActiveTab] = useState('overview');
  const [stockData, setStockData] = useState<StockData | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [chartRange, setChartRange] = useState<'1y' | '5y'>('1y');

  const fetchStock = async (t: string) => {
    if (!t) return;
    setLoading(true);
    setError(null);
    try {
      const res = await fetch(`/api/stock?ticker=${encodeURIComponent(t)}&range=${chartRange}`);
      const data = await res.json();
      if (!res.ok) {
        setError(data?.error || 'Fehler beim Laden');
        setStockData(null);
      } else {
        setStockData(data);
      }
    } catch (err) {
      setError('Netzwerkfehler');
      setStockData(null);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (initialTicker) {
      fetchStock(initialTicker);
    }
  }, [initialTicker]);

  // Wenn sich der Zeitraum ändert und wir bereits Daten haben, neu laden
  useEffect(() => {
    if (stockData?.ticker) {
      fetchStock(stockData.ticker);
    }
  }, [chartRange]);

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    fetchStock(ticker);
  };

  return (
    <div className="min-h-screen bg-[#0a0e1a] text-white pb-12">
      <SharedHeader />
      
      <main className="pt-24 px-4 sm:px-6 max-w-7xl mx-auto">
        {/* Header */}
        <div className="mb-6">
          <Link 
            href="/" 
            className="inline-flex items-center gap-2 text-gray-400 hover:text-[#f0b90b] transition-colors mb-4"
          >
            <ArrowLeft className="w-4 h-4" />
            Zurück zum Dashboard
          </Link>
          
          <h1 className="text-2xl font-bold flex items-center gap-3">
            <LayoutGrid className="w-7 h-7 text-[#f0b90b]" />
            Matrix 2.0 Analyse
          </h1>
          <p className="text-gray-400 text-sm mt-1">
            Detaillierte Einzelaktien-Analyse mit allen Tools
          </p>
        </div>

        {/* Search Bar */}
        <div className="glass-card rounded-xl p-4 mb-6 border border-[#1a1f37]">
          <form onSubmit={handleSearch} className="flex gap-3">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
              <input
                type="text"
                value={ticker}
                onChange={(e) => setTicker(e.target.value)}
                placeholder="Ticker eingeben (z.B. SAP.DE, AAPL, MSFT...)"
                className="w-full bg-[#0d1220] border border-[#2a2f47] rounded-lg pl-10 pr-4 py-3 text-white placeholder-gray-500 focus:outline-none focus:border-[#f0b90b]"
              />
            </div>
            <button
              type="submit"
              disabled={loading || !ticker}
              className="bg-[#f0b90b] hover:bg-[#d4a017] disabled:bg-gray-600 text-black font-semibold px-6 py-3 rounded-lg transition-all"
            >
              {loading ? 'Lädt...' : 'Analysieren'}
            </button>
          </form>
          
          {/* Quick Select */}
          <div className="flex gap-2 mt-3 flex-wrap">
            <span className="text-gray-500 text-xs">Schnell:</span>
            {quickStocks.map((stock) => (
              <button
                key={stock.ticker}
                onClick={() => { setTicker(stock.ticker); fetchStock(stock.ticker); }}
                className="text-xs px-3 py-1 rounded-full bg-[#0d1220] hover:bg-[#1a1f37] text-gray-300 hover:text-[#f0b90b] border border-[#2a2f47] transition-all"
              >
                {stock.name}
              </button>
            ))}
          </div>
        </div>

        {/* Error */}
        {error && (
          <div className="glass-card rounded-xl p-4 mb-6 border-l-4 border-red-500">
            <div className="flex items-center gap-2 text-red-400">
              <AlertTriangle className="w-5 h-5" />
              <span>{error}</span>
            </div>
          </div>
        )}

        {/* No Data State */}
        {!stockData && !loading && !error && (
          <div className="flex flex-col items-center justify-center py-20">
            <Zap className="w-16 h-16 text-[#f0b90b] mb-4 opacity-30" />
            <p className="text-gray-500 text-lg">Aktie suchen, um die Analyse zu starten</p>
            <p className="text-gray-600 text-sm mt-1">Oder wähle eine aus deinem Depot aus</p>
            
            {/* Depot Quick Links */}
            <div className="mt-6 grid grid-cols-4 gap-3">
              {['SAP.DE', 'MSFT', 'BYD6.DE', 'GOLD'].map((t) => (
                <button
                  key={t}
                  onClick={() => { setTicker(t); fetchStock(t); }}
                  className="px-4 py-2 bg-[#0d1220] border border-[#2a2f47] rounded-lg text-sm text-gray-300 hover:text-[#f0b90b] hover:border-[#f0b90b]/50 transition-all"
                >
                  {t}
                </button>
              ))}
            </div>
          </div>
        )}

        {/* Content with Tabs */}
        {stockData && !loading && (
          <>
            {/* Tabs */}
            <div className="flex gap-1 overflow-x-auto pb-2 mb-6 scrollbar-hide">
              {tabs.map((tab) => {
                const Icon = tab.icon;
                return (
                  <button
                    key={tab.id}
                    onClick={() => setActiveTab(tab.id)}
                    className={`flex items-center gap-2 px-4 py-2 rounded-lg text-sm whitespace-nowrap transition-all ${
                      activeTab === tab.id
                        ? 'bg-[#f0b90b] text-black font-medium'
                        : 'bg-[#0d1220] text-gray-400 hover:text-white border border-[#1a1f37]'
                    }`}
                  >
                    <Icon className="w-4 h-4" />
                    {tab.label}
                  </button>
                );
              })}
            </div>

            {/* Tab Content */}
            <div className="space-y-6">
              {activeTab === 'overview' && (
                <>
                  <StockOverview data={stockData} />
                  <MatrixAmpel data={stockData} />
                  <EarlyWarnings data={stockData} />
                  <StockChart data={stockData} range={chartRange} onRangeChange={setChartRange} />
                </>
              )}
              
              {activeTab === 'fundamental' && (
                <FundamentalAnalysis data={stockData} />
              )}
              
              {activeTab === 'technical' && (
                <TechnicalAnalysis data={stockData} />
              )}
              
              {activeTab === 'peers' && (
                <PeerComparison 
                  currentTicker={stockData.ticker} 
                  onAnalyze={(t) => { setTicker(t); fetchStock(t); }}
                />
              )}
              
              {activeTab === 'dividend' && (
                <DividendAnalysis data={stockData} />
              )}
              
              {activeTab === 'checklist' && (
                <MatrixChecklist data={stockData} />
              )}
              
              {activeTab === 'blackswan' && (
                <BlackSwanSimulation data={stockData} />
              )}
            </div>
          </>
        )}
      </main>
    </div>
  );
}

// Loading fallback
function MatrixLoading() {
  return (
    <div className="min-h-screen bg-[#0a0e1a] text-white flex items-center justify-center">
      <div className="flex flex-col items-center gap-4">
        <div className="w-12 h-12 border-4 border-[#f0b90b]/30 border-t-[#f0b90b] rounded-full animate-spin" />
        <p className="text-gray-400">Matrix wird geladen...</p>
      </div>
    </div>
  );
}

export default function MatrixPage() {
  return (
    <Suspense fallback={<MatrixLoading />}>
      <MatrixContent />
    </Suspense>
  );
}
