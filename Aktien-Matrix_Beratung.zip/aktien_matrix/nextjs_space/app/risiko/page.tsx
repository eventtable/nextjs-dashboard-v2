'use client';

import { useState, useMemo } from 'react';
import { motion } from 'framer-motion';
import { ShieldAlert, TrendingDown, AlertTriangle, Activity, Globe, Shield, DollarSign, PieChart, Bird, History, Target, Calculator, ChevronDown, ChevronUp, CheckCircle } from 'lucide-react';
import SharedHeader from '@/components/shared-header';
import RiskHeatmap from '@/components/risk-heatmap';
import { riskScenarios, berechneScenarioImpact } from '@/data/riskScenarios';
import { riskIndicators } from '@/data/riskIndicators';
import { depotPositionen } from '@/data/depot';

// Historische Black Swan Events
const historicalBlackSwans = [
  {
    id: '2008-crisis',
    year: '2008',
    name: 'Finanzkrise / Lehman Brothers',
    trigger: 'Lehman Brothers Bankrott, Subprime-Krise',
    sp500Drop: -57.0,
    recoveryDays: 1267,
    description: 'Die größte Finanzkrise seit der Großen Depression. Banken kollabierten, Aktienmärkte stürzten weltweit ab.',
    lessons: ['Diversifikation über Asset-Klassen', 'Liquidität ist König', 'Keine Hebelprodukte']
  },
  {
    id: '2020-covid',
    year: '2020',
    name: 'COVID-19 Crash',
    trigger: 'Pandemie-Ausbruch, globale Lockdowns',
    sp500Drop: -34.0,
    recoveryDays: 126,
    description: 'Schnellster Bärenmarkt der Geschichte, gefolgt von einer der schnellsten Erholungen dank Monetärer Politik.',
    lessons: ['Fälle nicht versuchen zu timen', 'Tech-Aktien outperformen', 'Zentralbanken retten Märkte']
  },
  {
    id: '2000-dotcom',
    year: '2000-2002',
    name: 'Dotcom-Blase',
    trigger: 'Internet-Blase platzt',
    sp500Drop: -49.0,
    recoveryDays: 1816,
    description: 'Spekulativer Exzess bei Internet-Aktien endete in einem Jahrzehnt der Stagnation.',
    lessons: ['Bewertung zählt langfristig', 'Gewinnlos = riskant', 'Diversifikation wichtig']
  },
  {
    id: '1987-black-monday',
    year: '1987',
    name: 'Black Monday',
    trigger: 'Programmhandel, Panik',
    sp500Drop: -20.5,
    recoveryDays: 68,
    description: 'An einem einzigen Tag verlor der Dow Jones 22%. Der schnellste Crash, aber auch schnellste Erholung.',
    lessons: ['Markteffizienz ist fragil', 'Panik ist kurzlebig', 'Dollar-Cost-Averaging hilft']
  },
  {
    id: '2022-inflation',
    year: '2022',
    name: 'Inflations-Schock',
    trigger: 'Höchste Inflation in 40 Jahren, aggressive Fed',
    sp500Drop: -25.0,
    recoveryDays: 300,
    description: 'Tech-Aktien verloren 30-80%, Growth wurde brutal bestraft, Value outperformte.',
    lessons: ['Zinsen töten Growth', 'Cash-Management wichtig', 'Duration-Mismatch vermeiden']
  }
];

// Hedge Strategien
const hedgeStrategies = [
  {
    name: 'Gold & Edelmetalle',
    allocation: '5-10%',
    description: 'Gold als Krisenwährung, steigt bei Panik und Inflation',
    pros: ['Liquide', 'Keine Gegenpartei-Risiken', 'Historisch bewährt'],
    cons: ['Kein Yield', 'Lagerungskosten', 'Volatil'],
    current: 'Du hast: GOLD + IGLN.L (~8%)'
  },
  {
    name: 'Anleihen & Cash',
    allocation: '15-25%',
    description: 'Kurzfristige Staatsanleihen und Cash-Reserven',
    pros: ['Kaufkraft in Crashes', 'Trockenes Pulver', 'Stabilität'],
    cons: ['Opportunity Cost', 'Inflationsverlust', 'Niedrige Rendite'],
    current: 'Du hast: Anleihen (~5%) - AUSBAUFÄHIG'
  },
  {
    name: 'Defensive Aktien',
    allocation: '20-30%',
    description: 'Versicherungen, Utilities, Consumer Staples',
    pros: ['Dividenden', 'Weniger volatil', 'Rezessionsresistent'],
    cons: ['Langsames Wachstum', 'Zins-sensitiv', 'Underperform in Booms'],
    current: 'Du hast: Allianz, Munich Re (~10%)'
  },
  {
    name: 'Inverse ETFs',
    allocation: '2-5%',
    description: 'S&P 500 Short ETFs als Versicherung',
    pros: ['Direkter Schutz', 'Liquide', 'Einfach'],
    cons: ['Time Decay', 'Hohe Kosten', 'Komplex'],
    current: 'Nicht im Depot'
  },
  {
    name: 'Cash-Reserve',
    allocation: '10-15%',
    description: 'Cash für Nachkäufe bei Panikverkäufen',
    pros: ['Optionality', 'Psychologischer Vorteil', 'Kein Risiko'],
    cons: ['Inflation frisst', 'FOMO in Bullenmärkten', 'Opportunity Cost'],
    current: 'Sparplan: 200€/Monat verfügbar'
  }
];

export default function RisikoPage() {
  const [activeScenario, setActiveScenario] = useState<string | null>(null);
  const [customDropPercent, setCustomDropPercent] = useState(20);
  const [showCustomSimulation, setShowCustomSimulation] = useState(false);
  const [expandedHistorical, setExpandedHistorical] = useState<string | null>(null);
  const [expandedStrategy, setExpandedStrategy] = useState<string | null>(null);
  const [showCalculator, setShowCalculator] = useState(false);
  const [riskInputs, setRiskInputs] = useState({
    portfolioSize: 8659,
    monthlyContribution: 200,
    maxDrawdown: 50,
    recoveryRate: 15
  });

  const selectedScenario = riskScenarios.find(s => s.id === activeScenario);
  const totalValue = depotPositionen.reduce((sum, p) => sum + p.wertEur, 0);

  // Berechne Impact für ausgewähltes Szenario
  const scenarioImpact = useMemo(() => {
    if (!selectedScenario) return null;
    return berechneScenarioImpact(selectedScenario, depotPositionen);
  }, [selectedScenario]);

  // Custom Black Swan Simulation
  const customSimulation = useMemo(() => {
    if (!showCustomSimulation) return null;
    const newTotalValue = totalValue * (1 - customDropPercent / 100);
    const loss = totalValue - newTotalValue;
    const recoveryNeeded = (totalValue / newTotalValue - 1) * 100;
    return {
      before: totalValue,
      after: newTotalValue,
      loss,
      percentLoss: customDropPercent,
      recoveryNeeded
    };
  }, [customDropPercent, showCustomSimulation, totalValue]);

  // Risk of Ruin Calculator
  const riskOfRuin = useMemo(() => {
    const { portfolioSize, monthlyContribution, maxDrawdown, recoveryRate } = riskInputs;
    const ruinThreshold = portfolioSize * (1 - maxDrawdown / 100);
    const monthsToRuin = portfolioSize / monthlyContribution;
    const probabilityOfRuin = Math.min(100, (maxDrawdown / 100) * (1 - recoveryRate / 100) * 100);
    return { ruinThreshold, monthsToRuin, probabilityOfRuin };
  }, [riskInputs]);

  return (
    <div className="min-h-screen bg-[#0a0e1a] text-white">
      {/* Shared Header mit Navigation */}
      <SharedHeader />

      {/* Main Content - mit Padding für den fixed Header */}
      <main className="pt-20 pb-12 px-4 sm:px-6 max-w-7xl mx-auto">
        {/* Header */}
        <div className="mb-6">
          <h1 className="text-2xl lg:text-3xl font-bold mb-2 flex items-center gap-3">
            <ShieldAlert className="w-8 h-8 text-[#f0b90b]" />
            Risiko-Analyse
          </h1>
          <p className="text-gray-400">
            Professionelle Risiko-Bewertung wie bei Asset Managern
          </p>
        </div>

        {/* Risiko-Status Banner */}
        <div className="glass-card rounded-xl p-4 mb-6 border border-yellow-500/30 bg-yellow-500/10">
          <div className="flex items-center gap-3">
            <AlertTriangle className="w-6 h-6 text-yellow-400" />
            <div>
              <h3 className="font-semibold text-yellow-400">Aktuelles Risiko-Level: ANGESPANNT</h3>
              <p className="text-sm text-gray-400">
                VIX: 18.5 | Yield Curve: Leicht invertiert | Geopolitische Spannungen
              </p>
            </div>
          </div>
        </div>

        {/* Haupt-Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-6">
          {/* Depot Heatmap */}
          <div className="lg:col-span-2">
            <RiskHeatmap positions={depotPositionen} totalValue={totalValue} />
          </div>

          {/* Szenario-Auswahl */}
          <div className="glass-card rounded-xl p-4">
            <h3 className="text-lg font-semibold mb-4 flex items-center gap-2">
              <Globe className="w-5 h-5 text-[#f0b90b]" />
              Risiko-Szenarien
            </h3>
            <div className="space-y-2 max-h-[400px] overflow-y-auto">
              {riskScenarios.map((scenario) => (
                <button
                  key={scenario.id}
                  onClick={() => {
                    setActiveScenario(scenario.id);
                    setShowCustomSimulation(false);
                  }}
                  className={`w-full p-3 rounded-lg text-left transition-all border ${
                    activeScenario === scenario.id
                      ? 'bg-[#f0b90b]/20 border-[#f0b90b]'
                      : 'bg-[#0f1629] border-[#1a1f37] hover:border-[#2a2f47]'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <span className="font-medium text-sm">{scenario.name}</span>
                    <span className={`text-xs px-2 py-0.5 rounded ${
                      scenario.impact === 'severe' ? 'bg-red-500/20 text-red-400' :
                      scenario.impact === 'high' ? 'bg-orange-500/20 text-orange-400' :
                      scenario.impact === 'medium' ? 'bg-yellow-500/20 text-yellow-400' :
                      'bg-green-500/20 text-green-400'
                    }`}>
                      {scenario.impact.toUpperCase()}
                    </span>
                  </div>
                  <div className="flex items-center justify-between mt-1">
                    <span className={`text-xs ${
                      scenario.estimatedImpact < 0 ? 'text-red-400' : 'text-green-400'
                    }`}>
                      {scenario.estimatedImpact > 0 ? '+' : ''}{scenario.estimatedImpact}%
                    </span>
                    <span className="text-xs text-gray-500">{scenario.probability}</span>
                  </div>
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* BLACK SWAN SIMULATOR - NEU */}
        <div className="glass-card rounded-xl p-6 mb-6 border border-red-500/30">
          <h3 className="text-lg font-semibold mb-4 flex items-center gap-2">
            <Shield className="w-6 h-6 text-red-400" />
            🦢 Black Swan Simulator - Portfolio Impact
          </h3>
          <p className="text-sm text-gray-400 mb-4">
            Simulieren Sie einen plötzlichen Kurssturz und sehen Sie die Auswirkung auf Ihr gesamtes Depot.
            Aktueller Depotwert: <span className="text-[#f0b90b] font-semibold">{totalValue.toLocaleString('de-DE')} €</span>
          </p>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4">
            <div>
              <label className="text-xs text-gray-500 block mb-1">Kursverfall (%)</label>
              <input
                type="range"
                min="5"
                max="50"
                step="5"
                value={customDropPercent}
                onChange={(e) => {
                  setCustomDropPercent(parseInt(e.target.value));
                  setShowCustomSimulation(true);
                  setActiveScenario(null);
                }}
                className="w-full accent-red-500"
              />
              <div className="text-center text-red-400 font-bold">-{customDropPercent}%</div>
            </div>
            <div className="flex items-end">
              <button
                onClick={() => setShowCustomSimulation(true)}
                className="w-full bg-red-500/20 hover:bg-red-500/30 text-red-400 border border-red-500/30 px-4 py-2 rounded-lg text-sm font-semibold transition-all flex items-center justify-center gap-2"
              >
                <TrendingDown className="w-4 h-4" />
                Simulation starten
              </button>
            </div>
            <div className="flex items-end">
              <button
                onClick={() => {
                  setShowCustomSimulation(false);
                  setCustomDropPercent(20);
                }}
                className="w-full bg-[#1a1f37] hover:bg-[#2a2f47] text-gray-400 px-4 py-2 rounded-lg text-sm transition-all"
              >
                Zurücksetzen
              </button>
            </div>
          </div>

          {/* Custom Simulation Ergebnis */}
          {customSimulation && (
            <motion.div
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              className="border border-red-500/20 rounded-lg p-4 bg-red-500/5"
            >
              <h4 className="text-sm font-semibold text-red-400 mb-3 flex items-center gap-2">
                <AlertTriangle className="w-4 h-4" />
                Simuliertes Szenario: -{customSimulation.percentLoss}% Crash
              </h4>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                <div className="bg-[#0f1629] rounded-lg p-3">
                  <p className="text-[10px] text-gray-500">Vorher</p>
                  <p className="text-lg font-bold text-white">{customSimulation.before.toLocaleString('de-DE')} €</p>
                </div>
                <div className="bg-[#0f1629] rounded-lg p-3">
                  <p className="text-[10px] text-gray-500">Nachher</p>
                  <p className="text-lg font-bold text-red-400">{customSimulation.after.toLocaleString('de-DE')} €</p>
                </div>
                <div className="bg-[#0f1629] rounded-lg p-3">
                  <p className="text-[10px] text-gray-500">Verlust</p>
                  <p className="text-lg font-bold text-red-500">-{customSimulation.loss.toLocaleString('de-DE')} €</p>
                </div>
              </div>
              <div className="mt-3 p-3 bg-[#0f1629] rounded-lg">
                <p className="text-xs text-gray-400">
                  <span className="text-[#f0b90b] font-semibold">Matrix 2.0 Tipp:</span> Bei einem Einbruch von –{customDropPercent}% 
                  sollten Sie Cash-Reserven (Sparplan) für Nachkäufe nutzen. Prüfen Sie Stop-Loss-Levels und Fundamentaldaten.
                </p>
              </div>
            </motion.div>
          )}
        </div>

        {/* Szenario-Details mit Depot-Impact */}
        {scenarioImpact && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="glass-card rounded-xl p-6 mb-6 border border-[#f0b90b]/30"
          >
            <h3 className="text-xl font-semibold mb-4 flex items-center gap-2">
              <TrendingDown className="w-6 h-6 text-red-400" />
              {scenarioImpact.scenario.name} - Depot Impact
            </h3>
            <p className="text-gray-300 mb-4">{scenarioImpact.scenario.description}</p>
            
            {/* Depot Impact Cards */}
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
              <div className="bg-[#0f1629] rounded-lg p-4 border border-[#1a1f37]">
                <p className="text-xs text-gray-500 mb-1">Depot vorher</p>
                <p className="text-xl font-bold text-white">{scenarioImpact.totalValueBefore.toLocaleString('de-DE')} €</p>
              </div>
              <div className="bg-[#0f1629] rounded-lg p-4 border border-[#1a1f37]">
                <p className="text-xs text-gray-500 mb-1">Depot nachher</p>
                <p className={`text-xl font-bold ${scenarioImpact.totalValueAfter < scenarioImpact.totalValueBefore ? 'text-red-400' : 'text-green-400'}`}>
                  {scenarioImpact.totalValueAfter.toLocaleString('de-DE')} €
                </p>
              </div>
              <div className="bg-[#0f1629] rounded-lg p-4 border border-[#1a1f37]">
                <p className="text-xs text-gray-500 mb-1">Gesamt-Impact</p>
                <p className={`text-xl font-bold ${scenarioImpact.depotImpact < 0 ? 'text-red-500' : 'text-green-500'}`}>
                  {scenarioImpact.depotImpact > 0 ? '+' : ''}{scenarioImpact.depotImpact.toFixed(1)}%
                </p>
              </div>
              <div className="bg-[#0f1629] rounded-lg p-4 border border-[#1a1f37]">
                <p className="text-xs text-gray-500 mb-1">Betroffene Positionen</p>
                <p className="text-xl font-bold text-[#f0b90b]">{scenarioImpact.affectedPositions.length}</p>
              </div>
            </div>

            {/* Betroffene Positionen Detail */}
            {scenarioImpact.affectedPositions.length > 0 && (
              <div className="mb-6">
                <h4 className="text-sm font-semibold mb-3 flex items-center gap-2">
                  <PieChart className="w-4 h-4 text-[#f0b90b]" />
                  Betroffene Positionen im Detail
                </h4>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
                  {scenarioImpact.affectedPositions.map((pos) => (
                    <div key={pos.ticker} className="bg-[#0f1629] rounded-lg p-3 border border-[#1a1f37]">
                      <div className="flex justify-between items-start">
                        <div>
                          <p className="font-semibold text-sm">{pos.name}</p>
                          <p className="text-xs text-gray-500">{pos.ticker}</p>
                        </div>
                        <span className={`text-xs px-2 py-0.5 rounded ${pos.impact < 0 ? 'bg-red-500/20 text-red-400' : 'bg-green-500/20 text-green-400'}`}>
                          {pos.impact > 0 ? '+' : ''}{pos.impact.toFixed(1)}%
                        </span>
                      </div>
                      <div className="mt-2 text-xs text-gray-400">
                        <div className="flex justify-between">
                          <span>Vorher:</span>
                          <span>{pos.wertEur.toLocaleString('de-DE')} €</span>
                        </div>
                        <div className="flex justify-between">
                          <span>Nachher:</span>
                          <span className={pos.newValue < pos.wertEur ? 'text-red-400' : 'text-green-400'}>
                            {pos.newValue.toLocaleString('de-DE')} €
                          </span>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="bg-[#0f1629] rounded-lg p-4">
                <p className="text-sm font-medium mb-2 text-gray-400 flex items-center gap-2">
                  <AlertTriangle className="w-4 h-4 text-[#f0b90b]" />
                  Auslöser:
                </p>
                <ul className="text-sm space-y-1">
                  {scenarioImpact.scenario.triggers.map((t, i) => (
                    <li key={i} className="flex items-center gap-2">
                      <span className="w-1.5 h-1.5 bg-[#f0b90b] rounded-full" />
                      {t}
                    </li>
                  ))}
                </ul>
              </div>
              <div className="bg-[#0f1629] rounded-lg p-4">
                <p className="text-sm font-medium mb-2 text-gray-400 flex items-center gap-2">
                  <Shield className="w-4 h-4 text-green-400" />
                  Mitigation:
                </p>
                <ul className="text-sm space-y-1">
                  {scenarioImpact.scenario.mitigation.map((m, i) => (
                    <li key={i} className="flex items-center gap-2">
                      <span className="w-1.5 h-1.5 bg-green-400 rounded-full" />
                      {m}
                    </li>
                  ))}
                </ul>
              </div>
            </div>
          </motion.div>
        )}

        {/* HISTORISCHE BLACK SWANS */}
        <div className="glass-card rounded-xl p-6 mb-8">
          <h2 className="text-xl font-semibold mb-4 flex items-center gap-2">
            <History className="w-6 h-6 text-[#f0b90b]" />
            Historische Black Swans
          </h2>
          
          <div className="space-y-3">
            {historicalBlackSwans.map((event) => (
              <div key={event.id} className="bg-[#0f1629] rounded-lg border border-[#1a1f37] overflow-hidden">
                <button
                  onClick={() => setExpandedHistorical(expandedHistorical === event.id ? null : event.id)}
                  className="w-full p-4 flex items-center justify-between hover:bg-[#1a1f37] transition-colors"
                >
                  <div className="flex items-center gap-4">
                    <span className="text-2xl font-bold text-[#f0b90b] w-16">{event.year}</span>
                    <div className="text-left">
                      <p className="font-semibold">{event.name}</p>
                      <p className="text-sm text-gray-400">{event.trigger}</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-4">
                    <div className="text-right">
                      <p className="text-red-400 font-bold">{event.sp500Drop}%</p>
                      <p className="text-xs text-gray-500">S&P 500</p>
                    </div>
                    {expandedHistorical === event.id ? (
                      <ChevronUp className="w-5 h-5 text-gray-400" />
                    ) : (
                      <ChevronDown className="w-5 h-5 text-gray-400" />
                    )}
                  </div>
                </button>
                
                {expandedHistorical === event.id && (
                  <motion.div
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    className="px-4 pb-4 border-t border-[#1a1f37]"
                  >
                    <div className="pt-4 grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div>
                        <p className="text-sm text-gray-300 mb-3">{event.description}</p>
                        <div className="flex items-center gap-2 text-sm">
                          <Target className="w-4 h-4 text-[#f0b90b]" />
                          <span className="text-gray-400">Erholung: </span>
                          <span className="text-emerald-400">{event.recoveryDays} Tage</span>
                        </div>
                      </div>
                      <div>
                        <p className="text-sm font-medium text-gray-400 mb-2">Lessons Learned:</p>
                        <ul className="space-y-1">
                          {event.lessons.map((lesson, i) => (
                            <li key={i} className="text-sm text-gray-300 flex items-center gap-2">
                              <span className="w-1.5 h-1.5 bg-[#f0b90b] rounded-full" />
                              {lesson}
                            </li>
                          ))}
                        </ul>
                      </div>
                    </div>
                  </motion.div>
                )}
              </div>
            ))}
          </div>
        </div>

        {/* HEDGE STRATEGIEN */}
        <div className="glass-card rounded-xl p-6 mb-8">
          <h2 className="text-xl font-semibold mb-4 flex items-center gap-2">
            <Shield className="w-6 h-6 text-emerald-400" />
            Hedge-Strategien für dein Depot
          </h2>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {hedgeStrategies.map((strategy) => (
              <div 
                key={strategy.name}
                className={`bg-[#0f1629] rounded-lg p-4 border cursor-pointer transition-all ${
                  expandedStrategy === strategy.name 
                    ? 'border-emerald-500/50' 
                    : 'border-[#1a1f37] hover:border-emerald-500/30'
                }`}
                onClick={() => setExpandedStrategy(expandedStrategy === strategy.name ? null : strategy.name)}
              >
                <div className="flex items-center justify-between mb-2">
                  <h3 className="font-semibold text-sm">{strategy.name}</h3>
                  <span className="text-xs bg-emerald-500/20 text-emerald-400 px-2 py-0.5 rounded">
                    {strategy.allocation}
                  </span>
                </div>
                <p className="text-xs text-gray-400 mb-2">{strategy.description}</p>
                <p className="text-xs text-[#f0b90b]">{strategy.current}</p>
                
                {expandedStrategy === strategy.name && (
                  <motion.div
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    className="mt-3 pt-3 border-t border-[#1a1f37]"
                  >
                    <div className="grid grid-cols-2 gap-2 text-xs">
                      <div>
                        <p className="text-emerald-400 mb-1">✓ Vorteile</p>
                        <ul className="space-y-0.5 text-gray-400">
                          {strategy.pros.map((pro, i) => (
                            <li key={i}>• {pro}</li>
                          ))}
                        </ul>
                      </div>
                      <div>
                        <p className="text-red-400 mb-1">✗ Nachteile</p>
                        <ul className="space-y-0.5 text-gray-400">
                          {strategy.cons.map((con, i) => (
                            <li key={i}>• {con}</li>
                          ))}
                        </ul>
                      </div>
                    </div>
                  </motion.div>
                )}
              </div>
            ))}
          </div>
        </div>

        {/* RISK OF RUIN CALCULATOR */}
        <div className="glass-card rounded-xl p-6 mb-8">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-xl font-semibold flex items-center gap-2">
              <Calculator className="w-6 h-6 text-[#f0b90b]" />
              Risk of Ruin Calculator
            </h2>
            <button
              onClick={() => setShowCalculator(!showCalculator)}
              className="text-sm text-[#f0b90b] hover:underline"
            >
              {showCalculator ? 'Schließen' : 'Öffnen'}
            </button>
          </div>

          {showCalculator && (
            <motion.div
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: 'auto' }}
              className="space-y-6"
            >
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="text-sm text-gray-400 mb-2 block">Portfolio-Größe (€)</label>
                  <input
                    type="number"
                    value={riskInputs.portfolioSize}
                    onChange={(e) => setRiskInputs({...riskInputs, portfolioSize: parseInt(e.target.value) || 0})}
                    className="w-full bg-[#0f1629] border border-[#2a2f47] rounded-lg px-4 py-2 text-white"
                  />
                </div>
                <div>
                  <label className="text-sm text-gray-400 mb-2 block">Monatliche Sparrate (€)</label>
                  <input
                    type="number"
                    value={riskInputs.monthlyContribution}
                    onChange={(e) => setRiskInputs({...riskInputs, monthlyContribution: parseInt(e.target.value) || 0})}
                    className="w-full bg-[#0f1629] border border-[#2a2f47] rounded-lg px-4 py-2 text-white"
                  />
                </div>
                <div>
                  <label className="text-sm text-gray-400 mb-2 block">Max Drawdown (%)</label>
                  <input
                    type="number"
                    value={riskInputs.maxDrawdown}
                    onChange={(e) => setRiskInputs({...riskInputs, maxDrawdown: parseInt(e.target.value) || 0})}
                    className="w-full bg-[#0f1629] border border-[#2a2f47] rounded-lg px-4 py-2 text-white"
                  />
                </div>
                <div>
                  <label className="text-sm text-gray-400 mb-2 block">Erholungsrate (%/Jahr)</label>
                  <input
                    type="number"
                    value={riskInputs.recoveryRate}
                    onChange={(e) => setRiskInputs({...riskInputs, recoveryRate: parseInt(e.target.value) || 0})}
                    className="w-full bg-[#0f1629] border border-[#2a2f47] rounded-lg px-4 py-2 text-white"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="bg-[#0f1629] rounded-lg p-4 border border-red-500/30">
                  <p className="text-xs text-gray-500 mb-1">Ruin-Grenze</p>
                  <p className="text-xl font-bold text-red-400">
                    {Math.round(riskOfRuin.ruinThreshold).toLocaleString('de-DE')} €
                  </p>
                  <p className="text-xs text-gray-500 mt-1">
                    Bei {riskInputs.maxDrawdown}% Verlust
                  </p>
                </div>
                <div className="bg-[#0f1629] rounded-lg p-4 border border-[#1a1f37]">
                  <p className="text-xs text-gray-500 mb-1">Monate bis Ruin</p>
                  <p className="text-xl font-bold text-white">
                    {Math.round(riskOfRuin.monthsToRuin)}
                  </p>
                  <p className="text-xs text-gray-500 mt-1">
                    Ohne Nachkäufe
                  </p>
                </div>
                <div className="bg-[#0f1629] rounded-lg p-4 border border-[#f0b90b]/30">
                  <p className="text-xs text-gray-500 mb-1">Ruin-Wahrscheinlichkeit</p>
                  <p className="text-xl font-bold text-[#f0b90b]">
                    {riskOfRuin.probabilityOfRuin.toFixed(1)}%
                  </p>
                  <p className="text-xs text-gray-500 mt-1">
                    Bei gleichbleibenden Bedingungen
                  </p>
                </div>
              </div>
            </motion.div>
          )}
        </div>

        {/* Risiko-Indikatoren */}
        <div className="glass-card rounded-xl p-6">
          <h3 className="text-lg font-semibold mb-4 flex items-center gap-2">
            <Activity className="w-5 h-5 text-[#f0b90b]" />
            Makro-Risiko-Indikatoren
            <span className="text-xs text-gray-500 font-normal ml-2">(Hover für Erklärung)</span>
          </h3>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            {riskIndicators.map((indicator) => {
              const getStatus = () => {
                // Spezielle Logik für Fear & Greed (umgekehrt)
                if (indicator.id === 'fear-greed') {
                  if (indicator.currentValue <= 20) return 'critical';
                  if (indicator.currentValue <= 40) return 'warning';
                  if (indicator.currentValue <= 60) return 'elevated';
                  return 'normal';
                }
                // Spezielle Logik für Yield Curve (negativ ist schlecht)
                if (indicator.id === 'yield-curve-10y-2y') {
                  if (indicator.currentValue <= -0.5) return 'critical';
                  if (indicator.currentValue <= -0.25) return 'warning';
                  if (indicator.currentValue <= 0) return 'elevated';
                  return 'normal';
                }
                // Standard-Logik
                if (indicator.currentValue >= indicator.thresholds.severe) return 'critical';
                if (indicator.currentValue >= indicator.thresholds.high) return 'warning';
                if (indicator.currentValue >= indicator.thresholds.medium) return 'elevated';
                return 'normal';
              };
              
              const status = getStatus();
              const statusColors = {
                critical: { bg: 'bg-red-500/20', border: 'border-red-500/50', dot: 'bg-red-500', text: 'text-red-400' },
                warning: { bg: 'bg-orange-500/20', border: 'border-orange-500/50', dot: 'bg-orange-500', text: 'text-orange-400' },
                elevated: { bg: 'bg-yellow-500/20', border: 'border-yellow-500/50', dot: 'bg-yellow-500', text: 'text-yellow-400' },
                normal: { bg: 'bg-green-500/20', border: 'border-green-500/50', dot: 'bg-green-500', text: 'text-green-400' }
              };
              const colors = statusColors[status];
              
              return (
              <div 
                key={indicator.id} 
                className={`group relative bg-[#0f1629] rounded-lg p-4 border ${colors.border} hover:${colors.bg} transition-all cursor-help`}
              >
                { /* Header */ }
                <div className="flex items-center justify-between mb-2">
                  <p className="text-xs text-gray-400">{indicator.name}</p>
                  <span className={`w-2 h-2 rounded-full ${colors.dot}`} />
                </div>
                
                { /* Value */ }
                <div className="flex items-baseline gap-1 mb-2">
                  <p className="text-2xl font-bold text-white">{indicator.currentValue}</p>
                  <p className="text-sm text-gray-500">{indicator.unit}</p>
                </div>
                
                { /* Trend */ }
                <div className="flex items-center gap-2">
                  <span className={`text-xs ${colors.text}`}>
                    {indicator.trendDescription}
                  </span>
                </div>
                
                { /* Tooltip mit Erklärung */ }
                <div className="absolute z-10 left-0 right-0 top-full mt-2 p-4 bg-[#1a1f37] border border-[#2a2f47] rounded-lg shadow-xl opacity-0 invisible group-hover:opacity-100 group-hover:visible transition-all">
                  <p className="text-sm text-gray-300 mb-2">{indicator.description}</p>
                  
                  <div className="border-t border-[#2a2f47] pt-2 mt-2">
                    <p className="text-xs text-gray-500 mb-1">Schwellenwerte:</p>
                    <div className="grid grid-cols-4 gap-1 text-xs">
                      <div className="text-center">
                        <span className="text-green-400">Normal</span>
                        <br />
                        <span className="text-gray-500">{'<'}{indicator.thresholds.medium}</span>
                      </div>
                      <div className="text-center">
                        <span className="text-yellow-400">Beachten</span>
                        <br />
                        <span className="text-gray-500">{indicator.thresholds.medium}-{indicator.thresholds.high}</span>
                      </div>
                      <div className="text-center">
                        <span className="text-orange-400">Warnung</span>
                        <br />
                        <span className="text-gray-500">{indicator.thresholds.high}-{indicator.thresholds.severe}</span>
                      </div>
                      <div className="text-center">
                        <span className="text-red-400">Kritisch</span>
                        <br />
                        <span className="text-gray-500">{'>'}{indicator.thresholds.severe}</span>
                      </div>
                    </div>
                  </div>
                  
                  <p className="text-[10px] text-gray-500 mt-2">Quelle: {indicator.source}</p>
                </div>
              </div>
              );
            })}
          </div>
          
          {/* Legende */}
          <div className="mt-6 flex flex-wrap items-center justify-center gap-4 text-xs text-gray-400">
            <div className="flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-green-500" />
              <span>Normal</span>
            </div>
            <div className="flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-yellow-500" />
              <span>Beachten</span>
            </div>
            <div className="flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-orange-500" />
              <span>Warnung</span>
            </div>
            <div className="flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-red-500" />
              <span>Kritisch</span>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}