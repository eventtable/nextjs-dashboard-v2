'use client';

import { useState, useCallback } from 'react';
import { useDropzone } from 'react-dropzone';
import Papa from 'papaparse';
import { motion, AnimatePresence } from 'framer-motion';
import Link from 'next/link';
import {
  Upload,
  FileText,
  CheckCircle,
  AlertCircle,
  ArrowLeft,
  Download,
  Trash2,
  Save,
  Eye,
  Table
} from 'lucide-react';
import SharedHeader from '@/components/shared-header';

interface CsvPosition {
  Name: string;
  Ticker: string;
  ISIN: string;
  Anzahl: string;
  'Buy-In': string;
  Aktuell: string;
  Typ?: string;
  Sektor?: string;
}

interface ParsedPosition {
  id: string;
  name: string;
  ticker: string;
  isin: string;
  typ: 'Aktie' | 'ETF' | 'Anleihe';
  stueck: number;
  einstandKurs: number;
  kursProStueck: number;
  wertEur: number;
  performanceProzent: number;
  gewinnEur: number;
  sektor?: string;
}

const REQUIRED_COLUMNS = ['Name', 'Ticker', 'ISIN', 'Anzahl', 'Buy-In', 'Aktuell'];

export default function UploadPage() {
  const [parsedData, setParsedData] = useState<ParsedPosition[]>([]);
  const [errors, setErrors] = useState<string[]>([]);
  const [isParsing, setIsParsing] = useState(false);
  const [showPreview, setShowPreview] = useState(false);
  const [savedData, setSavedData] = useState<ParsedPosition[] | null>(null);

  // Lade gespeicherte Daten beim Mount
  const loadSavedData = () => {
    if (typeof window !== 'undefined') {
      const saved = localStorage.getItem('meinDepot');
      if (saved) {
        try {
          const data = JSON.parse(saved);
          setSavedData(data);
          return data;
        } catch (e) {
          console.error('Fehler beim Laden:', e);
        }
      }
    }
    return null;
  };

  // Initial load
  useState(() => {
    loadSavedData();
  });

  const validateCSV = (data: CsvPosition[]): { valid: boolean; errors: string[] } => {
    const errors: string[] = [];
    
    if (data.length === 0) {
      errors.push('CSV-Datei ist leer');
      return { valid: false, errors };
    }

    const headers = Object.keys(data[0]);
    const missingColumns = REQUIRED_COLUMNS.filter(col => !headers.includes(col));
    
    if (missingColumns.length > 0) {
      errors.push(`Fehlende Spalten: ${missingColumns.join(', ')}`);
    }

    // Validiere jede Zeile
    data.forEach((row, index) => {
      const rowNum = index + 2; // +2 wegen Header und 1-basiert
      
      if (!row.Name || row.Name.trim() === '') {
        errors.push(`Zeile ${rowNum}: Name fehlt`);
      }
      if (!row.Ticker || row.Ticker.trim() === '') {
        errors.push(`Zeile ${rowNum}: Ticker fehlt`);
      }
      if (!row.ISIN || row.ISIN.trim() === '') {
        errors.push(`Zeile ${rowNum}: ISIN fehlt`);
      }
      
      const anzahl = parseFloat(row.Anzahl);
      if (isNaN(anzahl) || anzahl <= 0) {
        errors.push(`Zeile ${rowNum}: Ungültige Anzahl (${row.Anzahl})`);
      }
      
      const buyIn = parseFloat(row['Buy-In'].replace(',', '.'));
      if (isNaN(buyIn) || buyIn <= 0) {
        errors.push(`Zeile ${rowNum}: Ungültiger Buy-In (${row['Buy-In']})`);
      }
      
      const aktuell = parseFloat(row.Aktuell.replace(',', '.'));
      if (isNaN(aktuell) || aktuell <= 0) {
        errors.push(`Zeile ${rowNum}: Ungültiger Aktueller Kurs (${row.Aktuell})`);
      }
    });

    return { valid: errors.length === 0, errors };
  };

  const transformData = (data: CsvPosition[]): ParsedPosition[] => {
    return data.map((row, index) => {
      const stueck = parseFloat(row.Anzahl);
      const einstandKurs = parseFloat(row['Buy-In'].replace(',', '.'));
      const kursProStueck = parseFloat(row.Aktuell.replace(',', '.'));
      const wertEur = stueck * kursProStueck;
      const investiert = stueck * einstandKurs;
      const performanceProzent = ((wertEur - investiert) / investiert) * 100;
      const gewinnEur = wertEur - investiert;

      // Bestimme Typ aus Ticker oder Spalte
      let typ: 'Aktie' | 'ETF' | 'Anleihe' = 'Aktie';
      if (row.Typ) {
        typ = row.Typ as 'Aktie' | 'ETF' | 'Anleihe';
      } else if (row.Ticker.includes('ETF') || row.Ticker.includes('XAI') || row.Ticker.includes('VHYD') || 
                 row.Ticker.includes('XDWC') || row.Ticker.includes('AMEM') || row.Ticker.includes('COMO') ||
                 row.Ticker.includes('NATO') || row.Ticker.includes('IGLN') || row.Ticker.includes('3DES')) {
        typ = 'ETF';
      } else if (row.Ticker.includes('XS') || row.Ticker.includes('Bond')) {
        typ = 'Anleihe';
      }

      return {
        id: `pos-${index}`,
        name: row.Name.trim(),
        ticker: row.Ticker.trim(),
        isin: row.ISIN.trim(),
        typ,
        stueck,
        einstandKurs,
        kursProStueck,
        wertEur: Math.round(wertEur * 100) / 100,
        performanceProzent: Math.round(performanceProzent * 100) / 100,
        gewinnEur: Math.round(gewinnEur * 100) / 100,
        sektor: row.Sektor || undefined
      };
    });
  };

  const onDrop = useCallback((acceptedFiles: File[]) => {
    const file = acceptedFiles[0];
    if (!file) return;

    setIsParsing(true);
    setErrors([]);
    setParsedData([]);

    Papa.parse<CsvPosition>(file, {
      header: true,
      skipEmptyLines: true,
      complete: (results) => {
        setIsParsing(false);
        
        const validation = validateCSV(results.data);
        if (!validation.valid) {
          setErrors(validation.errors);
          return;
        }

        const transformed = transformData(results.data);
        setParsedData(transformed);
        setShowPreview(true);
      },
      error: (error) => {
        setIsParsing(false);
        setErrors([`Fehler beim Parsen: ${error.message}`]);
      }
    });
  }, []);

  const { getRootProps, getInputProps, isDragActive, isDragReject } = useDropzone({
    onDrop,
    accept: {
      'text/csv': ['.csv'],
      'application/vnd.ms-excel': ['.csv']
    },
    maxFiles: 1,
    maxSize: 1024 * 1024 // 1MB
  });

  const saveToLocalStorage = () => {
    if (parsedData.length > 0) {
      localStorage.setItem('meinDepot', JSON.stringify(parsedData));
      localStorage.setItem('meinDepotTimestamp', new Date().toISOString());
      setSavedData(parsedData);
      alert(`✅ ${parsedData.length} Positionen erfolgreich gespeichert!`);
    }
  };

  const clearData = () => {
    if (confirm('Möchtest du alle gespeicherten Daten löschen?')) {
      localStorage.removeItem('meinDepot');
      localStorage.removeItem('meinDepotTimestamp');
      setSavedData(null);
      setParsedData([]);
      setShowPreview(false);
      alert('Daten gelöscht');
    }
  };

  const formatCurrency = (value: number) => {
    return value.toLocaleString('de-DE', { style: 'currency', currency: 'EUR' });
  };

  const formatPercent = (value: number) => {
    return `${value >= 0 ? '+' : ''}${value.toFixed(2)}%`;
  };

  return (
    <div className="min-h-screen bg-[#0a0e1a] text-white">
      <SharedHeader />

      <main className="pt-24 pb-12 px-4 sm:px-6 max-w-7xl mx-auto">
        <div className="flex items-center gap-4 mb-6">
          <Link href="/" className="flex items-center gap-2 text-gray-400 hover:text-white transition-colors">
            <ArrowLeft className="w-5 h-5" />
            <span>Zurück</span>
          </Link>
        </div>

        <div className="mb-8">
          <h1 className="text-3xl font-bold mb-2 flex items-center gap-3">
            <Upload className="w-8 h-8 text-[#f0b90b]" />
            Depot-Upload
          </h1>
          <p className="text-gray-400">
            Lade deine Depot-Daten als CSV hoch für persönliche Analysen
          </p>
        </div>

        {/* Info Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
          <div className="bg-[#0d1220] border border-[#1a1f37] rounded-xl p-6">
            <h3 className="font-semibold mb-3 flex items-center gap-2">
              <FileText className="w-5 h-5 text-[#f0b90b]" />
              CSV-Format
            </h3>
            <p className="text-sm text-gray-400 mb-4">
              Deine CSV-Datei benötigt diese Spalten:
            </p>
            <code className="block bg-[#0a0e1a] p-3 rounded text-sm text-[#f0b90b] font-mono">
              Name,Ticker,ISIN,Anzahl,Buy-In,Aktuell,Typ,Sektor
            </code>
            <p className="text-xs text-gray-500 mt-2">
              Typ und Sektor sind optional. Dezimalzahlen mit Punkt oder Komma.
            </p>
          </div>

          <div className="bg-[#0d1220] border border-[#1a1f37] rounded-xl p-6">
            <h3 className="font-semibold mb-3 flex items-center gap-2">
              <Download className="w-5 h-5 text-emerald-400" />
              Vorlage
            </h3>
            <p className="text-sm text-gray-400 mb-4">
              Lade die Vorlage herunter und fülle sie aus:
            </p>
            <a
              href="/depot_template.csv"
              download
              className="inline-flex items-center gap-2 px-4 py-2 bg-emerald-500/20 border border-emerald-500/30 text-emerald-400 rounded-lg hover:bg-emerald-500/30 transition-colors"
            >
              <Download className="w-4 h-4" />
              Vorlage herunterladen
            </a>
          </div>
        </div>

        {/* Dropzone */}
        <div className="mb-8">
          <div
            {...getRootProps()}
            className={`
              border-2 border-dashed rounded-xl p-12 text-center cursor-pointer transition-all
              ${isDragActive ? 'border-[#f0b90b] bg-[#f0b90b]/10' : ''}
              ${isDragReject ? 'border-red-500 bg-red-500/10' : ''}
              ${!isDragActive && !isDragReject ? 'border-[#1a1f37] hover:border-[#f0b90b]/50 hover:bg-[#0d1220]' : ''}
            `}
          >
            <input {...getInputProps()} />
            
            {isParsing ? (
              <div className="flex flex-col items-center">
                <div className="w-8 h-8 border-2 border-[#f0b90b] border-t-transparent rounded-full animate-spin mb-4" />
                <p className="text-gray-400">CSV wird verarbeitet...</p>
              </div>
            ) : (
              <>
                <Upload className="w-12 h-12 mx-auto mb-4 text-gray-400" />
                <p className="text-lg font-medium mb-2">
                  {isDragActive ? 'Datei hier ablegen...' : 'CSV-Datei hierher ziehen oder klicken'}
                </p>
                <p className="text-sm text-gray-500">
                  Nur .csv Dateien, maximal 1MB
                </p>
              </>
            )}
          </div>
        </div>

        {/* Errors */}
        <AnimatePresence>
          {errors.length > 0 && (
            <motion.div
              initial={{ opacity: 0, y: -20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="bg-red-500/10 border border-red-500/30 rounded-xl p-6 mb-8"
            >
              <div className="flex items-center gap-2 mb-4">
                <AlertCircle className="w-5 h-5 text-red-400" />
                <h3 className="font-semibold text-red-400">Validierungsfehler</h3>
              </div>
              <ul className="space-y-2">
                {errors.map((error, index) => (
                  <li key={index} className="text-sm text-red-400 flex items-start gap-2">
                    <span className="text-red-500">•</span>
                    {error}
                  </li>
                ))}
              </ul>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Preview */}
        <AnimatePresence>
          {showPreview && parsedData.length > 0 && (
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: 20 }}
              className="bg-[#0d1220] border border-[#1a1f37] rounded-xl overflow-hidden mb-8"
            >
              <div className="p-6 border-b border-[#1a1f37]">
                <div className="flex items-center justify-between">
                  <h3 className="font-semibold flex items-center gap-2">
                    <Eye className="w-5 h-5 text-[#f0b90b]" />
                    Vorschau ({parsedData.length} Positionen)
                  </h3>
                  <div className="flex gap-2">
                    <button
                      onClick={() => setShowPreview(!showPreview)}
                      className="px-3 py-1 text-sm text-gray-400 hover:text-white transition-colors"
                    >
                      {showPreview ? 'Ausblenden' : 'Anzeigen'}
                    </button>
                  </div>
                </div>
              </div>

              {showPreview && (
                <div className="overflow-x-auto">
                  <table className="w-full">
                    <thead className="bg-[#0a0e1a]">
                      <tr>
                        <th className="text-left px-4 py-3 text-sm font-medium text-gray-400">Name</th>
                        <th className="text-left px-4 py-3 text-sm font-medium text-gray-400">Ticker</th>
                        <th className="text-left px-4 py-3 text-sm font-medium text-gray-400">Typ</th>
                        <th className="text-right px-4 py-3 text-sm font-medium text-gray-400">Anzahl</th>
                        <th className="text-right px-4 py-3 text-sm font-medium text-gray-400">Buy-In</th>
                        <th className="text-right px-4 py-3 text-sm font-medium text-gray-400">Aktuell</th>
                        <th className="text-right px-4 py-3 text-sm font-medium text-gray-400">Wert</th>
                        <th className="text-right px-4 py-3 text-sm font-medium text-gray-400">Performance</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-[#1a1f37]">
                      {parsedData.map((pos) => (
                        <tr key={pos.id} className="hover:bg-[#0a0e1a]/50">
                          <td className="px-4 py-3">
                            <div className="font-medium">{pos.name}</div>
                            <div className="text-xs text-gray-500">{pos.isin}</div>
                          </td>
                          <td className="px-4 py-3 text-sm">{pos.ticker}</td>
                          <td className="px-4 py-3">
                            <span className={`text-xs px-2 py-0.5 rounded ${
                              pos.typ === 'Aktie' ? 'bg-blue-500/20 text-blue-400' :
                              pos.typ === 'ETF' ? 'bg-purple-500/20 text-purple-400' :
                              'bg-orange-500/20 text-orange-400'
                            }`}>
                              {pos.typ}
                            </span>
                          </td>
                          <td className="px-4 py-3 text-right text-sm">{pos.stueck}</td>
                          <td className="px-4 py-3 text-right text-sm">{formatCurrency(pos.einstandKurs)}</td>
                          <td className="px-4 py-3 text-right text-sm">{formatCurrency(pos.kursProStueck)}</td>
                          <td className="px-4 py-3 text-right font-medium">{formatCurrency(pos.wertEur)}</td>
                          <td className={`px-4 py-3 text-right font-medium ${
                            pos.performanceProzent >= 0 ? 'text-emerald-400' : 'text-red-400'
                          }`}>
                            {formatPercent(pos.performanceProzent)}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                    <tfoot className="bg-[#0a0e1a] border-t border-[#1a1f37]">
                      <tr>
                        <td colSpan={6} className="px-4 py-3 text-right font-medium">Gesamtwert:</td>
                        <td className="px-4 py-3 text-right font-bold text-[#f0b90b]">
                          {formatCurrency(parsedData.reduce((sum, p) => sum + p.wertEur, 0))}
                        </td>
                        <td className="px-4 py-3 text-right">
                          <span className={`font-medium ${
                            parsedData.reduce((sum, p) => sum + p.gewinnEur, 0) >= 0 ? 'text-emerald-400' : 'text-red-400'
                          }`}>
                            {formatPercent(
                              (parsedData.reduce((sum, p) => sum + p.gewinnEur, 0) / 
                               parsedData.reduce((sum, p) => sum + (p.stueck * p.einstandKurs), 0)) * 100
                            )}
                          </span>
                        </td>
                      </tr>
                    </tfoot>
                  </table>
                </div>
              )}

              {/* Action Buttons */}
              <div className="p-6 border-t border-[#1a1f37] flex gap-4">
                <button
                  onClick={saveToLocalStorage}
                  className="flex-1 flex items-center justify-center gap-2 px-6 py-3 bg-emerald-500/20 border border-emerald-500/30 text-emerald-400 rounded-lg hover:bg-emerald-500/30 transition-colors font-medium"
                >
                  <Save className="w-5 h-5" />
                  Import speichern
                </button>
                <button
                  onClick={() => { setParsedData([]); setShowPreview(false); }}
                  className="px-6 py-3 bg-[#0a0e1a] border border-[#1a1f37] text-gray-400 rounded-lg hover:text-white transition-colors"
                >
                  Abbrechen
                </button>
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Saved Data Info */}
        {savedData && (
          <div className="bg-emerald-500/10 border border-emerald-500/30 rounded-xl p-6">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <CheckCircle className="w-6 h-6 text-emerald-400" />
                <div>
                  <h3 className="font-semibold text-emerald-400">Daten gespeichert</h3>
                  <p className="text-sm text-gray-400">
                    {savedData.length} Positionen im LocalStorage • {' '}
                    {localStorage.getItem('meinDepotTimestamp') && 
                      new Date(localStorage.getItem('meinDepotTimestamp')!).toLocaleString('de-DE')}
                  </p>
                </div>
              </div>
              <div className="flex gap-2">
                <Link
                  href="/mein-depot"
                  className="flex items-center gap-2 px-4 py-2 bg-[#0a0e1a] border border-[#1a1f37] text-white rounded-lg hover:border-emerald-500/50 transition-colors"
                >
                  <Table className="w-4 h-4" />
                  Depot ansehen
                </Link>
                <button
                  onClick={clearData}
                  className="flex items-center gap-2 px-4 py-2 bg-red-500/20 border border-red-500/30 text-red-400 rounded-lg hover:bg-red-500/30 transition-colors"
                >
                  <Trash2 className="w-4 h-4" />
                  Löschen
                </button>
              </div>
            </div>
          </div>
        )}

        {/* Navigation */}
        <div className="flex gap-4 mt-8">
          <Link
            href="/mein-depot"
            className="flex-1 bg-[#0d1220] border border-[#1a1f37] hover:border-[#f0b90b]/50 rounded-xl p-4 text-center transition-all"
          >
            <Table className="w-6 h-6 mx-auto mb-2 text-[#f0b90b]" />
            <p className="font-semibold">Mein Depot</p>
            <p className="text-sm text-gray-400">Gespeicherte Positionen</p>
          </Link>
          <Link
            href="/empfehlungen"
            className="flex-1 bg-[#0d1220] border border-[#1a1f37] hover:border-[#f0b90b]/50 rounded-xl p-4 text-center transition-all"
          >
            <CheckCircle className="w-6 h-6 mx-auto mb-2 text-[#f0b90b]" />
            <p className="font-semibold">Empfehlungen</p>
            <p className="text-sm text-gray-400">Matrix-Analyse deiner Daten</p>
          </Link>
        </div>
      </main>
    </div>
  );
}