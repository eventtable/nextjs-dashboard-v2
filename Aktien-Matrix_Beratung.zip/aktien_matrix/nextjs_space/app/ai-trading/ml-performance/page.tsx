'use client';

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { TrendingUp, TrendingDown, Minus, Activity, BarChart3, Target, Award, RefreshCw, ArrowLeft, Home } from "lucide-react";
import { useState, useEffect } from "react";
import Link from "next/link";

// API URL - Lokale JSON Dateien (werden vom Sync-Cronjob aktualisiert)
const API_URL = '/ml_data';

function GradeBadge({ grade }: { grade: string }) {
  const colors: Record<string, string> = {
    'A': 'bg-emerald-500',
    'B': 'bg-blue-500',
    'C': 'bg-yellow-500',
    'D': 'bg-orange-500',
    'F': 'bg-gray-500',
  };

  return (
    <div className={`${colors[grade] || 'bg-gray-500'} text-white text-2xl font-bold w-12 h-12 rounded-full flex items-center justify-center`}>
      {grade}
    </div>
  );
}

function WinRateBar({ rate }: { rate: number }) {
  const color = rate >= 60 ? 'bg-emerald-500' : rate >= 50 ? 'bg-yellow-500' : 'bg-red-500';

  return (
    <div className="w-full">
      <div className="flex justify-between mb-1 text-sm">
        <span>Win Rate</span>
        <span className={`font-bold ${rate >= 60 ? 'text-emerald-400' : rate >= 50 ? 'text-yellow-400' : 'text-red-400'}`}>
          {rate.toFixed(1)}%
        </span>
      </div>
      <div className="w-full bg-gray-700 rounded-full h-3">
        <div className={`${color} h-3 rounded-full transition-all`} style={{ width: `${Math.min(100, rate)}%` }} />
      </div>
    </div>
  );
}

function getGrade(winRate: number) {
  if (winRate >= 80) return 'A';
  if (winRate >= 60) return 'B';
  if (winRate >= 40) return 'C';
  if (winRate >= 20) return 'D';
  return 'F';
}

// Performance Card Component
function PerformanceCard({ title, summary, icon: Icon, color }: { 
  title: string; 
  summary: any; 
  icon: any; 
  color: string;
}) {
  const winRate = summary?.win_rate || 0;
  const total = summary?.total_predictions || 0;
  const correct = summary?.correct_predictions || 0;
  const wrong = summary?.wrong_predictions || 0;
  const grade = getGrade(winRate);

  return (
    <Card className="bg-gradient-to-br from-[#1a1d2d] to-[#0d1220] border-gray-700/50">
      <CardHeader className="pb-2">
        <CardTitle className={`text-lg flex items-center gap-2 ${color}`}>
          <Icon className="w-5 h-5" />
          {title}
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="flex items-center gap-4 mb-4">
          <GradeBadge grade={grade} />
          <div>
            <div className="text-2xl font-bold">{winRate}%</div>
            <div className="text-sm text-gray-400">Win Rate</div>
          </div>
        </div>
        
        <div className="space-y-2 text-sm">
          <div className="flex justify-between">
            <span className="text-gray-400">Gesamt:</span>
            <span className="font-bold">{total}</span>
          </div>
          <div className="flex justify-between text-emerald-400">
            <span>✓ Richtig:</span>
            <span className="font-bold">{correct}</span>
          </div>
          <div className="flex justify-between text-red-400">
            <span>✗ Falsch:</span>
            <span className="font-bold">{wrong}</span>
          </div>
        </div>

        <div className="mt-4 text-xs text-gray-500">
          {winRate >= 60 ? '🏆 Exzellente Performance' : 
           winRate >= 50 ? '✅ Solide Performance' : 
           '⚠️ Verbesserung nötig'}
        </div>
      </CardContent>
    </Card>
  );
}

// Prediction Card Component
function PredictionCard({ pred }: { pred: any }) {
  const SignalIcon = pred.signal === 'BUY' ? TrendingUp : pred.signal === 'SELL' ? TrendingDown : Minus;
  const signalColor = pred.signal === 'BUY' ? 'text-emerald-400' : pred.signal === 'SELL' ? 'text-red-400' : 'text-gray-400';
  const confValue = Math.min(3, Math.max(1, Math.round(pred.confidence)));
  const confidenceColor = confValue >= 3 ? 'bg-emerald-500/20 text-emerald-400' :
                         confValue >= 2 ? 'bg-yellow-500/20 text-yellow-400' :
                         'bg-red-500/20 text-red-400';

  return (
    <div className="bg-[#131722] border border-gray-700/50 rounded-lg p-3 flex items-center justify-between">
      <div className="flex items-center gap-3">
        <div className={`p-2 rounded-lg ${pred.signal === 'BUY' ? 'bg-emerald-500/20' : pred.signal === 'SELL' ? 'bg-red-500/20' : 'bg-gray-500/20'}`}>
          <SignalIcon className={`w-4 h-4 ${signalColor}`} />
        </div>
        <div>
          <div className="font-bold">{pred.ticker}</div>
          <div className={`text-sm ${signalColor}`}>{pred.signal}</div>
        </div>
      </div>
      <div className={`px-3 py-1 rounded-full text-sm font-medium ${confidenceColor}`}>
        {'⭐'.repeat(Math.min(3, Math.max(1, Math.round(pred.confidence))))}
      </div>
    </div>
  );
}

// Evaluated Prediction Card
function EvaluatedCard({ pred }: { pred: any }) {
  return (
    <div className="bg-[#0d1220] rounded-lg p-3">
      <div className="flex items-center justify-between mb-2">
        <span className="font-bold">{pred.ticker}</span>
        <span className={`font-bold ${pred.actualOutcome === 'correct' ? 'text-emerald-400' : 'text-red-400'}`}>
          {pred.actualOutcome === 'correct' ? '✓' : '✗'} {pred.actualReturn?.toFixed(1) || 0}%
        </span>
      </div>
      <div className="flex justify-between text-sm text-gray-400">
        <span>{pred.signal} @ {'⭐'.repeat(Math.min(3, Math.max(1, Math.round(pred.confidence))))}</span>
        <span>{new Date(pred.predictedAt).toLocaleDateString('de-DE')}</span>
      </div>
    </div>
  );
}

// Main Component
function MLPerformanceClient() {
  const [data, setData] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [lastUpdated, setLastUpdated] = useState<string>('');

  const fetchData = async () => {
    try {
      setLoading(true);
      
      // Lade alle JSON-Dateien
      const [predictionsRes, scorecardRes, evaluatedRes] = await Promise.all([
        fetch(`${API_URL}/current_predictions.json`),
        fetch(`${API_URL}/ml_scorecard.json`),
        fetch(`${API_URL}/evaluated_predictions.json`)
      ]);
      
      if (!predictionsRes.ok || !scorecardRes.ok) {
        throw new Error('JSON-Dateien nicht gefunden');
      }
      
      const predictionsData = await predictionsRes.json();
      const scorecardData = await scorecardRes.json();
      const evaluatedData = evaluatedRes.ok ? await evaluatedRes.json() : { live: { predictions: [] }, backtest: { predictions: [] } };
      
      setData({
        predictions: predictionsData.predictions || [],
        liveSummary: scorecardData.live,
        backtestSummary: scorecardData.backtest,
        overallSummary: scorecardData.overall,
        liveEvaluated: evaluatedData.live?.predictions || [],
        backtestEvaluated: evaluatedData.backtest?.predictions || []
      });
      
      setLastUpdated(new Date().toLocaleTimeString('de-DE'));
      setError(null);
    } catch (err) {
      console.error('Fetch error:', err);
      setError('JSON-Dateien nicht verfügbar. Sync-Cronjob prüfen.');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchData();
    const interval = setInterval(fetchData, 300000); // Auto-refresh alle 5 Minuten
    return () => clearInterval(interval);
  }, []);

  if (loading && !data) {
    return (
      <div className="p-6 max-w-7xl mx-auto flex items-center justify-center min-h-[400px]">
        <div className="text-center">
          <RefreshCw className="w-12 h-12 mx-auto mb-4 animate-spin text-blue-400" />
          <p className="text-gray-400">Lade ML-Daten...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="p-6 max-w-7xl mx-auto">
      {/* Header mit Zurück-Link */}
      <div className="mb-4">
        <Link href="/" className="flex items-center gap-2 text-gray-400 hover:text-white transition-colors mb-4 inline-flex">
          <ArrowLeft className="w-4 h-4" />
          <Home className="w-4 h-4" />
          Zurück zum Dashboard
        </Link>
      </div>

      <div className="mb-8 flex items-start justify-between">
        <div>
          <h1 className="text-3xl font-bold mb-2 flex items-center gap-3">
            <Activity className="w-8 h-8 text-purple-400" />
            ML Agent Performance
          </h1>
          <p className="text-gray-400">
            Live Trading vs. Backtest Performance
          </p>
        </div>
        <button 
          onClick={fetchData}
          disabled={loading}
          className="flex items-center gap-2 px-4 py-2 bg-blue-600 hover:bg-blue-700 disabled:bg-gray-600 rounded-lg transition-colors"
        >
          <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin' : ''}`} />
          {loading ? 'Lade...' : 'Aktualisieren'}
        </button>
      </div>

      {error && (
        <div className="mb-6 p-4 bg-red-900/50 border border-red-700 rounded-lg text-red-200">
          ⚠️ {error}
        </div>
      )}

      {/* OVERALL Stats */}
      <div className="mb-8">
        <h2 className="text-xl font-semibold mb-4 flex items-center gap-2">
          <BarChart3 className="w-6 h-6 text-yellow-400" />
          Gesamt Performance
        </h2>
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
          <Card className="bg-gradient-to-br from-[#1a1d2d] to-[#0d1220] border-gray-700/50">
            <CardContent className="pt-6">
              <div className="text-center">
                <div className="text-3xl font-bold text-yellow-400">
                  {data?.overallSummary?.total_predictions || 0}
                </div>
                <div className="text-sm text-gray-400 mt-1">Total Predictions</div>
              </div>
            </CardContent>
          </Card>
          
          <Card className="bg-gradient-to-br from-[#1a1d2d] to-[#0d1220] border-gray-700/50">
            <CardContent className="pt-6">
              <div className="text-center">
                <div className="text-3xl font-bold text-emerald-400">
                  {data?.overallSummary?.win_rate || 0}%
                </div>
                <div className="text-sm text-gray-400 mt-1">Ø Win Rate</div>
              </div>
            </CardContent>
          </Card>
          
          <Card className="bg-gradient-to-br from-[#1a1d2d] to-[#0d1220] border-gray-700/50">
            <CardContent className="pt-6">
              <div className="text-center">
                <div className="text-3xl font-bold text-blue-400">
                  {data?.liveSummary?.total_predictions || 0}
                </div>
                <div className="text-sm text-gray-400 mt-1">Live Trades</div>
              </div>
            </CardContent>
          </Card>
          
          <Card className="bg-gradient-to-br from-[#1a1d2d] to-[#0d1220] border-gray-700/50">
            <CardContent className="pt-6">
              <div className="text-center">
                <div className="text-3xl font-bold text-purple-400">
                  {data?.backtestSummary?.total_predictions || 0}
                </div>
                <div className="text-sm text-gray-400 mt-1">Backtest Trades</div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>

      {/* TWO Performance Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
        {/* LIVE Trading Performance */}
        <PerformanceCard 
          title="🔴 LIVE Trading Performance" 
          summary={data?.liveSummary} 
          icon={TrendingUp}
          color="text-emerald-400"
        />

        {/* BACKTEST Performance */}
        <PerformanceCard 
          title="📊 Backtest Performance (Historisch)" 
          summary={data?.backtestSummary} 
          icon={BarChart3}
          color="text-purple-400"
        />
      </div>

      {/* TWO Tables */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* LIVE Predictions */}
        <Card className="bg-[#131722] border-gray-700/50">
          <CardHeader>
            <CardTitle className="text-xl flex items-center gap-2 text-emerald-400">
              <TrendingUp className="w-5 h-5" />
              Aktuelle LIVE Vorhersagen ({data?.predictions?.length || 0})
            </CardTitle>
          </CardHeader>
          <CardContent>
            {data?.predictions?.length ? (
              <div className="space-y-2 max-h-96 overflow-y-auto">
                {data.predictions
                  .sort((a: any, b: any) => b.confidence - a.confidence)
                  .map((pred: any) => (
                  <PredictionCard key={pred.ticker} pred={pred} />
                ))}
              </div>
            ) : (
              <div className="text-center py-8 text-gray-500">
                Keine ausstehenden LIVE Vorhersagen
              </div>
            )}
          </CardContent>
        </Card>

        {/* LIVE Evaluations */}
        <Card className="bg-[#131722] border-gray-700/50">
          <CardHeader>
            <CardTitle className="text-xl flex items-center gap-2 text-blue-400">
              <Award className="w-5 h-5" />
              LIVE Auswertungen ({data?.liveEvaluated?.length || 0})
            </CardTitle>
          </CardHeader>
          <CardContent>
            {data?.liveEvaluated?.length ? (
              <>
                <div className="space-y-2 max-h-96 overflow-y-auto">
                  {data.liveEvaluated
                    .slice(0, 50)  // Auf 50 Einträge begrenzt
                    .map((pred: any) => (
                    <EvaluatedCard key={pred.id} pred={pred} />
                  ))}
                </div>
                {data.liveEvaluated.length > 50 && (
                  <div className="text-center text-sm text-gray-500 mt-2">
                    ... und {data.liveEvaluated.length - 50} weitere Auswertungen
                  </div>
                )}
              </>
            ) : (
              <div className="text-center py-8 text-gray-500">
                Noch keine LIVE Auswertungen
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      {/* BACKTEST Evaluations */}
      <Card className="bg-[#131722] border-gray-700/50 mt-6">
        <CardHeader>
          <CardTitle className="text-xl flex items-center gap-2 text-purple-400">
            <BarChart3 className="w-5 h-5" />
            Backtest Auswertungen ({data?.backtestEvaluated?.length || 0})
          </CardTitle>
        </CardHeader>
        <CardContent>
          {data?.backtestEvaluated?.length ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-2 max-h-64 overflow-y-auto">
              {data.backtestEvaluated
                .slice(0, 50)  // Auf 50 Einträge begrenzt
                .map((pred: any) => (
                <EvaluatedCard key={pred.id} pred={pred} />
              ))}
            </div>
          ) : (
            <div className="text-center py-8 text-gray-500">
              Noch keine Backtest Auswertungen
            </div>
          )}
          {data.backtestEvaluated?.length > 50 && (
            <div className="text-center text-sm text-gray-500 mt-2">
              ... und {data.backtestEvaluated.length - 50} weitere Backtest-Auswertungen
            </div>
          )}
        </CardContent>
      </Card>

      {/* Info */}
      <Card className="bg-[#131722] border-gray-700/50 mt-6">
        <CardContent className="py-4">
          <div className="flex justify-between items-center text-sm text-gray-400">
            <div>
              <span className="text-emerald-400 font-bold">LIVE:</span> Echte Marktdaten & Trades
            </div>
            <div>
              <span className="text-purple-400 font-bold">Backtest:</span> Historische Kursdaten (30 Tage)
            </div>
            <div>
              Letzte Aktualisierung: {lastUpdated}
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}

export default function MLPerformancePage() {
  return <MLPerformanceClient />;
}
