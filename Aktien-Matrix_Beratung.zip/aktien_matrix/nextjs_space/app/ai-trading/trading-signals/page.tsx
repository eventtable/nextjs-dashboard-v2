import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { 
  TrendingUp, 
  TrendingDown, 
  Minus, 
  ArrowDownCircle,
  Target,
  AlertTriangle,
  CheckCircle2,
  XCircle,
  BarChart3
} from "lucide-react";

// Trading Signals basierend auf 26-Jahre Backtests
const tradingSignals = [
  {
    ticker: "EUNL.DE",
    name: "iShares Core MSCI World",
    signal: "BUY",
    action: "KAUFEN",
    confidence: 92,
    reason: "ETF Top-Performer (77.8% Win Rate)",
    targetPrice: "142.50",
    stopLoss: "138.00",
    timeframe: "Langfristig",
    type: "LONG"
  },
  {
    ticker: "SXRV.DE",
    name: "iShares Nasdaq 100",
    signal: "BUY",
    action: "KAUFEN",
    confidence: 89,
    reason: "Tech-ETF stark (76.8% Win Rate)",
    targetPrice: "85.20",
    stopLoss: "81.50",
    timeframe: "Mittelfristig",
    type: "LONG"
  },
  {
    ticker: "SAP.DE",
    name: "SAP SE",
    signal: "HOLD",
    action: "HALTEN",
    confidence: 65,
    reason: "Software-Sektor stabil, warte auf Dip",
    targetPrice: "155.00",
    stopLoss: "145.00",
    timeframe: "Beobachten",
    type: "NEUTRAL"
  },
  {
    ticker: "BYD",
    name: "BYD Co.",
    signal: "SHORT",
    action: "SHORTEN",
    confidence: 78,
    reason: "E-Mobilität überbewertet, Korrektur erwartet",
    targetPrice: "9.50",
    stopLoss: "12.80",
    timeframe: "Short-Term",
    type: "SHORT"
  },
  {
    ticker: "ALV.DE",
    name: "Allianz",
    signal: "BUY",
    action: "KAUFEN",
    confidence: 85,
    reason: "Versicherung defensiv, 100% historisch korrekt",
    targetPrice: "355.00",
    stopLoss: "335.00",
    timeframe: "Langfristig",
    type: "LONG"
  },
  {
    ticker: "MSF.DE",
    name: "Microsoft",
    signal: "SHORT",
    action: "SHORTEN",
    confidence: 72,
    reason: "Tech-Overvaluation, Short-Chance bei 320€",
    targetPrice: "295.00",
    stopLoss: "340.00",
    timeframe: "Mittelfristig",
    type: "SHORT"
  },
  {
    ticker: "MUV2.DE",
    name: "Münchener Rück",
    signal: "BUY",
    action: "KAUFEN",
    confidence: 88,
    reason: "Rückversicherung stabil, Dividende attraktiv",
    targetPrice: "540.00",
    stopLoss: "505.00",
    timeframe: "Langfristig",
    type: "LONG"
  },
  {
    ticker: "NOVO-B.CO",
    name: "Novo Nordisk",
    signal: "HOLD",
    action: "HALTEN",
    confidence: 60,
    reason: "Pharma volatil, warte auf klares Signal",
    targetPrice: "33.00",
    stopLoss: "28.50",
    timeframe: "Beobachten",
    type: "NEUTRAL"
  },
  {
    ticker: "MBB.DE",
    name: "MBB SE",
    signal: "SELL",
    action: "VERKAUFEN",
    confidence: 70,
    reason: "Tech-Beratung schwach, Position reduzieren",
    targetPrice: "175.00",
    stopLoss: "195.00",
    timeframe: "Sofort",
    type: "CLOSE"
  },
  {
    ticker: "GOLD",
    name: "Barrick Gold",
    signal: "SHORT",
    action: "SHORTEN",
    confidence: 75,
    reason: "Gold-Mining unter Druck, Short bei 34€",
    targetPrice: "28.00",
    stopLoss: "36.50",
    timeframe: "Mittelfristig",
    type: "SHORT"
  },
  {
    ticker: "EXS1.DE",
    name: "iShares Euro Stoxx 50",
    signal: "BUY",
    action: "KAUFEN",
    confidence: 90,
    reason: "Europa-ETF solide (74.3% Win Rate)",
    targetPrice: "42.80",
    stopLoss: "40.50",
    timeframe: "Langfristig",
    type: "LONG"
  },
  {
    ticker: "QDVC.F",
    name: "iShares MSCI World Quality",
    signal: "BUY",
    action: "KAUFEN",
    confidence: 87,
    reason: "Quality-Faktor überzeugt (75.2% Win Rate)",
    targetPrice: "38.50",
    stopLoss: "36.80",
    timeframe: "Langfristig",
    type: "LONG"
  },
  {
    ticker: "2B76.F",
    name: "iShares Core DAX",
    signal: "SHORT",
    action: "SHORTEN",
    confidence: 68,
    reason: "DAX überbewertet, Short-Chance bei Korrektur",
    targetPrice: "175.00",
    stopLoss: "195.00",
    timeframe: "Short-Term",
    type: "SHORT"
  },
  {
    ticker: "NESN.SW",
    name: "Nestlé",
    signal: "BUY",
    action: "KAUFEN",
    confidence: 82,
    reason: "Defensiv-Konsum stabil in Krisen",
    targetPrice: "108.00",
    stopLoss: "102.00",
    timeframe: "Langfristig",
    type: "LONG"
  },
  {
    ticker: "ASML.AS",
    name: "ASML",
    signal: "HOLD",
    action: "HALTEN",
    confidence: 63,
    reason: "Halbleiter zyklisch, warte auf besseren Einstieg",
    targetPrice: "780.00",
    stopLoss: "720.00",
    timeframe: "Beobachten",
    type: "NEUTRAL"
  }
];

function SignalCard({ signal }: { signal: typeof tradingSignals[0] }) {
  const getSignalColor = (type: string) => {
    switch (type) {
      case "LONG":
        return "bg-emerald-500/20 text-emerald-400 border-emerald-500/50";
      case "SHORT":
        return "bg-red-500/20 text-red-400 border-red-500/50";
      case "CLOSE":
        return "bg-orange-500/20 text-orange-400 border-orange-500/50";
      case "NEUTRAL":
        return "bg-yellow-500/20 text-yellow-400 border-yellow-500/50";
      default:
        return "bg-gray-500/20 text-gray-400 border-gray-500/50";
    }
  };

  const getSignalIcon = (type: string) => {
    switch (type) {
      case "LONG":
        return <TrendingUp className="w-5 h-5" />;
      case "SHORT":
        return <ArrowDownCircle className="w-5 h-5" />;
      case "CLOSE":
        return <XCircle className="w-5 h-5" />;
      case "NEUTRAL":
        return <Minus className="w-5 h-5" />;
      default:
        return <Target className="w-5 h-5" />;
    }
  };

  return (
    <Card className={`bg-[#131722] border border-gray-700/50 hover:border-gray-600 transition-all ${getSignalColor(signal.type)}`}>
      <CardHeader className="pb-3">
        <div className="flex justify-between items-start">
          <div>
            <CardTitle className="text-lg font-bold text-white">
              {signal.ticker}
            </CardTitle>
            <p className="text-sm text-gray-400">{signal.name}</p>
          </div>
          <div className={`px-3 py-1 rounded-full text-sm font-bold border ${getSignalColor(signal.type)}`}>
            {signal.action}
          </div>
        </div>
      </CardHeader>
      <CardContent className="pt-0">
        <div className="space-y-3">
          <div className="flex items-center gap-2">
            {getSignalIcon(signal.type)}
            <span className="text-sm font-medium">{signal.reason}</span>
          </div>
          
          <div className="grid grid-cols-3 gap-2 text-sm">
            <div className="bg-gray-800/50 p-2 rounded">
              <p className="text-gray-400 text-xs">Konfidenz</p>
              <p className="font-bold">{signal.confidence}%</p>
            </div>
            <div className="bg-gray-800/50 p-2 rounded">
              <p className="text-gray-400 text-xs">Ziel</p>
              <p className="font-bold">{signal.targetPrice}€</p>
            </div>
            <div className="bg-gray-800/50 p-2 rounded">
              <p className="text-gray-400 text-xs">Stop-Loss</p>
              <p className="font-bold text-red-400">{signal.stopLoss}€</p>
            </div>
          </div>
          
          <div className="flex items-center gap-2 text-xs text-gray-400">
            <Target className="w-4 h-4" />
            <span>{signal.timeframe}</span>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}

export default function TradingSignalsPage() {
  const longSignals = tradingSignals.filter(s => s.type === "LONG");
  const shortSignals = tradingSignals.filter(s => s.type === "SHORT");
  const holdSignals = tradingSignals.filter(s => s.type === "NEUTRAL" || s.type === "CLOSE");

  return (
    <div className="min-h-screen bg-[#0a0e1a] text-white p-6">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold mb-2">🎯 Trading Signale</h1>
          <p className="text-gray-400">
            Basierend auf 26-Jahre Backtest-Analyse (4.725 historische Trades)
          </p>
          <div className="flex gap-4 mt-4 text-sm">
            <div className="flex items-center gap-2">
              <div className="w-3 h-3 bg-emerald-500 rounded-full"></div>
              <span>KAUFEN ({longSignals.length})</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-3 h-3 bg-red-500 rounded-full"></div>
              <span>SHORTEN ({shortSignals.length})</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-3 h-3 bg-yellow-500 rounded-full"></div>
              <span>HALTEN/VERKAUFEN ({holdSignals.length})</span>
            </div>
          </div>
        </div>

        {/* Stats Overview */}
        <div className="grid grid-cols-4 gap-4 mb-8">
          <Card className="bg-emerald-500/10 border-emerald-500/30">
            <CardContent className="p-4">
              <div className="text-2xl font-bold text-emerald-400">{longSignals.length}</div>
              <div className="text-sm text-gray-400">KAUF-Signale</div>
            </CardContent>
          </Card>
          <Card className="bg-red-500/10 border-red-500/30">
            <CardContent className="p-4">
              <div className="text-2xl font-bold text-red-400">{shortSignals.length}</div>
              <div className="text-sm text-gray-400">SHORT-Signale</div>
            </CardContent>
          </Card>
          <Card className="bg-yellow-500/10 border-yellow-500/30">
            <CardContent className="p-4">
              <div className="text-2xl font-bold text-yellow-400">{holdSignals.length}</div>
              <div className="text-sm text-gray-400">HALTEN/VERKAUF</div>
            </CardContent>
          </Card>
          <Card className="bg-blue-500/10 border-blue-500/30">
            <CardContent className="p-4">
              <div className="text-2xl font-bold text-blue-400">69%</div>
              <div className="text-sm text-gray-400">Ø Win Rate</div>
            </CardContent>
          </Card>
        </div>

        {/* Long Signals */}
        <div className="mb-8">
          <h2 className="text-xl font-bold mb-4 flex items-center gap-2">
            <TrendingUp className="w-6 h-6 text-emerald-400" />
            <span className="text-emerald-400">KAUFEN (Long)</span>
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {longSignals.map((signal) => (
              <SignalCard key={signal.ticker} signal={signal} />
            ))}
          </div>
        </div>

        {/* Short Signals */}
        <div className="mb-8">
          <h2 className="text-xl font-bold mb-4 flex items-center gap-2">
            <ArrowDownCircle className="w-6 h-6 text-red-400" />
            <span className="text-red-400">SHORTEN (Short)</span>
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {shortSignals.map((signal) => (
              <SignalCard key={signal.ticker} signal={signal} />
            ))}
          </div>
        </div>

        {/* Hold/Close Signals */}
        <div className="mb-8">
          <h2 className="text-xl font-bold mb-4 flex items-center gap-2">
            <Minus className="w-6 h-6 text-yellow-400" />
            <span className="text-yellow-400">HALTEN / VERKAUFEN</span>
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {holdSignals.map((signal) => (
              <SignalCard key={signal.ticker} signal={signal} />
            ))}
          </div>
        </div>

        {/* Disclaimer */}
        <Card className="bg-gray-800/30 border-gray-700/50 mt-8">
          <CardContent className="p-4">
            <div className="flex items-start gap-3">
              <AlertTriangle className="w-5 h-5 text-yellow-400 mt-0.5" />
              <div className="text-sm text-gray-400">
                <p className="font-semibold text-white mb-1">Hinweis:</p>
                <p>
                  Diese Signale basieren auf historischen Backtests (2000-2026) und sind keine 
                  Anlageberatung. Short-Positionen bergen erhöhtes Risiko. 
                  Stop-Loss Limits sind Pflicht! 
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}