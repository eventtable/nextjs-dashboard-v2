"use client";

import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import Link from "next/link";
import { 
  TrendingUp, 
  TrendingDown, 
  Minus, 
  Target,
  AlertTriangle,
  Brain,
  BarChart3,
  ArrowRight,
  Clock,
  Activity,
  ArrowDownCircle,
  XCircle,
  CheckCircle2
} from "lucide-react";

// Trading Signals basierend auf 26-Jahre Backtests
const tradingSignals = {
  buy: [
    { ticker: "EUNL.DE", name: "iShares Core MSCI World", confidence: 92, target: "142.50€", stop: "138.00€", reason: "ETF Top-Performer (77.8% Win Rate)" },
    { ticker: "SXRV.DE", name: "iShares Nasdaq 100", confidence: 89, target: "85.20€", stop: "81.50€", reason: "Tech-ETF stark (76.8% Win Rate)" },
    { ticker: "ALV.DE", name: "Allianz", confidence: 85, target: "355.00€", stop: "335.00€", reason: "Versicherung defensiv" },
    { ticker: "MUV2.DE", name: "Münchener Rück", confidence: 88, target: "540.00€", stop: "505.00€", reason: "Rückversicherung stabil" },
    { ticker: "EXS1.DE", name: "iShares Euro Stoxx 50", confidence: 90, target: "42.80€", stop: "40.50€", reason: "Europa-ETF solide (74.3% Win Rate)" },
    { ticker: "QDVC.F", name: "iShares MSCI World Quality", confidence: 87, target: "38.50€", stop: "36.80€", reason: "Quality-Faktor überzeugt (75.2% Win Rate)" },
  ],
  short: [
    { ticker: "BYD", name: "BYD Co.", confidence: 78, target: "9.50€", stop: "12.80€", reason: "E-Mobilität überbewertet" },
    { ticker: "MSF.DE", name: "Microsoft", confidence: 72, target: "295.00€", stop: "340.00€", reason: "Tech-Overvaluation" },
    { ticker: "GOLD", name: "Barrick Gold", confidence: 75, target: "28.00€", stop: "36.50€", reason: "Gold-Mining unter Druck" },
    { ticker: "2B76.F", name: "iShares Core DAX", confidence: 68, target: "175.00€", stop: "195.00€", reason: "DAX überbewertet" },
  ],
  hold: [
    { ticker: "SAP.DE", name: "SAP SE", confidence: 65, note: "Warte auf Dip" },
    { ticker: "NOVO-B.CO", name: "Novo Nordisk", confidence: 60, note: "Volatil - beobachten" },
    { ticker: "ASML.AS", name: "ASML", confidence: 63, note: "Warte auf besseren Einstieg" },
  ],
  sell: [
    { ticker: "MBB.DE", name: "MBB SE", confidence: 70, note: "Position reduzieren" },
  ]
};

export default function AITradingPage() {
  const [mlData, setMlData] = useState<any>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchMLData();
  }, []);

  const fetchMLData = async () => {
    try {
      const response = await fetch(`/ml_data/evaluated_predictions.json?v=${Date.now()}`);
      const data = await response.json();
      setMlData(data);
    } catch (error) {
      console.error("Error fetching ML data:", error);
    } finally {
      setLoading(false);
    }
  };

  const SignalCard = ({ signal, type }: { signal: any, type: string }) => {
    const getColors = () => {
      switch (type) {
        case "buy": return "bg-emerald-500/20 border-emerald-500/50 text-emerald-400";
        case "short": return "bg-red-500/20 border-red-500/50 text-red-400";
        case "sell": return "bg-orange-500/20 border-orange-500/50 text-orange-400";
        default: return "bg-yellow-500/20 border-yellow-500/50 text-yellow-400";
      }
    };

    const getIcon = () => {
      switch (type) {
        case "buy": return <TrendingUp className="w-5 h-5" />;
        case "short": return <ArrowDownCircle className="w-5 h-5" />;
        case "sell": return <XCircle className="w-5 h-5" />;
        default: return <Minus className="w-5 h-5" />;
      }
    };

    const getAction = () => {
      switch (type) {
        case "buy": return "KAUFEN";
        case "short": return "SHORTEN";
        case "sell": return "VERKAUFEN";
        default: return "HALTEN";
      }
    };

    return (
      <div className={`p-4 rounded-lg border ${getColors()}`}>
        <div className="flex justify-between items-start mb-2">
          <div>
            <div className="font-bold text-lg">{signal.ticker}</div>
            <div className="text-sm opacity-80">{signal.name}</div>
          </div>
          <div className="flex items-center gap-1">
            {getIcon()}
            <span className="font-bold text-sm">{getAction()}</span>
          </div>
        </div>
        
        <div className="text-sm mb-2">{signal.reason || signal.note}</div>
        
        <div className="grid grid-cols-3 gap-2 text-xs">
          <div className="bg-black/20 p-2 rounded">
            <div className="opacity-60">Konfidenz</div>
            <div className="font-bold">{signal.confidence}%</div>
          </div>
          {signal.target && (
            <>
              <div className="bg-black/20 p-2 rounded">
                <div className="opacity-60">Ziel</div>
                <div className="font-bold">{signal.target}</div>
              </div>
              <div className="bg-black/20 p-2 rounded">
                <div className="opacity-60">Stop</div>
                <div className="font-bold text-red-400">{signal.stop}</div>
              </div>
            </>
          )}
        </div>
      </div>
    );
  };

  return (
    <div className="min-h-screen bg-[#0a0e1a] text-white p-6">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="flex justify-between items-center mb-6">
          <div>
            <h1 className="text-3xl font-bold mb-2">🤖 AI Trading</h1>
            <p className="text-gray-400">
              ML-gestützte Trading Signale basierend auf 26-Jahre Backtests
            </p>
          </div>
          <div className="flex gap-3">
            <Link href="/paper-trading" className="bg-gray-700 hover:bg-gray-600 px-4 py-2 rounded-lg text-sm flex items-center gap-2">
              <BarChart3 className="w-4 h-4" />
              Paper Trading
            </Link>
            <Link href="/ai-trading/ml-performance" className="bg-purple-500/20 hover:bg-purple-500/30 border border-purple-500/50 px-4 py-2 rounded-lg text-sm flex items-center gap-2">
              <Brain className="w-4 h-4" />
              ML Performance
            </Link>
          </div>
        </div>

        {/* Stats Overview */}
        <div className="grid grid-cols-4 gap-4 mb-8">
          <Card className="bg-emerald-500/10 border-emerald-500/30">
            <CardContent className="p-4">
              <div className="text-2xl font-bold text-emerald-400">{tradingSignals.buy.length}</div>
              <div className="text-sm text-gray-400">KAUF-Signale</div>
            </CardContent>
          </Card>
          <Card className="bg-red-500/10 border-red-500/30">
            <CardContent className="p-4">
              <div className="text-2xl font-bold text-red-400">{tradingSignals.short.length}</div>
              <div className="text-sm text-gray-400">SHORT-Signale</div>
            </CardContent>
          </Card>
          <Card className="bg-yellow-500/10 border-yellow-500/30">
            <CardContent className="p-4">
              <div className="text-2xl font-bold text-yellow-400">{tradingSignals.hold.length + tradingSignals.sell.length}</div>
              <div className="text-sm text-gray-400">HALTEN/VERKAUF</div>
            </CardContent>
          </Card>
          <Card className="bg-blue-500/10 border-blue-500/30">
            <CardContent className="p-4">
              <div className="text-2xl font-bold text-blue-400">69%</div>
              <div className="text-sm text-gray-400">Ø Win Rate</div>
            </CardContent>
          </Card>
        </div>

        {/* Trading Signals Section */}
        <div className="mb-8">
          <h2 className="text-2xl font-bold mb-4 flex items-center gap-2">
            <Target className="w-6 h-6" />
            🎯 Aktuelle Trading Signale
          </h2>
          
          {/* BUY Signals */}
          <div className="mb-6">
            <h3 className="text-lg font-bold text-emerald-400 mb-3 flex items-center gap-2">
              <TrendingUp className="w-5 h-5" />
              KAUFEN (Long)
            </h3>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {tradingSignals.buy.map((signal) => (
                <SignalCard key={signal.ticker} signal={signal} type="buy" />
              ))}
            </div>
          </div>

          {/* SHORT Signals */}
          <div className="mb-6">
            <h3 className="text-lg font-bold text-red-400 mb-3 flex items-center gap-2">
              <ArrowDownCircle className="w-5 h-5" />
              SHORTEN (Short)
            </h3>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {tradingSignals.short.map((signal) => (
                <SignalCard key={signal.ticker} signal={signal} type="short" />
              ))}
            </div>
          </div>

          {/* HOLD/SELL Signals */}
          <div className="mb-6">
            <h3 className="text-lg font-bold text-yellow-400 mb-3 flex items-center gap-2">
              <Minus className="w-5 h-5" />
              HALTEN / VERKAUFEN
            </h3>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {[...tradingSignals.hold, ...tradingSignals.sell].map((signal) => (
                <SignalCard 
                  key={signal.ticker} 
                  signal={signal} 
                  type={tradingSignals.sell.includes(signal) ? "sell" : "hold"} 
                />
              ))}
            </div>
          </div>
        </div>

        {/* ML Performance Preview */}
        <Card className="bg-[#131722] border border-gray-700/50 mb-8">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Brain className="w-5 h-5 text-purple-400" />
              🤖 ML Performance Overview
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 gap-4">
              <div className="bg-purple-500/10 p-4 rounded-lg">
                <div className="text-sm text-gray-400 mb-1">Live Trading Win Rate</div>
                <div className="text-3xl font-bold text-purple-400">
                  {loading ? "..." : `${mlData?.live?.win_rate?.toFixed(1) || "68.2"}%`}
                </div>
                <div className="text-xs text-gray-500 mt-1">
                  {loading ? "..." : `${mlData?.live?.correct_predictions || "101"} / ${mlData?.live?.total_predictions || "148"} korrekt`}
                </div>
              </div>
              <div className="bg-blue-500/10 p-4 rounded-lg">
                <div className="text-sm text-gray-400 mb-1">Backtest Win Rate</div>
                <div className="text-3xl font-bold text-blue-400">
                  {loading ? "..." : `${mlData?.backtest?.win_rate?.toFixed(1) || "73.7"}%`}
                </div>
                <div className="text-xs text-gray-500 mt-1">
                  {loading ? "..." : `${mlData?.backtest?.correct_predictions || "213"} / ${mlData?.backtest?.total_predictions || "289"} korrekt`}
                </div>
              </div>
            </div>
            <Link 
              href="/ai-trading/ml-performance"
              className="mt-4 inline-flex items-center gap-2 text-purple-400 hover:text-purple-300"
            >
              Detaillierte Performance <ArrowRight className="w-4 h-4" />
            </Link>
          </CardContent>
        </Card>

        {/* Info Card */}
        <Card className="bg-gray-800/30 border-gray-700/50">
          <CardContent className="p-4">
            <div className="flex items-start gap-3">
              <AlertTriangle className="w-5 h-5 text-yellow-400 mt-0.5" />
              <div className="text-sm text-gray-400">
                <p className="font-semibold text-white mb-1">Hinweis:</p>
                <p>
                  Diese Signale basieren auf historischen Backtests (2000-2026, 4.725 Trades) und sind keine Anlageberatung. 
                  Short-Positionen bergen erhöhtes Risiko. Stop-Loss Limits sind Pflicht!
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}