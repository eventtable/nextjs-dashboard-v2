import { Inter } from 'next/font/google';
import './globals.css';
import type { Metadata } from 'next';
import Providers from '@/components/providers';

export const dynamic = 'force-dynamic';

const inter = Inter({ subsets: ['latin'] });

export const metadata: Metadata = {
  metadataBase: new URL(process.env.NEXTAUTH_URL || 'http://localhost:3000'),
  title: 'Aktien-Börsenprofi – Matrix 2.0',
  description: 'Professionelle Aktienanalyse nach der Matrix 2.0 Strategie mit Live-Marktdaten',
  icons: {
    icon: '/favicon.svg',
    shortcut: '/favicon.svg',
  },
  robots: {
    index: false,
    follow: false,
    nocache: true,
    googleBot: {
      index: false,
      follow: false,
      noimageindex: true,
    },
  },
  openGraph: {
    title: 'Aktien-Börsenprofi – Matrix 2.0',
    description: 'Professionelle Aktienanalyse nach der Matrix 2.0 Strategie',
    images: ['/og-image.png'],
  },
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="de" className="dark">
      <head>
        <script src="https://apps.abacus.ai/chatllm/appllm-lib.js"></script>
      </head>
      <body className={`${inter.className} bg-[#0a0e1a] text-white min-h-screen`}>
        <Providers>{children}</Providers>
      </body>
    </html>
  );
}