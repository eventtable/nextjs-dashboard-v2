'use client';

import { useState } from 'react';
import { motion } from 'framer-motion';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import { Play, ArrowLeft, TrendingUp, TrendingDown, Activity } from 'lucide-react';
import Link from 'next/link';
import SharedHeader from '@/components/shared-header';
import { MARKET_SCENARIOS } from '@/lib/yahoo-finance';
import { runBacktest, BacktestResult } from '@/lib/backtest-engine';

export default function BacktestPage() {
  const [selectedScenario, setSelectedScenario] = useState(MARKET_SCENARIOS[0]);
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<BacktestResult | null>(null);
  
  const [config, setConfig] = useState({
    initialCapital: 10000,
    minScore: 60,
    shortThreshold: 35,
    positionSize: 20,
    stopLoss: 10,
    takeProfit: 20,
    maxPositions: 3
  });

  const runTest = async () => {
    setLoading(true);
    try {
      const backtestResult = await runBacktest(selectedScenario, config);
      setResult(backtestResult);
    } catch (error) {
      console.error('Backtest Fehler:', error);
      alert('Fehler beim Backtest');
    }
    setLoading(false);
  };

  return (
    <div className="min-h-screen bg-[#0a0e1a] text-white">
      <SharedHeader />
      
      <main className="pt-24 pb-12 px-4 max-w-7xl mx-auto">
        <div className="flex items-center gap-4 mb-6">
          <Link href="/paper-trading" className="flex items-center gap-2 text-gray-400 hover:text-white">
            <ArrowLeft className="w-5 h-5" />
            <span>Zurück</span>
          </Link>
        </div>

        <h1 className="text-3xl font-bold mb-2 flex items-center gap-3">
          <Activity className="w-8 h-8 text-[#f0b90b]" />
          Backtesting Lab
        </h1>
        <p className="text-gray-400 mb-8">
          Teste Matrix-Strategie an historischen Marktzyklen
        </p>

        {/* Scenario Selection */}
        <div className="glass-card rounded-xl p-6 border border-[#1a1f37] mb-8">
          <h2 className="text-xl font-semibold mb-4">Markt-Szenario wählen</h2>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            {MARKET_SCENARIOS.map((scenario) => (
              <motion.div
                key={scenario.id}
                onClick={() => setSelectedScenario(scenario)}
                className={`cursor-pointer rounded-xl p-4 border transition-all ${
                  selectedScenario.id === scenario.id
                    ? 'bg-[#f0b90b]/20 border-[#f0b90b]'
                    : 'bg-[#0d1220] border-[#2a2f47] hover:border-[#f0b90b]/50'
                }`}
              >
                <div className="text-2xl mb-2">{scenario.name.split(' ')[0]}</div>
                <h3 className="font-semibold mb-1">{scenario.name.split(' ').slice(1).join(' ')}</h3>
                <p className="text-xs text-gray-400 mb-2">{scenario.description}</p>
                <div className="text-xs text-gray-500">{scenario.period}</div>
                <div className="flex gap-2 mt-2">
                  <span className={`text-xs px-2 py-0.5 rounded ${
                    scenario.characteristics.trend === 'up' ? 'bg-emerald-500/20 text-emerald-400' :
                    scenario.characteristics.trend === 'down' ? 'bg-red-500/20 text-red-400' :
                    'bg-yellow-500/20 text-yellow-400'
                  }`}>
                    {scenario.characteristics.trend === 'up' ? '📈' : 
                     scenario.characteristics.trend === 'down' ? '📉' : '➡️'}
                  </span>
                  <span className="text-xs text-gray-400">
                    Vol: {scenario.characteristics.volatility}%
                  </span>
                </div>
              </motion.div>
            ))}
          </div>
        </div>

        {/* Config */}
        <div className="glass-card rounded-xl p-6 border border-[#1a1f37] mb-8">
          <h2 className="text-xl font-semibold mb-4">Matrix-Strategie Konfiguration</h2>
          
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div>
              <label className="block text-gray-400 mb-2 text-sm">Startkapital</label>
              <input
                type="number"
                value={config.initialCapital}
                onChange={(e) => setConfig({...config, initialCapital: parseInt(e.target.value)})}
                className="w-full bg-[#0a0e1a] border border-[#2a2f47] rounded-lg px-4 py-2 text-white"
              />
            </div>
            <div>
              <label className="block text-gray-400 mb-2 text-sm">Min. Score (Long)</label>
              <input
                type="number"
                value={config.minScore}
                onChange={(e) => setConfig({...config, minScore: parseInt(e.target.value)})}
                className="w-full bg-[#0a0e1a] border border-[#2a2f47] rounded-lg px-4 py-2 text-white"
              />
            </div>
            <div>
              <label className="block text-gray-400 mb-2 text-sm">Short-Threshold</label>
              <input
                type="number"
                value={config.shortThreshold}
                onChange={(e) => setConfig({...config, shortThreshold: parseInt(e.target.value)})}
                className="w-full bg-[#0a0e1a] border border-[#2a2f47] rounded-lg px-4 py-2 text-white"
              />
            </div>
            <div>
              <label className="block text-gray-400 mb-2 text-sm">Positionsgröße (%)</label>
              <input
                type="number"
                value={config.positionSize}
                onChange={(e) => setConfig({...config, positionSize: parseInt(e.target.value)})}
                className="w-full bg-[#0a0e1a] border border-[#2a2f47] rounded-lg px-4 py-2 text-white"
              />
            </div>
          </div>

          <div className="mt-6">
            <button
              onClick={runTest}
              disabled={loading}
              className="bg-[#f0b90b] hover:bg-[#d4a009] text-black font-semibold px-8 py-3 rounded-lg transition-colors disabled:opacity-50 flex items-center gap-2"
            >
              <Play className="w-5 h-5" />
              {loading ? 'Backtest läuft...' : 'Backtest starten'}
            </button>
          </div>
        </div>

        {/* Results */}
        {result && (
          <div className="space-y-8">
            {/* Stats Grid */}
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
              <div className="bg-emerald-500/10 border border-emerald-500/30 rounded-xl p-4">
                <div className="text-gray-400 mb-1">Gesamtrendite</div>
                <div className={`text-2xl font-bold ${result.totalReturn >= 0 ? 'text-emerald-400' : 'text-red-400'}`}>
                  {result.totalReturn >= 0 ? '+' : ''}{result.totalReturn.toFixed(1)}%
                </div>
              </div>
              <div className="bg-blue-500/10 border border-blue-500/30 rounded-xl p-4">
                <div className="text-gray-400 mb-1">Trades</div>
                <div className="text-2xl font-bold">{result.totalTrades}</div>
                <div className="text-xs text-gray-400">
                  {result.winningTrades} ✅ / {result.losingTrades} ❌
                </div>
              </div>
              <div className="bg-red-500/10 border border-red-500/30 rounded-xl p-4">
                <div className="text-gray-400 mb-1">Max. Drawdown</div>
                <div className="text-2xl font-bold text-red-400">
                  -{result.maxDrawdown.toFixed(1)}%
                </div>
              </div>
              <div className="bg-purple-500/10 border border-purple-500/30 rounded-xl p-4">
                <div className="text-gray-400 mb-1">Sharpe Ratio</div>
                <div className="text-2xl font-bold text-purple-400">
                  {result.sharpeRatio.toFixed(2)}
                </div>
              </div>
            </div>

            {/* Equity Chart */}
            <div className="glass-card rounded-xl p-6 border border-[#1a1f37]">
              <h2 className="text-xl font-semibold mb-4">Equity Curve</h2>
              <div className="h-80">
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart data={result.equityCurve}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#2a2f47" />
                    <XAxis dataKey="date" stroke="#6b7280" />
                    <YAxis stroke="#6b7280" />
                    <Tooltip 
                      contentStyle={{ backgroundColor: '#1a1f37', border: 'none' }}
                      itemStyle={{ color: '#f0b90b' }}
                    />
                    <Line 
                      type="monotone" 
                      dataKey="value" 
                      stroke="#f0b90b" 
                      strokeWidth={2}
                      dot={false}
                    />
                  </LineChart>
                </ResponsiveContainer>
              </div>
            </div>

            {/* Trade History */}
            <div className="glass-card rounded-xl p-6 border border-[#1a1f37]">
              <h2 className="text-xl font-semibold mb-4">Trade Historie</h2>
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead>
                    <tr className="border-b border-[#1a1f37]">
                      <th className="text-left py-2 text-gray-400">Datum</th>
                      <th className="text-left py-2 text-gray-400">Ticker</th>
                      <th className="text-left py-2 text-gray-400">Typ</th>
                      <th className="text-right py-2 text-gray-400">Entry</th>
                      <th className="text-right py-2 text-gray-400">Exit</th>
                      <th className="text-right py-2 text-gray-400">P&L</th>
                    </tr>
                  </thead>
                  <tbody>
                    {result.trades.slice(0, 20).map((trade, idx) => (
                      <tr key={idx} className="border-b border-[#1a1f37]/50">
                        <td className="py-2 text-sm">{trade.date}</td>
                        <td className="py-2 font-semibold">{trade.ticker}</td>
                        <td className="py-2">
                          <span className={`text-xs px-2 py-0.5 rounded ${
                            trade.type === 'long' ? 'bg-emerald-500/20 text-emerald-400' : 'bg-red-500/20 text-red-400'
                          }`}>
                            {trade.type === 'long' ? '📈 LONG' : '🔻 SHORT'}
                          </span>
                        </td>
                        <td className="text-right py-2">{trade.entryPrice.toFixed(2)}€</td>
                        <td className="text-right py-2">{trade.exitPrice?.toFixed(2)}€</td>
                        <td className={`text-right py-2 ${trade.pnl >= 0 ? 'text-emerald-400' : 'text-red-400'}`}>
                          {trade.pnl >= 0 ? '+' : ''}{trade.pnl.toFixed(0)}€ ({trade.pnlPercent.toFixed(1)}%)
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
                {result.trades.length > 20 && (
                  <p className="text-center text-gray-400 mt-4 text-sm">
                    ... und {result.trades.length - 20} weitere Trades
                  </p>
                )}
              </div>
            </div>
          </div>
        )}
      </main>
    </div>
  );
}