'use client';

import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Users, Plus, Trash2, RefreshCw, Loader2, Copy } from 'lucide-react';

interface Friend {
  id: string;
  name: string;
  email: string;
  status: 'active' | 'inactive';
  createdAt: string;
}

export default function FriendsPage() {
  const [friends, setFriends] = useState<Friend[]>([]);
  const [loading, setLoading] = useState(true);
  const [newName, setNewName] = useState('');
  const [newEmail, setNewEmail] = useState('');
  const [inviteCode, setInviteCode] = useState('');

  useEffect(() => {
    loadFriends();
  }, []);

  const loadFriends = async () => {
    setLoading(true);
    try {
      const res = await fetch('/api/friends');
      if (res.ok) {
        const data = await res.json();
        setFriends(data.friends || []);
      }
    } catch (e) {
      console.error('Error loading friends:', e);
    }
    setLoading(false);
  };

  const generateInvite = async () => {
    try {
      const res = await fetch('/api/create-invite', { method: 'POST' });
      if (res.ok) {
        const data = await res.json();
        setInviteCode(data.code || data.inviteCode);
      }
    } catch (e) {
      console.error('Error generating invite:', e);
    }
  };

  const copyInviteLink = () => {
    const link = `${window.location.origin}/register?code=${inviteCode}`;
    navigator.clipboard.writeText(link);
    alert('Einladungslink kopiert!');
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-[#0a0e1a] p-6 flex items-center justify-center">
        <Loader2 className="w-8 h-8 animate-spin text-[#f0b90b]" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#0a0e1a] p-6">
      <h1 className="text-3xl font-bold text-white mb-8 flex items-center gap-3">
        <Users className="w-8 h-8 text-[#f0b90b]" />
        Freunde Verwalten
      </h1>

      {/* Invite Section */}
      <Card className="bg-[#131722] border-gray-700/50 mb-6">
        <CardHeader>
          <CardTitle className="text-white flex items-center gap-2">
            <Plus className="w-5 h-5 text-[#f0b90b]" />
            Neuen Freund Einladen
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          {!inviteCode ? (
            <Button 
              onClick={generateInvite}
              className="bg-[#f0b90b] text-black font-semibold"
            >
              <Plus className="w-4 h-4 mr-2" />
              Einladungscode Generieren
            </Button>
          ) : (
            <div className="space-y-2">
              <div className="flex items-center gap-2">
                <code className="bg-[#0d1220] px-4 py-2 rounded text-[#f0b90b] font-mono">
                  {inviteCode}
                </code>
                <Button onClick={copyInviteLink} variant="outline" size="sm">
                  <Copy className="w-4 h-4" />
                </Button>
              </div>
              <p className="text-sm text-gray-400">
                Link: {typeof window !== 'undefined' ? `${window.location.origin}/register?code=${inviteCode}` : ''}
              </p>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Friends List */}
      <Card className="bg-[#131722] border-gray-700/50">
        <CardHeader className="flex flex-row items-center justify-between">
          <CardTitle className="text-white flex items-center gap-2">
            <Users className="w-5 h-5 text-[#f0b90b]" />
            Registrierte Freunde ({friends.length})
          </CardTitle>
          <Button onClick={loadFriends} variant="outline" size="sm">
            <RefreshCw className="w-4 h-4" />
          </Button>
        </CardHeader>
        <CardContent>
          {friends.length === 0 ? (
            <p className="text-gray-400 text-center py-8">
              Noch keine Freunde registriert.
            </p>
          ) : (
            <div className="space-y-3">
              {friends.map((friend) => (
                <div 
                  key={friend.id} 
                  className="flex items-center justify-between bg-[#0d1220] p-4 rounded-lg"
                >
                  <div>
                    <p className="font-semibold text-white">{friend.name}</p>
                    <p className="text-sm text-gray-400">{friend.email}</p>
                    <p className="text-xs text-gray-500">
                      {friend.status === 'active' ? '🟢 Aktiv' : '⚪ Inaktiv'} • 
                      {new Date(friend.createdAt).toLocaleDateString('de-DE')}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
