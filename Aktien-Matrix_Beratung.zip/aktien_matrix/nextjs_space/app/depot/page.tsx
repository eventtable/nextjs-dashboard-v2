'use client';

import { useState, useEffect } from 'react';
import Link from 'next/link';
import { 
  Activity, 
  TrendingUp, 
  TrendingDown, 
  Wallet, 
  PieChart,
  Zap,
  Filter,
  BarChart3,
  Grid3X3,
  BellRing,
  LineChart,
  Trophy,
  AlertTriangle,
  Newspaper,
  RefreshCw
} from 'lucide-react';
import SharedHeader from '@/components/shared-header';
import NewsTicker from '@/components/news-ticker';
import TradingViewChart from '@/components/depot/tradingview-chart';
import { SmartMoneyDashboard } from '@/components/smart-money';
import { 
  depotPositionen, 
  berechneDepotSummen, 
  berechneAssetAllocation,
  type Position
} from '@/data/depot';

// Position mit Live-Daten
interface LivePosition extends Position {
  liveKurs: number;
  liveWert: number;
  liveGewinn: number;
  livePerformance: number;
}

// Mock 52W High/Low data for the charts
const depotAktien = [
  { ticker: 'SAP.DE', name: 'SAP SE', currentPrice: 186.20, fiftyTwoWeekHigh: 220.00, fiftyTwoWeekLow: 135.50 },
  { ticker: 'MSFT', name: 'Microsoft Corp.', currentPrice: 420.55, fiftyTwoWeekHigh: 468.35, fiftyTwoWeekLow: 362.90 },
  { ticker: 'BYD6.DE', name: 'BYD Co. Ltd.', currentPrice: 28.45, fiftyTwoWeekHigh: 35.20, fiftyTwoWeekLow: 22.10 },
  { ticker: 'ALV.DE', name: 'Allianz SE', currentPrice: 245.30, fiftyTwoWeekHigh: 265.00, fiftyTwoWeekLow: 210.50 },
  { ticker: 'MUV2.DE', name: 'Münchener Rück', currentPrice: 520.80, fiftyTwoWeekHigh: 580.00, fiftyTwoWeekLow: 450.00 },
  { ticker: 'NVO', name: 'Novo Nordisk', currentPrice: 82.15, fiftyTwoWeekHigh: 140.00, fiftyTwoWeekLow: 65.00 },
  { ticker: 'GOLD', name: 'Barrick Gold', currentPrice: 32.61, fiftyTwoWeekHigh: 38.00, fiftyTwoWeekLow: 24.50 },
  // ETFs
  { ticker: 'EXS1.DE', name: 'iShares Core DAX', currentPrice: 185.20, fiftyTwoWeekHigh: 210.00, fiftyTwoWeekLow: 160.00 },
];

export default function DepotPage() {
  const [activeTab, setActiveTab] = useState<'depot' | 'charts' | 'smartmoney' | 'risiko'>('depot');
  const [filter, setFilter] = useState<'alle' | 'aktien' | 'etfs' | 'anleihen'>('alle');
  const [livePositions, setLivePositions] = useState<LivePosition[] | null>(null);
  const [loading, setLoading] = useState(true);
  const [lastUpdate, setLastUpdate] = useState<string>('');
  
  // Live-Kurse laden - Einzelner Server-Request für alle 16 Positionen
  useEffect(() => {
    const fetchLivePrices = async () => {
      setLoading(true);
      try {
        // Ein Request für alle Kurse (vermeidet Browser-Timeouts)
        const res = await fetch('/api/depot-prices');
        if (!res.ok) {
          throw new Error(`HTTP ${res.status}`);
        }
        
        const data = await res.json();
        const priceMap = data.prices || {};
        
        // Positionen mit Live-Kursen aktualisieren
        const updatedPositions = depotPositionen.map((pos) => {
          const liveData = priceMap[pos.ticker];
          if (liveData?.price) {
            const liveKurs = liveData.price;
            const liveWert = pos.stueck * liveKurs;
            const investiert = pos.stueck * pos.einstandKurs;
            const liveGewinn = liveWert - investiert;
            const livePerformance = (liveGewinn / investiert) * 100;
            
            return {
              ...pos,
              liveKurs,
              liveWert: Math.round(liveWert * 100) / 100,
              liveGewinn: Math.round(liveGewinn * 100) / 100,
              livePerformance: Math.round(livePerformance * 100) / 100
            };
          }
          
          // Fallback zu statischen Daten
          return {
            ...pos,
            liveKurs: pos.kursProStueck,
            liveWert: pos.wertEur,
            liveGewinn: pos.gewinnEur,
            livePerformance: pos.performanceProzent
          };
        });
        
        setLivePositions(updatedPositions);
        setLastUpdate(new Date().toLocaleTimeString('de-DE'));
      } catch (error) {
        console.error('Fehler beim Laden der Kurse:', error);
        // Bei Fehler: Statische Daten verwenden
        setLivePositions(depotPositionen.map(pos => ({
          ...pos,
          liveKurs: pos.kursProStueck,
          liveWert: pos.wertEur,
          liveGewinn: pos.gewinnEur,
          livePerformance: pos.performanceProzent
        })));
      } finally {
        setLoading(false);
      }
    };
    
    fetchLivePrices();
  }, []);
  
  // Berechnete Summen aus Live-Daten
  const liveSummen = livePositions ? {
    gesamtWert: livePositions.reduce((sum, pos) => sum + pos.liveWert, 0),
    gesamtGewinn: livePositions.reduce((sum, pos) => sum + pos.liveGewinn, 0),
    investiert: livePositions.reduce((sum, pos) => sum + (pos.stueck * pos.einstandKurs), 0),
    performanceProzent: livePositions.length > 0 
      ? (livePositions.reduce((sum, pos) => sum + pos.liveGewinn, 0) / 
         livePositions.reduce((sum, pos) => sum + (pos.stueck * pos.einstandKurs), 0)) * 100 
      : 0,
    anzahlPositionen: livePositions.length
  } : null;
  
  // Fallback zu statischen Daten wenn keine Live-Daten
  const displaySummen = liveSummen || berechneDepotSummen();
  const displayPositions = livePositions || depotPositionen;
  const allocation = berechneAssetAllocation();
  
  const filteredPositions = displayPositions.filter(pos => {
    if (filter === 'alle') return true;
    if (filter === 'aktien') return pos.typ === 'Aktie';
    if (filter === 'etfs') return pos.typ === 'ETF';
    if (filter === 'anleihen') return pos.typ === 'Anleihe';
    return true;
  });

  const tabs = [
    { id: 'depot' as const, label: 'Depot', icon: Grid3X3 },
    { id: 'charts' as const, label: 'Charts', icon: LineChart },
    { id: 'smartmoney' as const, label: '🏆 Profis', icon: Trophy },
    { id: 'risiko' as const, label: 'Risiko', icon: AlertTriangle },
  ];

  return (
    <div className="min-h-screen bg-[#0a0e1a] text-white">
      {/* Shared Header */}
      <SharedHeader />

      {/* Main Content */}
      <main className="pt-24 pb-12 px-4 sm:px-6 max-w-7xl mx-auto">
        {/* Page Title */}
        <div className="mb-6">
          <h1 className="text-2xl font-bold flex items-center gap-2">
            <Wallet className="w-6 h-6 text-[#f0b90b]" />
            Mein Depot
          </h1>
          <p className="text-gray-400 text-sm mt-1">Übersicht aller Positionen und Asset Allocation</p>
        </div>

        {/* News Ticker - Full Width */}
        <div className="mb-8">
          <NewsTicker />
        </div>

        {/* Main Navigation Tabs */}
        <div className="mb-8">
          <div className="flex flex-wrap gap-2 p-2 bg-[#0d1220] border border-[#1a1f37] rounded-xl">
            {tabs.map((tab) => {
              const Icon = tab.icon;
              return (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id)}
                  className={`flex items-center gap-2 px-5 py-3 rounded-lg text-sm font-medium transition-all flex-1 sm:flex-none justify-center ${
                    activeTab === tab.id
                      ? 'bg-[#f0b90b] text-black shadow-lg shadow-[#f0b90b]/20'
                      : 'text-gray-400 hover:text-white hover:bg-[#1a1f37]'
                  }`}
                >
                  <Icon className="w-4 h-4" />
                  {tab.label}
                </button>
              );
            })}
          </div>
        </div>

        {/* Tab Content */}
        <div className="min-h-[600px]">
          {/* Depot Tab */}
          {activeTab === 'depot' && (
            <div className="space-y-8">
              {/* Key Metrics */}
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
                <div className="bg-[#0d1220] border border-[#1a1f37] rounded-xl p-5">
                  <div className="flex items-center gap-2 mb-2">
                    <Wallet className="w-4 h-4 text-[#f0b90b]" />
                    <span className="text-sm text-gray-400">Gesamtwert</span>
                    {loading && <RefreshCw className="w-3 h-3 text-[#f0b90b] animate-spin" />}
                  </div>
                  <div className="text-2xl font-bold">
                    {displaySummen.gesamtWert.toLocaleString('de-DE', { style: 'currency', currency: 'EUR' })}
                  </div>
                  {lastUpdate && <div className="text-xs text-gray-500 mt-1">Aktualisiert: {lastUpdate}</div>}
                </div>

                <div className="bg-[#0d1220] border border-[#1a1f37] rounded-xl p-5">
                  <div className="flex items-center gap-2 mb-2">
                    {displaySummen.gesamtGewinn >= 0 ? (
                      <TrendingUp className="w-4 h-4 text-emerald-400" />
                    ) : (
                      <TrendingDown className="w-4 h-4 text-red-400" />
                    )}
                    <span className="text-sm text-gray-400">Gesamtgewinn</span>
                  </div>
                  <div className={`text-2xl font-bold ${displaySummen.gesamtGewinn >= 0 ? 'text-emerald-400' : 'text-red-400'}`}>
                    {displaySummen.gesamtGewinn >= 0 ? '+' : ''}
                    {displaySummen.gesamtGewinn.toLocaleString('de-DE', { style: 'currency', currency: 'EUR' })}
                  </div>
                </div>

                <div className="bg-[#0d1220] border border-[#1a1f37] rounded-xl p-5">
                  <div className="flex items-center gap-2 mb-2">
                    <Activity className="w-4 h-4 text-[#60B5FF]" />
                    <span className="text-sm text-gray-400">Performance</span>
                  </div>
                  <div className={`text-2xl font-bold ${displaySummen.performanceProzent >= 0 ? 'text-emerald-400' : 'text-red-400'}`}>
                    {displaySummen.performanceProzent >= 0 ? '+' : ''}{displaySummen.performanceProzent.toFixed(2)}%
                  </div>
                </div>

                <div className="bg-[#0d1220] border border-[#1a1f37] rounded-xl p-5">
                  <div className="flex items-center gap-2 mb-2">
                    <PieChart className="w-4 h-4 text-[#f0b90b]" />
                    <span className="text-sm text-gray-400">Positionen</span>
                  </div>
                  <div className="text-2xl font-bold">
                    {displaySummen.anzahlPositionen}
                  </div>
                </div>
              </div>

              {/* Asset Allocation & Positions */}
              <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                {/* Asset Allocation */}
                <div className="bg-[#0d1220] border border-[#1a1f37] rounded-xl p-6">
                  <h2 className="text-lg font-semibold flex items-center gap-2 mb-4">
                    <PieChart className="w-5 h-5 text-[#f0b90b]" />
                    Asset Allocation
                  </h2>
                  
                  <div className="space-y-4">
                    {allocation.map((asset) => (
                      <div key={asset.name} className="space-y-2">
                        <div className="flex justify-between text-sm">
                          <span className="text-gray-300">{asset.name}</span>
                          <span className="text-gray-400">
                            {asset.prozent.toFixed(1)}%
                          </span>
                        </div>
                        <div className="h-2 bg-[#1a1f37] rounded-full overflow-hidden">
                          <div 
                            className={`h-full rounded-full ${
                              asset.name === 'Aktien' ? 'bg-[#60B5FF]' : 
                              asset.name === 'ETFs' ? 'bg-[#f0b90b]' : 'bg-[#22c55e]'
                            }`}
                            style={{ width: `${asset.prozent}%` }}
                          />
                        </div>
                        <div className="text-xs text-gray-500">
                          {asset.wert.toLocaleString('de-DE', { style: 'currency', currency: 'EUR' })}
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Positions Table */}
                <div className="lg:col-span-2 bg-[#0d1220] border border-[#1a1f37] rounded-xl p-6">
                  <div className="flex items-center justify-between mb-4">
                    <h2 className="text-lg font-semibold flex items-center gap-2">
                      <Wallet className="w-5 h-5 text-[#f0b90b]" />
                      Positionen
                    </h2>
                    
                    {/* Filter */}
                    <div className="flex items-center gap-2">
                      <Filter className="w-4 h-4 text-gray-400" />
                      <div className="flex gap-1">
                        {(['alle', 'aktien', 'etfs', 'anleihen'] as const).map((f) => (
                          <button
                            key={f}
                            onClick={() => setFilter(f)}
                            className={`px-3 py-1 text-xs rounded-lg transition-all ${
                              filter === f
                                ? 'bg-[#f0b90b] text-black font-medium'
                                : 'bg-[#1a1f37] text-gray-400 hover:text-white'
                            }`}
                          >
                            {f.charAt(0).toUpperCase() + f.slice(1)}
                          </button>
                        ))}
                      </div>
                    </div>
                  </div>

                  <div className="overflow-x-auto">
                    <table className="w-full">
                      <thead>
                        <tr className="border-b border-[#1a1f37]">
                          <th className="text-left py-3 px-2 text-sm text-gray-400 font-medium">Name</th>
                          <th className="text-left py-3 px-2 text-sm text-gray-400 font-medium">Ticker</th>
                          <th className="text-left py-3 px-2 text-sm text-gray-400 font-medium">Typ</th>
                          <th className="text-right py-3 px-2 text-sm text-gray-400 font-medium">Aktuell</th>
                          <th className="text-right py-3 px-2 text-sm text-gray-400 font-medium">Einstand</th>
                          <th className="text-right py-3 px-2 text-sm text-gray-400 font-medium">Wert</th>
                          <th className="text-right py-3 px-2 text-sm text-gray-400 font-medium">G/V €</th>
                          <th className="text-right py-3 px-2 text-sm text-gray-400 font-medium">G/V %</th>
                        </tr>
                      </thead>
                      <tbody>
                        {filteredPositions.map((pos) => {
                          // Type guard für LivePosition
                          const isLive = 'liveKurs' in pos;
                          const displayKurs = isLive ? (pos as LivePosition).liveKurs : pos.kursProStueck;
                          const displayWert = isLive ? (pos as LivePosition).liveWert : pos.wertEur;
                          const displayGewinn = isLive ? (pos as LivePosition).liveGewinn : pos.gewinnEur;
                          const displayPerformance = isLive ? (pos as LivePosition).livePerformance : pos.performanceProzent;
                          
                          return (
                            <tr key={pos.id} className="border-b border-[#1a1f37] hover:bg-[#111827] transition-colors">
                              <td className="py-3 px-2">
                                <div className="font-medium">{pos.name}</div>
                                <div className="text-xs text-gray-500">{pos.stueck.toLocaleString('de-DE')} Stk.</div>
                              </td>
                              <td className="py-3 px-2 text-gray-400 text-sm">{pos.ticker}</td>
                              <td className="py-3 px-2">
                                <span className={`inline-flex px-2 py-1 text-xs rounded-full ${
                                  pos.typ === 'Aktie' ? 'bg-[#60B5FF]/20 text-[#60B5FF]' :
                                  pos.typ === 'ETF' ? 'bg-[#f0b90b]/20 text-[#f0b90b]' :
                                  'bg-[#22c55e]/20 text-[#22c55e]'
                                }`}>
                                  {pos.typ}
                                </span>
                              </td>
                              <td className="py-3 px-2 text-right font-medium">
                                {(displayKurs as number).toLocaleString('de-DE', { style: 'currency', currency: 'EUR' })}
                                {isLive && <span className="text-xs text-emerald-400 ml-1">●</span>}
                              </td>
                              <td className="py-3 px-2 text-right text-gray-400">
                                {pos.einstandKurs.toLocaleString('de-DE', { style: 'currency', currency: 'EUR' })}
                              </td>
                              <td className="py-3 px-2 text-right">
                                {displayWert.toLocaleString('de-DE', { style: 'currency', currency: 'EUR' })}
                              </td>
                              <td className={`py-3 px-2 text-right font-medium ${displayGewinn >= 0 ? 'text-emerald-400' : 'text-red-400'}`}>
                                {displayGewinn >= 0 ? '+' : ''}{displayGewinn.toLocaleString('de-DE', { style: 'currency', currency: 'EUR' })}
                              </td>
                              <td className={`py-3 px-2 text-right ${displayPerformance >= 0 ? 'text-emerald-400' : 'text-red-400'}`}>
                                {displayPerformance >= 0 ? '+' : ''}{displayPerformance.toFixed(2)}%
                              </td>
                            </tr>
                          );
                        })}
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* Charts Tab */}
          {activeTab === 'charts' && (
            <div className="space-y-6">
              <div className="bg-[#0d1220] border border-[#1a1f37] rounded-xl p-6">
                <div className="flex items-center justify-between mb-6">
                  <div>
                    <h2 className="text-lg font-semibold flex items-center gap-2">
                      <LineChart className="w-5 h-5 text-[#f0b90b]" />
                      Erweiterte Chart-Analyse
                    </h2>
                    <p className="text-sm text-gray-400 mt-1">
                      Depot-Positionen mit TradingView Charts
                    </p>
                  </div>
                </div>

                <div className="space-y-6">
                  {depotAktien.map((aktie) => (
                    <div key={aktie.ticker} className="bg-[#080c18] border border-[#252a3d] rounded-xl p-4">
                      <TradingViewChart
                        ticker={aktie.ticker}
                        name={aktie.name}
                        currentPrice={aktie.currentPrice}
                        fiftyTwoWeekHigh={aktie.fiftyTwoWeekHigh}
                        fiftyTwoWeekLow={aktie.fiftyTwoWeekLow}
                      />
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* Smart Money Tab */}
          {activeTab === 'smartmoney' && (
            <div className="space-y-6">
              <div className="bg-[#0d1220] border border-[#1a1f37] rounded-xl p-6">
                <div className="mb-6">
                  <h2 className="text-lg font-semibold flex items-center gap-2">
                    <Trophy className="w-5 h-5 text-[#f0b90b]" />
                    Smart Money Dashboard
                  </h2>
                  <p className="text-sm text-gray-400 mt-1">
                    Top-Investoren, 13F Filings, Insider-Transaktionen und Dark Pool Analysen
                  </p>
                </div>
                <SmartMoneyDashboard />
              </div>
            </div>
          )}

          {/* Risiko Tab */}
          {activeTab === 'risiko' && (
            <div className="space-y-6">
              <div className="bg-[#0d1220] border border-[#1a1f37] rounded-xl p-6">
                <div className="flex items-center gap-3 mb-6">
                  <AlertTriangle className="w-6 h-6 text-[#f0b90b]" />
                  <h2 className="text-xl font-semibold">Depot Risiko Analyse</h2>
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="bg-[#080c18] border border-[#1a1f37] rounded-xl p-5">
                    <h3 className="font-semibold mb-4">Risiko Level</h3>
                    <div className="space-y-4">
                      <div>
                        <div className="flex justify-between mb-2">
                          <span className="text-sm text-gray-400">Gesamtrisiko</span>
                          <span className="text-yellow-400 font-medium">Mittel</span>
                        </div>
                        <div className="h-2 bg-[#1a1f37] rounded-full">
                          <div className="h-2 bg-yellow-400 rounded-full" style={{ width: '65%' }} />
                        </div>
                      </div>
                      <div>
                        <div className="flex justify-between mb-2">
                          <span className="text-sm text-gray-400">Diversifikation</span>
                          <span className="text-emerald-400 font-medium">Gut</span>
                        </div>
                        <div className="h-2 bg-[#1a1f37] rounded-full">
                          <div className="h-2 bg-emerald-400 rounded-full" style={{ width: '80%' }} />
                        </div>
                      </div>
                      <div>
                        <div className="flex justify-between mb-2">
                          <span className="text-sm text-gray-400">Volatilität</span>
                          <span className="text-yellow-400 font-medium">Mittel</span>
                        </div>
                        <div className="h-2 bg-[#1a1f37] rounded-full">
                          <div className="h-2 bg-yellow-400 rounded-full" style={{ width: '60%' }} />
                        </div>
                      </div>
                    </div>
                  </div>

                  <div className="bg-[#080c18] border border-[#1a1f37] rounded-xl p-5">
                    <h3 className="font-semibold mb-4">Risiko Faktoren</h3>
                    <ul className="space-y-3 text-sm">
                      <li className="flex items-start gap-2">
                        <span className="text-yellow-400 mt-0.5">⚠️</span>
                        <span className="text-gray-300">Hoher Tech-Exposure durch NVIDIA</span>
                      </li>
                      <li className="flex items-start gap-2">
                        <span className="text-yellow-400 mt-0.5">⚠️</span>
                        <span className="text-gray-300">China-Exposure durch BYD</span>
                      </li>
                      <li className="flex items-start gap-2">
                        <span className="text-emerald-400 mt-0.5">✓</span>
                        <span className="text-gray-300">Gute Diversifikation über Sektoren</span>
                      </li>
                      <li className="flex items-start gap-2">
                        <span className="text-emerald-400 mt-0.5">✓</span>
                        <span className="text-gray-300">Defensive Positionen (Allianz, Munich Re)</span>
                      </li>
                    </ul>
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>
      </main>
    </div>
  );
}