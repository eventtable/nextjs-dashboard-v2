'use client';

import { useState } from 'react';
import Link from 'next/link';
import { ArrowLeft, TrendingUp, Activity } from 'lucide-react';
import StockChartEnhanced from '@/components/depot/stock-chart-enhanced';
import { depotPositionen } from '@/data/depot';

// Mock 52W High/Low Daten für die Demo
const mockStockData = {
  'GOLD': { high: 38.50, low: 24.20, price: 32.61, name: 'Barrick Mining' },
  'BYD6.DE': { high: 14.20, low: 9.50, price: 11.31, name: 'BYD' },
  'SAP.DE': { high: 168.00, low: 125.00, price: 145.80, name: 'SAP' },
  'ALV.DE': { high: 380.00, low: 320.00, price: 351.40, name: 'Allianz' },
  'MUV2.DE': { high: 540.00, low: 480.00, price: 520.20, name: 'Munich Re' },
  'NOVO-B.CO': { high: 45.00, low: 28.00, price: 31.76, name: 'Novo Nordisk' },
  'MSFT': { high: 360.00, low: 280.00, price: 317.25, name: 'Microsoft' },
};

export default function ChartDemoPage() {
  const [selectedTicker, setSelectedTicker] = useState<string>('SAP.DE');
  
  const stockInfo = mockStockData[selectedTicker as keyof typeof mockStockData];
  const aktien = depotPositionen.filter(p => p.typ === 'Aktie');

  return (
    <div className="min-h-screen bg-[#0a0e1a] text-white">
      {/* Header */}
      <header className="fixed top-0 left-0 right-0 z-50 bg-[#0a0e1a]/95 backdrop-blur-md border-b border-[#1a1f37]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 h-16 flex items-center">
          <Link href="/depot" className="flex items-center gap-2 text-gray-400 hover:text-white transition-colors">
            <ArrowLeft className="w-5 h-5" />
            <span>Zurück zum Depot</span>
          </Link>
          <div className="ml-8 flex items-center gap-2">
            <TrendingUp className="w-5 h-5 text-[#f0b90b]" />
            <h1 className="font-semibold">Erweiterte Chart-Analyse</h1>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="pt-24 pb-12 px-4 sm:px-6 max-w-5xl mx-auto">
        {/* Stock Selector */}
        <div className="mb-6">
          <label className="text-sm text-gray-400 mb-2 block flex items-center gap-2">
            <Activity className="w-4 h-4" />
            Aktie auswählen:
          </label>
          <div className="flex flex-wrap gap-2">
            {aktien.map((aktie) => (
              <button
                key={aktie.ticker}
                onClick={() => setSelectedTicker(aktie.ticker)}
                className={`px-4 py-2 text-sm rounded-lg transition-all ${
                  selectedTicker === aktie.ticker
                    ? 'bg-[#f0b90b] text-black font-medium'
                    : 'bg-[#1a1f37] text-gray-300 hover:bg-[#252b47]'
                }`}
              >
                {aktie.ticker}
              </button>
            ))}
          </div>
        </div>

        {/* Enhanced Chart */}
        {stockInfo && (
          <StockChartEnhanced
            ticker={selectedTicker}
            name={stockInfo.name}
            currentPrice={stockInfo.price}
            fiftyTwoWeekHigh={stockInfo.high}
            fiftyTwoWeekLow={stockInfo.low}
          />
        )}

        {/* Info Section */}
        <div className="mt-8 grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* Fibonacci Info */}
          <div className="bg-[#0d1220] border border-[#1a1f37] rounded-xl p-5">
            <h3 className="text-lg font-semibold mb-4 flex items-center gap-2 text-[#60B5FF]">
              <TrendingUp className="w-5 h-5" />
              Fibonacci-Levels
            </h3>
            <p className="text-sm text-gray-400 mb-4">
              Die Fibonacci-Retracement-Levels werden aus dem 52-Wochen-Hoch und -Tief berechnet. 
              Die wichtigsten Level sind 38.2%, 50% und 61.8%.
            </p>
            {stockInfo && (
              <div className="space-y-2 text-sm">
                <div className="flex justify-between">
                  <span className="text-gray-500">52W High:</span>
                  <span className="text-white">{stockInfo.high.toFixed(2)} €</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-500">52W Low:</span>
                  <span className="text-white">{stockInfo.low.toFixed(2)} €</span>
                </div>
                <div className="flex justify-between border-t border-[#1a1f37] pt-2 mt-2">
                  <span className="text-[#60B5FF]">38.2% Level:</span>
                  <span className="text-[#60B5FF]">
                    {(stockInfo.high - (stockInfo.high - stockInfo.low) * 0.382).toFixed(2)} €
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-[#60B5FF]">50% Level:</span>
                  <span className="text-[#60B5FF]">
                    {((stockInfo.high + stockInfo.low) / 2).toFixed(2)} €
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-[#60B5FF]">61.8% Level:</span>
                  <span className="text-[#60B5FF]">
                    {(stockInfo.high - (stockInfo.high - stockInfo.low) * 0.618).toFixed(2)} €
                  </span>
                </div>
              </div>
            )}
          </div>

          {/* EMA Info */}
          <div className="bg-[#0d1220] border border-[#1a1f37] rounded-xl p-5">
            <h3 className="text-lg font-semibold mb-4 flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-[#00D4AA]"></span>
              <span className="text-[#00D4AA]">EMA-Indikatoren</span>
            </h3>
            <p className="text-sm text-gray-400 mb-4">
              Exponentieller Gleitender Durchschnitt (EMA) gibt aktuellen Kursen mehr Gewicht. 
              Wird für Trendbestimmung und Einstiegs-/Ausstiegssignale genutzt.
            </p>
            <div className="space-y-2 text-sm">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <span className="w-3 h-3 rounded-full bg-[#00D4AA]"></span>
                  <span className="text-[#00D4AA]">EMA 50</span>
                </div>
                <span className="text-gray-400">Mittelfristiger Trend</span>
              </div>
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <span className="w-3 h-3 rounded-full bg-[#f0b90b]"></span>
                  <span className="text-[#f0b90b]">EMA 100</span>
                </div>
                <span className="text-gray-400">Langfristiger Trend</span>
              </div>
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <span className="w-3 h-3 rounded-full bg-[#FF6B6B]"></span>
                  <span className="text-[#FF6B6B]">EMA 200</span>
                </div>
                <span className="text-gray-400">Sehr langfristiger Trend</span>
              </div>
            </div>
            <div className="mt-4 p-3 bg-[#1a1f37]/50 rounded-lg text-xs text-gray-500">
              <strong>Formel:</strong> EMA = (Kurs × Multiplikator) + (EMA<sub>gestern</sub> × (1 - Multiplikator))
              <br />
              <strong>Multiplikator:</strong> 2 / (Periode + 1)
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}