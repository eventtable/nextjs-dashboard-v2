'use client'

import { useState } from 'react'
import { signIn } from 'next-auth/react'
import { useRouter } from 'next/navigation'
import Link from 'next/link'

export default function LoginPage() {
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [error, setError] = useState('')
  const [loading, setLoading] = useState(false)
  const router = useRouter()

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)
    setError('')

    console.log('🔍 Login attempt:', { email, password: '***' })

    try {
      const result = await signIn('credentials', {
        email: email.trim().toLowerCase(),
        password: password,
        redirect: false,
        callbackUrl: '/admin'
      })

      console.log('🔍 SignIn result:', result)

      if (result?.error) {
        setError('Ungültige Anmeldedaten')
        setLoading(false)
        return
      }

      if (result?.ok) {
        router.push('/admin')
        router.refresh()
      }
    } catch (err: any) {
      console.error('🔍 Login error:', err)
      setError('Ein Fehler ist aufgetreten')
      setLoading(false)
    }
  }

  return (
    <div className="min-h-screen bg-[#0a0e1a] flex items-center justify-center px-4">
      <div className="max-w-md w-full">
        <div className="text-center mb-8">
          <h1 className="text-3xl font-bold text-white mb-2">Login</h1>
          <p className="text-gray-400">Admin Dashboard</p>
        </div>

        <form onSubmit={handleSubmit} className="bg-[#1a1f37] rounded-xl p-8 border border-[#2a2f47]">
          {error && (
            <div className="bg-red-500/20 border border-red-500/30 text-red-400 px-4 py-3 rounded-lg mb-4">
              {error}
            </div>
          )}

          <div className="mb-4">
            <label htmlFor="email" className="block text-gray-400 mb-2">Email</label>
            <input
              id="email"
              name="email"
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              autoComplete="email"
              className="w-full bg-[#0a0e1a] border border-[#2a2f47] rounded-lg px-4 py-3 text-white focus:border-[#f0b90b] focus:outline-none"
              required
            />
          </div>

          <div className="mb-6">
            <label htmlFor="password" className="block text-gray-400 mb-2">Passwort</label>
            <input
              id="password"
              name="password"
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              autoComplete="current-password"
              className="w-full bg-[#0a0e1a] border border-[#2a2f47] rounded-lg px-4 py-3 text-white focus:border-[#f0b90b] focus:outline-none"
              required
            />
          </div>

          <button
            type="submit"
            disabled={loading}
            className="w-full bg-[#f0b90b] hover:bg-[#d4a009] text-black font-semibold py-3 rounded-lg transition-colors disabled:opacity-50"
          >
            {loading ? 'Wird angemeldet...' : 'Anmelden'}
          </button>
          
          <div className="mt-4 text-center">
            <p className="text-gray-400 text-sm">
              Noch kein Konto?{" "}
              <Link href="/register" className="text-emerald-400 hover:text-emerald-300">
                Mit Invite Code registrieren
              </Link>
            </p>
          </div>
        </form>
      </div>
    </div>
  )
}
