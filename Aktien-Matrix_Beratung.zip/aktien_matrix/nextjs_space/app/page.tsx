'use client';

import { useState, useMemo, useEffect } from 'react';
import { motion } from 'framer-motion';
import Link from 'next/link';
import { 
  Zap, 
  TrendingUp, 
  TrendingDown, 
  Wallet, 
  Activity,
  LayoutGrid,
  PieChart,
  ArrowRight,
  Search,
  Target,
  CheckCircle,
  AlertCircle,
  AlertTriangle,
  XCircle,
  Globe,
  BellRing,
  ShoppingCart,
  Brain,
  Cpu
} from 'lucide-react';
import SharedHeader from '@/components/shared-header';
import { depotPositionen, berechneDepotSummen } from '@/data/depot';

// Matrix Daten (wie in /matrix)
interface MatrixScore {
  id: string;
  name: string;
  ticker: string;
  typ: 'Aktie' | 'ETF' | 'Anleihe';
  fundamentalScore: number;
  technicalScore: number;
  chancenRisiko: number;
  empfehlung: 'strong-buy' | 'buy' | 'hold' | 'reduce' | 'sell';
  wertEur: number;
}

const matrixDaten: MatrixScore[] = [
  { id: '1', name: 'SAP', ticker: 'SAP.DE', typ: 'Aktie', fundamentalScore: 8.5, technicalScore: 7.2, chancenRisiko: 1.2, empfehlung: 'strong-buy', wertEur: 854.40 },
  { id: '2', name: 'Microsoft', ticker: 'MSFT', typ: 'Aktie', fundamentalScore: 7.8, technicalScore: 5.5, chancenRisiko: 0.9, empfehlung: 'hold', wertEur: 1425.60 },
  { id: '3', name: 'BYD', ticker: 'BYD6.DE', typ: 'Aktie', fundamentalScore: 6.5, technicalScore: 7.0, chancenRisiko: 1.1, empfehlung: 'buy', wertEur: 1088.00 },
  { id: '4', name: 'Allianz', ticker: 'ALV.DE', typ: 'Aktie', fundamentalScore: 7.2, technicalScore: 6.5, chancenRisiko: 1.0, empfehlung: 'hold', wertEur: 1425.20 },
  { id: '5', name: 'Munich Re', ticker: 'MUV2.DE', typ: 'Aktie', fundamentalScore: 7.0, technicalScore: 6.2, chancenRisiko: 0.95, empfehlung: 'hold', wertEur: 1243.20 },
  { id: '6', name: 'Novo Nordisk', ticker: 'NOVO-B.CO', typ: 'Aktie', fundamentalScore: 5.2, technicalScore: 4.5, chancenRisiko: 0.6, empfehlung: 'reduce', wertEur: 345.60 },
  { id: '7', name: 'Barrick Mining', ticker: 'GOLD', typ: 'Aktie', fundamentalScore: 8.0, technicalScore: 8.5, chancenRisiko: 1.3, empfehlung: 'strong-buy', wertEur: 518.40 },
  { id: '8', name: 'iShares World', ticker: 'EUNL.DE', typ: 'ETF', fundamentalScore: 6.0, technicalScore: 6.5, chancenRisiko: 1.0, empfehlung: 'hold', wertEur: 2592.00 },
  { id: '9', name: 'iShares MSCI EM', ticker: 'EXS1.DE', typ: 'ETF', fundamentalScore: 5.5, technicalScore: 5.8, chancenRisiko: 0.85, empfehlung: 'hold', wertEur: 1728.00 },
  { id: '10', name: 'iShares Gold', ticker: 'IGLN.L', typ: 'ETF', fundamentalScore: 7.5, technicalScore: 8.0, chancenRisiko: 1.25, empfehlung: 'strong-buy', wertEur: 1728.00 },
  { id: '11', name: 'iShares Silver', ticker: 'SSLV.L', typ: 'ETF', fundamentalScore: 6.5, technicalScore: 7.0, chancenRisiko: 1.1, empfehlung: 'buy', wertEur: 345.60 },
  { id: '12', name: 'iShares Stoxx', ticker: 'EXS0.DE', typ: 'ETF', fundamentalScore: 5.8, technicalScore: 6.0, chancenRisiko: 0.9, empfehlung: 'hold', wertEur: 1209.60 },
  { id: '13', name: 'iShares Div', ticker: 'EXV1.DE', typ: 'ETF', fundamentalScore: 6.2, technicalScore: 6.2, chancenRisiko: 0.95, empfehlung: 'hold', wertEur: 691.20 },
  { id: '14', name: 'iShares S&P 500', ticker: 'EUN3.DE', typ: 'ETF', fundamentalScore: 5.5, technicalScore: 6.0, chancenRisiko: 0.9, empfehlung: 'hold', wertEur: 1728.00 },
  { id: '15', name: 'Lyxor EU Bond', ticker: '2B78.DE', typ: 'Anleihe', fundamentalScore: 4.0, technicalScore: 4.0, chancenRisiko: 0.5, empfehlung: 'hold', wertEur: 518.40 },
];

// Empfehlung Config
const empfehlungConfig = {
  'strong-buy': { label: 'Strong Buy', color: '#22c55e', bg: 'bg-emerald-500/20', border: 'border-emerald-500/30', icon: CheckCircle },
  'buy': { label: 'Buy', color: '#22c55e', bg: 'bg-emerald-500/20', border: 'border-emerald-500/30', icon: CheckCircle },
  'hold': { label: 'Hold', color: '#eab308', bg: 'bg-yellow-500/20', border: 'border-yellow-500/30', icon: AlertCircle },
  'reduce': { label: 'Reduce', color: '#f97316', bg: 'bg-orange-500/20', border: 'border-orange-500/30', icon: AlertTriangle },
  'sell': { label: 'Sell', color: '#ef4444', bg: 'bg-red-500/20', border: 'border-red-500/30', icon: XCircle },
};

// Matrix Mini Card
function MatrixMiniCard({ position }: { position: MatrixScore }) {
  const empfehlung = empfehlungConfig[position.empfehlung];
  const Icon = empfehlung.icon;
  
  return (
    <Link href={`/matrix?ticker=${position.ticker}`}>
      <div className={`bg-[#0d1220] border ${empfehlung.border} rounded-xl p-3 hover:bg-[#111827] transition-all hover:scale-105 cursor-pointer`}>
        <div className="flex items-start justify-between mb-2">
          <div>
            <h3 className="font-semibold text-white text-sm">{position.name}</h3>
            <p className="text-[10px] text-gray-400">{position.ticker}</p>
          </div>
          <Icon className="w-4 h-4" style={{ color: empfehlung.color }} />
        </div>
        
        <div className="flex items-center justify-between mb-2">
          <span className="text-xs text-gray-400">{position.wertEur.toLocaleString('de-DE')} €</span>
          <span className={`text-[10px] px-1.5 py-0.5 rounded ${empfehlung.bg}`} style={{ color: empfehlung.color }}>
            {empfehlung.label}
          </span>
        </div>
        
        <div className="grid grid-cols-2 gap-1 text-[9px]">
          <div className="flex justify-between">
            <span className="text-gray-500">F:</span>
            <span className="text-[#60B5FF]">{position.fundamentalScore.toFixed(1)}</span>
          </div>
          <div className="flex justify-between">
            <span className="text-gray-500">T:</span>
            <span className="text-purple-400">{position.technicalScore.toFixed(1)}</span>
          </div>
        </div>
      </div>
    </Link>
  );
}

// ML Performance Widget - Live & Backtest
function MLPerformanceWidget() {
  const [data, setData] = useState<any>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetch('/ml_data/ml_scorecard.json?v=' + Date.now())
      .then(res => res.json())
      .then(data => {
        setData(data);
        setLoading(false);
      })
      .catch(() => {
        setLoading(false);
      });
  }, []);

  if (loading) {
    return (
      <div className="glass-card rounded-xl p-6 border border-[#1a1f37]">
        <div className="flex items-center justify-center py-8 text-gray-400">
          <div className="animate-spin w-6 h-6 border-2 border-purple-400 border-t-transparent rounded-full mr-3" />
          Lade ML Agent Daten...
        </div>
      </div>
    );
  }

  const live = data?.live || { win_rate: 0, total_predictions: 0, score_grade: '-' };
  const backtest = data?.backtest || { win_rate: 0, total_predictions: 0, score_grade: '-' };
  const overall = data?.overall || { win_rate: 0, total_predictions: 0, score_grade: '-' };

  return (
    <Link href="/ai-trading/ml-performance">
      <div className="glass-card rounded-xl p-6 border border-purple-500/30 hover:border-purple-500/50 transition-all hover:scale-[1.02] cursor-pointer bg-purple-500/5">
        <h3 className="text-lg font-semibold mb-4 flex items-center gap-2 text-purple-400">
          <Cpu className="w-5 h-5" />
          ML Agent Performance
        </h3>
        
        <div className="grid grid-cols-3 gap-4">
          {/* LIVE */}
          <div className="text-center p-3 bg-red-500/10 rounded-lg border border-red-500/20">
            <div className="text-xs text-red-400 mb-1">🔴 LIVE</div>
            <div className="text-2xl font-bold text-white">{live.win_rate}%</div>
            <div className="text-xs text-gray-400">{live.total_predictions} Trades</div>
          </div>

          {/* BACKTEST */}
          <div className="text-center p-3 bg-purple-500/10 rounded-lg border border-purple-500/20">
            <div className="text-xs text-purple-400 mb-1">📊 Backtest</div>
            <div className="text-2xl font-bold text-white">{backtest.win_rate}%</div>
            <div className="text-xs text-gray-400">{backtest.total_predictions} Trades</div>
          </div>

          {/* GESAMT */}
          <div className="text-center p-3 bg-emerald-500/10 rounded-lg border border-emerald-500/20">
            <div className="text-xs text-emerald-400 mb-1">📈 Gesamt</div>
            <div className="text-2xl font-bold text-white">{overall.win_rate}%</div>
            <div className="text-xs text-gray-400">{overall.total_predictions} Trades</div>
          </div>
        </div>

        <div className="mt-4 text-center text-sm text-gray-400">
          Klicken für detaillierte Analyse →
        </div>
      </div>
    </Link>
  );
}

export default function HomePage() {
  const [searchQuery, setSearchQuery] = useState('');
  const [liveSummen, setLiveSummen] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  
  // Live-Daten laden
  useEffect(() => {
    const fetchLiveData = async () => {
      try {
        const res = await fetch('/api/depot-prices');
        if (res.ok) {
          const data = await res.json();
          const prices = data.prices || {};
          
          // Berechne Summen aus Live-Daten
          let gesamtWert = 0;
          let gesamtGewinn = 0;
          let investiert = 0;
          
          depotPositionen.forEach(pos => {
            const liveData = prices[pos.ticker];
            if (liveData?.price) {
              const liveWert = pos.stueck * liveData.price;
              const posInvestiert = pos.stueck * pos.einstandKurs;
              const liveGewinn = liveWert - posInvestiert;
              
              gesamtWert += liveWert;
              gesamtGewinn += liveGewinn;
              investiert += posInvestiert;
            } else {
              // Fallback zu statischen Daten
              gesamtWert += pos.wertEur;
              gesamtGewinn += pos.gewinnEur;
              investiert += pos.stueck * pos.einstandKurs;
            }
          });
          
          const performanceProzent = investiert > 0 ? ((gesamtWert - investiert) / investiert) * 100 : 0;
          
          setLiveSummen({
            gesamtWert: Math.round(gesamtWert * 100) / 100,
            gesamtGewinn: Math.round(gesamtGewinn * 100) / 100,
            investiert: Math.round(investiert * 100) / 100,
            performanceProzent: Math.round(performanceProzent * 100) / 100,
            anzahlPositionen: depotPositionen.length
          });
        }
      } catch (err) {
        console.error('Fehler beim Laden der Live-Daten:', err);
      } finally {
        setLoading(false);
      }
    };
    
    fetchLiveData();
  }, []);
  
  // Verwende Live-Daten oder Fallback zu statischen
  const summen = liveSummen || berechneDepotSummen();
  
  // Stats
  const stats = {
    strongBuy: matrixDaten.filter(p => p.empfehlung === 'strong-buy').length,
    buy: matrixDaten.filter(p => p.empfehlung === 'buy').length,
    hold: matrixDaten.filter(p => p.empfehlung === 'hold').length,
    reduce: matrixDaten.filter(p => p.empfehlung === 'reduce').length,
  };

  return (
    <div className="min-h-screen bg-[#0a0e1a] text-white">
      <SharedHeader />

      <main className="pt-24 pb-12 px-4 sm:px-6 max-w-7xl mx-auto">
        {/* Header */}
        <div className="mb-6">
          <h1 className="text-3xl font-bold mb-2 flex items-center gap-3">
            <Zap className="w-8 h-8 text-[#f0b90b]" />
            Matrix 2.0 Dashboard
          </h1>
          <p className="text-gray-400">
            Dein Depot, deine Matrix, deine Entscheidungen
          </p>
        </div>

        {/* Aktien-Analyse (Quick Search) - OBEN */}
        <div className="glass-card rounded-xl p-5 border border-[#f0b90b]/30 mb-6">
          <h2 className="text-lg font-semibold mb-3 flex items-center gap-2">
            <Search className="w-5 h-5 text-[#f0b90b]" />
            Aktien-Analyse (Quick Search)
          </h2>
          
          <div className="flex gap-3 items-center">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Aktie suchen (z.B. SAP, Apple, NVIDIA...)"
                className="w-full bg-[#0d1220] border border-[#2a2f47] rounded-lg pl-10 pr-4 py-3 text-white placeholder-gray-500 focus:outline-none focus:border-[#f0b90b] transition-all"
              />
            </div>
            <Link 
              href={searchQuery ? `/matrix?search=${encodeURIComponent(searchQuery)}` : '/matrix'}
              className="bg-[#f0b90b] hover:bg-[#d4a017] text-black font-semibold px-6 py-3 rounded-lg transition-all flex items-center gap-2"
            >
              <Search className="w-4 h-4" />
              Analysieren
            </Link>
          </div>
          
          <div className="flex gap-2 mt-3 flex-wrap items-center">
            <span className="text-gray-500 text-sm">Schnellauswahl:</span>
            {['SAP.DE', 'AAPL', 'NVDA', 'MSFT', 'BYD6.DE'].map((ticker) => (
              <button
                key={ticker}
                onClick={() => setSearchQuery(ticker)}
                className="text-sm px-3 py-1.5 rounded-full bg-[#0d1220] hover:bg-[#1a1f37] text-gray-300 hover:text-[#f0b90b] border border-[#2a2f47] transition-all"
              >
                {ticker}
              </button>
            ))}
          </div>
        </div>

        {/* Quick Actions Row */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-8">
          <Link href="/depot" className="glass-card rounded-xl p-4 border border-[#1a1f37] hover:border-[#f0b90b]/50 transition-all group">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-[#f0b90b]/20 rounded-lg flex items-center justify-center">
                <Wallet className="w-5 h-5 text-[#f0b90b]" />
              </div>
              <div>
                <p className="text-sm text-gray-400">Depot</p>
                <p className="font-semibold group-hover:text-[#f0b90b] transition-colors">Details ansehen →</p>
              </div>
            </div>
          </Link>
          
          <Link href="/risiko" className="glass-card rounded-xl p-4 border border-[#1a1f37] hover:border-red-500/50 transition-all group">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-red-500/20 rounded-lg flex items-center justify-center">
                <BellRing className="w-5 h-5 text-red-400" />
              </div>
              <div>
                <p className="text-sm text-gray-400">Risiko</p>
                <p className="font-semibold group-hover:text-red-400 transition-colors">Szenarien checken →</p>
              </div>
            </div>
          </Link>
          
          <Link href="/empfehlungen" className="glass-card rounded-xl p-4 border border-[#1a1f37] hover:border-emerald-500/50 transition-all group">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-emerald-500/20 rounded-lg flex items-center justify-center">
                <ShoppingCart className="w-5 h-5 text-emerald-400" />
              </div>
              <div>
                <p className="text-sm text-gray-400">Empfehlungen</p>
                <p className="font-semibold group-hover:text-emerald-400 transition-colors">Nachkäufe & Risiko →</p>
              </div>
            </div>
          </Link>
          
          <Link href="/entwicklung" className="glass-card rounded-xl p-4 border border-[#1a1f37] hover:border-blue-500/50 transition-all group">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-blue-500/20 rounded-lg flex items-center justify-center">
                <TrendingUp className="w-5 h-5 text-blue-400" />
              </div>
              <div>
                <p className="text-sm text-gray-400">Entwicklung</p>
                <p className="font-semibold group-hover:text-blue-400 transition-colors">Depot-Verlauf →</p>
              </div>
            </div>
          </Link>
        </div>

        {/* Depot Overview Cards */}
        <div className="glass-card rounded-xl p-6 mb-8 border border-[#f0b90b]/30">
          <h2 className="text-xl font-semibold mb-4 flex items-center gap-2">
            <Wallet className="w-6 h-6 text-[#f0b90b]" />
            Depot-Übersicht
          </h2>
          
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div className="bg-[#0d1220] rounded-lg p-4 border border-[#1a1f37]">
              <p className="text-xs text-gray-400 mb-1">Gesamtwert</p>
              <p className="text-2xl font-bold text-white">{summen.gesamtWert.toLocaleString('de-DE')} €</p>
            </div>
            
            <div className="bg-[#0d1220] rounded-lg p-4 border border-[#1a1f37]">
              <p className="text-xs text-gray-400 mb-1">Gewinn/Verlust</p>
              <p className={`text-2xl font-bold ${summen.gesamtGewinn >= 0 ? 'text-emerald-400' : 'text-red-400'}`}>
                {summen.gesamtGewinn >= 0 ? '+' : ''}{summen.gesamtGewinn.toLocaleString('de-DE')} €
              </p>
            </div>
            
            <div className="bg-[#0d1220] rounded-lg p-4 border border-[#1a1f37]">
              <p className="text-xs text-gray-400 mb-1">Rendite</p>
              <p className={`text-2xl font-bold ${summen.performanceProzent >= 0 ? 'text-emerald-400' : 'text-red-400'}`}>
                {summen.performanceProzent >= 0 ? '+' : ''}{summen.performanceProzent}%
              </p>
              <p className="text-xs text-gray-500 mt-1">{summen.investiert.toLocaleString('de-DE')} € investiert</p>
            </div>
            
            <div className="bg-[#0d1220] rounded-lg p-4 border border-[#1a1f37]">
              <p className="text-xs text-gray-400 mb-1">Positionen</p>
              <p className="text-2xl font-bold text-white">{depotPositionen.length}</p>
            </div>
          </div>
          
          {/* Asset Allocation Mini */}
          <div className="mt-6 grid grid-cols-3 gap-4">
            <div className="bg-[#0d1220] rounded-lg p-3 border border-[#1a1f37]">
              <p className="text-xs text-gray-400 mb-1">Aktien</p>
              <div className="flex items-center gap-2">
                <div className="flex-1 h-2 bg-[#1a1f37] rounded-full overflow-hidden">
                  <div className="h-full bg-[#60B5FF] rounded-full" style={{ width: '65%' }} />
                </div>
                <span className="text-sm font-semibold">65%</span>
              </div>
            </div>
            
            <div className="bg-[#0d1220] rounded-lg p-3 border border-[#1a1f37]">
              <p className="text-xs text-gray-400 mb-1">ETFs</p>
              <div className="flex items-center gap-2">
                <div className="flex-1 h-2 bg-[#1a1f37] rounded-full overflow-hidden">
                  <div className="h-full bg-[#f0b90b] rounded-full" style={{ width: '30%' }} />
                </div>
                <span className="text-sm font-semibold">30%</span>
              </div>
            </div>
            
            <div className="bg-[#0d1220] rounded-lg p-3 border border-[#1a1f37]">
              <p className="text-xs text-gray-400 mb-1">Anleihen</p>
              <div className="flex items-center gap-2">
                <div className="flex-1 h-2 bg-[#1a1f37] rounded-full overflow-hidden">
                  <div className="h-full bg-emerald-400 rounded-full" style={{ width: '5%' }} />
                </div>
                <span className="text-sm font-semibold">5%</span>
              </div>
            </div>
          </div>
        
          {/* Quick Analysis */}
          <div className="mt-6">
            <h3 className="text-sm font-semibold text-gray-400 mb-3 flex items-center gap-2">
              <Zap className="w-4 h-4 text-[#f0b90b]" />
              Quick Analyse
            </h3>
            <div className="flex flex-wrap gap-2">
              {[
                { ticker: '^GDAXI', name: '🇩🇪 DAX' },
                { ticker: '^GSPC', name: '🇺🇸 S&P 500' },
                { ticker: '^IXIC', name: '🇺🇸 NASDAQ' },
                { ticker: 'SAP.DE', name: 'SAP' },
                { ticker: 'MSF.DE', name: 'Microsoft' },
                { ticker: 'ALV.DE', name: 'Allianz' },
                { ticker: 'MUV2.DE', name: 'Munich Re' },
                { ticker: 'NOVO-B.CO', name: 'Novo Nordisk' },
                { ticker: 'MBK.DE', name: 'MBB SE' },
                { ticker: 'ABX.TO', name: 'Barrick Gold' },
                { ticker: 'BYD', name: 'BYD' },
                { ticker: 'EXS1.DE', name: 'iShares DAX' },
                { ticker: 'EUNL.DE', name: 'MSCI World' },
                { ticker: 'SXRV.DE', name: 'NASDAQ 100' },
                { ticker: 'QDVC.F', name: 'Div. Arist.' },
              ].map((stock) => (
                <Link
                  key={stock.ticker}
                  href={`/matrix?ticker=${stock.ticker}`}
                  className="px-3 py-1.5 bg-[#1a1f37] hover:bg-[#2a2f47] border border-[#2a2f47] hover:border-[#f0b90b]/50 rounded-lg text-xs text-gray-300 hover:text-white transition-all"
                >
                  {stock.name}
                </Link>
              ))}
            </div>
          </div>
        </div>

        {/* Matrix 2.0 Section */}
        <div className="mb-8">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-xl font-semibold flex items-center gap-2">
              <LayoutGrid className="w-6 h-6 text-[#f0b90b]" />
              Matrix 2.0 - Deine Positionen
            </h2>
            <Link href="/matrix" className="text-sm text-[#f0b90b] hover:underline flex items-center gap-1">
              Vollständige Matrix <ArrowRight className="w-4 h-4" />
            </Link>
          </div>
          
          {/* Stats */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mb-6">
            <div className="bg-emerald-500/10 border border-emerald-500/30 rounded-lg p-3">
              <p className="text-xs text-emerald-400 mb-1">🟢 Buy/Strong Buy</p>
              <p className="text-xl font-bold text-emerald-400">{stats.strongBuy + stats.buy}</p>
            </div>
            <div className="bg-yellow-500/10 border border-yellow-500/30 rounded-lg p-3">
              <p className="text-xs text-yellow-400 mb-1">🟡 Hold</p>
              <p className="text-xl font-bold text-yellow-400">{stats.hold}</p>
            </div>
            <div className="bg-orange-500/10 border border-orange-500/30 rounded-lg p-3">
              <p className="text-xs text-orange-400 mb-1">🟠 Reduce</p>
              <p className="text-xl font-bold text-orange-400">{stats.reduce}</p>
            </div>
            <div className="bg-[#f0b90b]/10 border border-[#f0b90b]/30 rounded-lg p-3">
              <p className="text-xs text-[#f0b90b] mb-1">Gesamt</p>
              <p className="text-xl font-bold text-[#f0b90b]">{matrixDaten.length}</p>
            </div>
          </div>
          
          {/* Matrix Grid */}
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 xl:grid-cols-8 gap-3">
            {matrixDaten.map((pos) => (
              <MatrixMiniCard key={pos.id} position={pos} />
            ))}
          </div>
        </div>

        {/* ML Agent Performance Widget */}
        <div className="mb-8">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-xl font-semibold flex items-center gap-2">
              <Brain className="w-6 h-6 text-purple-400" />
              ML Trading Agent
            </h2>
            <Link href="/ai-trading/ml-performance" className="text-sm text-purple-400 hover:underline flex items-center gap-1">
              Details ansehen <ArrowRight className="w-4 h-4" />
            </Link>
          </div>
          
          <MLPerformanceWidget />
        </div>

      </main>
    </div>
  );
}
