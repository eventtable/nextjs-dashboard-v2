'use client'
import { useState } from 'react'
import { useRouter } from 'next/navigation'

export default function ResetPasswordPage() {
  const [email, setEmail] = useState('')
  const [oldPassword, setOldPassword] = useState('')
  const [newPassword, setNewPassword] = useState('')
  const [confirm, setConfirm] = useState('')
  const [error, setError] = useState('')
  const [success, setSuccess] = useState(false)
  const [loading, setLoading] = useState(false)
  const router = useRouter()

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setError('')
    if (newPassword !== confirm) { setError('Passwörter stimmen nicht überein'); return }
    if (newPassword.length < 8) { setError('Passwort muss mindestens 8 Zeichen haben'); return }
    setLoading(true)

    const res = await fetch('/api/auth/reset-password', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email, oldPassword, newPassword })
    })

    const data = await res.json()
    setLoading(false)

    if (!res.ok) { setError(data.error || 'Fehler'); return }
    setSuccess(true)
    setTimeout(() => router.push('/login'), 2000)
  }

  return (
    <div className="min-h-screen bg-[#0a0e1a] flex items-center justify-center px-4">
      <div className="w-full max-w-md">
        <div className="bg-[#080c18] border border-[#1a1f37] rounded-2xl p-8">
          <h1 className="text-2xl font-bold text-white mb-2">Passwort ändern</h1>
          <p className="text-gray-400 text-sm mb-6">Gib dein altes und neues Passwort ein</p>

          {success ? (
            <div className="bg-emerald-500/10 border border-emerald-500/30 rounded-lg p-4 text-emerald-400 text-center">
              ✅ Passwort erfolgreich geändert! Weiterleitung...
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <label className="text-sm text-gray-400 mb-1 block">Email</label>
                <input type="email" value={email} onChange={e => setEmail(e.target.value)}
                  className="w-full bg-[#0d1220] border border-[#2a2f47] rounded-lg px-4 py-3 text-white focus:outline-none focus:border-[#f0b90b]"
                  required />
              </div>
              <div>
                <label className="text-sm text-gray-400 mb-1 block">Altes Passwort</label>
                <input type="password" value={oldPassword} onChange={e => setOldPassword(e.target.value)}
                  className="w-full bg-[#0d1220] border border-[#2a2f47] rounded-lg px-4 py-3 text-white focus:outline-none focus:border-[#f0b90b]"
                  required />
              </div>
              <div>
                <label className="text-sm text-gray-400 mb-1 block">Neues Passwort</label>
                <input type="password" value={newPassword} onChange={e => setNewPassword(e.target.value)}
                  className="w-full bg-[#0d1220] border border-[#2a2f47] rounded-lg px-4 py-3 text-white focus:outline-none focus:border-[#f0b90b]"
                  required />
              </div>
              <div>
                <label className="text-sm text-gray-400 mb-1 block">Neues Passwort bestätigen</label>
                <input type="password" value={confirm} onChange={e => setConfirm(e.target.value)}
                  className="w-full bg-[#0d1220] border border-[#2a2f47] rounded-lg px-4 py-3 text-white focus:outline-none focus:border-[#f0b90b]"
                  required />
              </div>
              {error && <div className="bg-red-500/10 border border-red-500/30 rounded-lg p-3 text-red-400 text-sm">{error}</div>}
              <button type="submit" disabled={loading}
                className="w-full bg-[#f0b90b] hover:bg-[#d4a017] text-black font-semibold py-3 rounded-lg transition-all disabled:opacity-50">
                {loading ? 'Wird gespeichert...' : 'Passwort ändern'}
              </button>
              <p className="text-center text-gray-500 text-sm">
                <a href="/login" className="text-[#f0b90b] hover:underline">Zurück zum Login</a>
              </p>
            </form>
          )}
        </div>
      </div>
    </div>
  )
}
