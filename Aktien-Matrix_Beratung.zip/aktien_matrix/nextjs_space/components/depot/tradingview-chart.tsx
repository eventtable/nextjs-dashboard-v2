'use client';

import { useState, useMemo } from 'react';
import { ComposedChart, Bar, Line, XAxis, YAxis, Tooltip, ResponsiveContainer, ReferenceLine } from 'recharts';
import { BarChart2, TrendingUp, Activity } from 'lucide-react';

interface TradingViewChartProps {
  ticker: string;
  name: string;
  currentPrice: number;
  fiftyTwoWeekHigh: number;
  fiftyTwoWeekLow: number;
}

// RSI Berechnung
function calculateRSI(prices: number[], period: number = 14): number[] {
  const rsi: number[] = [];
  let gains = 0;
  let losses = 0;
  
  for (let i = 1; i <= period && i < prices.length; i++) {
    const change = prices[i] - prices[i - 1];
    if (change > 0) gains += change;
    else losses -= change;
  }
  
  let avgGain = gains / period;
  let avgLoss = losses / period;
  
  for (let i = 0; i < prices.length; i++) {
    if (i < period) {
      rsi.push(50);
    } else {
      const change = prices[i] - prices[i - 1];
      if (change > 0) {
        avgGain = (avgGain * (period - 1) + change) / period;
        avgLoss = (avgLoss * (period - 1)) / period;
      } else {
        avgGain = (avgGain * (period - 1)) / period;
        avgLoss = (avgLoss * (period - 1) - change) / period;
      }
      const rs = avgLoss === 0 ? 100 : avgGain / avgLoss;
      rsi.push(100 - (100 / (1 + rs)));
    }
  }
  return rsi;
}

// EMA Berechnung
function calculateEMA(prices: number[], period: number): number[] {
  const ema: number[] = [];
  const multiplier = 2 / (period + 1);
  
  for (let i = 0; i < prices.length; i++) {
    if (i === 0) ema.push(prices[i]);
    else {
      const currentEMA = (prices[i] * multiplier) + (ema[i - 1] * (1 - multiplier));
      ema.push(currentEMA);
    }
  }
  return ema;
}

// Kerzendaten mit OHLCV - Zeitrahmen-spezifisch
function generateCandles(currentPrice: number, timeFrame: string) {
  const data = [];
  let price = currentPrice;
  let count = 60;
  let volatility = currentPrice * 0.02;
  
  switch(timeFrame) {
    case '1M': count = 60; volatility = currentPrice * 0.005; break;
    case '5M': count = 48; volatility = currentPrice * 0.008; break;
    case '15M': count = 32; volatility = currentPrice * 0.012; break;
    case '1H': count = 24; volatility = currentPrice * 0.015; break;
    case '4H': count = 30; volatility = currentPrice * 0.025; break;
    case '1D': count = 30; volatility = currentPrice * 0.03; break;
    case '1W': count = 52; volatility = currentPrice * 0.05; break;
    default: count = 60;
  }
  
  for (let i = 0; i < count; i++) {
    const open = price;
    const change = (Math.random() - 0.48) * volatility;
    price += change;
    const high = Math.max(open, price) + Math.random() * volatility * 0.2;
    const low = Math.min(open, price) - Math.random() * volatility * 0.2;
    const volume = Math.floor(Math.random() * 100000) + 50000;
    
    data.push({
      index: i,
      time: i,
      open: Math.round(open * 100) / 100,
      high: Math.round(high * 100) / 100,
      low: Math.round(low * 100) / 100,
      close: Math.round(price * 100) / 100,
      volume,
      isUp: price >= open,
    });
  }
  return data;
}

export default function TradingViewChart({
  ticker,
  name,
  currentPrice,
}: TradingViewChartProps) {
  const [showFibonacci, setShowFibonacci] = useState(false);
  const [showSupportResistance, setShowSupportResistance] = useState(false);
  const [showMax, setShowMax] = useState(false);
  const [showEMA20, setShowEMA20] = useState(false);
  const [showEMA50, setShowEMA50] = useState(true);
  const [showEMA100, setShowEMA100] = useState(false);
  const [showEMA200, setShowEMA200] = useState(false);
  const [showVolume, setShowVolume] = useState(true);
  const [showRSI, setShowRSI] = useState(false);
  const [chartType, setChartType] = useState<'candles' | 'line'>('candles');
  const [timeFrame, setTimeFrame] = useState('1H');

  // Generiere Daten - REAGIERT auf timeFrame Änderung!
  const rawData = useMemo(() => {
    return generateCandles(currentPrice, timeFrame);
  }, [currentPrice, timeFrame]);

  // Berechne EMAs
  const prices = rawData.map(d => d.close);
  const ema20 = calculateEMA(prices, 20);
  const ema50 = calculateEMA(prices, 50);
  const ema100 = calculateEMA(prices, 100);
  const ema200 = calculateEMA(prices, 200);
  const rsi = calculateRSI(prices, 14);

  const chartData = rawData.map((d, i) => ({
    ...d,
    ema20: ema20[i],
    ema50: ema50[i],
    ema100: ema100[i],
    ema200: ema200[i],
    rsi: rsi[i],
  }));

  // Chart-Bereich
  const allPrices = chartData.flatMap(d => [d.open, d.high, d.low, d.close].filter(v => v > 0));
  const minPrice = Math.min(...allPrices);
  const maxPrice = Math.max(...allPrices);
  const priceRange = maxPrice - minPrice;

  // Fibonacci
  const fib382 = maxPrice - priceRange * 0.382;
  const fib50 = maxPrice - priceRange * 0.5;
  const fib618 = maxPrice - priceRange * 0.618;

  // Widerstands- und Supportzonen (letzte 3 Hochs/Tiefs)
  const recentHighs = [...chartData.map(d => d.high)].sort((a, b) => b - a).slice(0, 3);
  const recentLows = [...chartData.map(d => d.low)].sort((a, b) => a - b).slice(0, 3);

  // EINFACHE Candlestick Shape
  const CandleShape = (props: any) => {
    const { x, y, width, height, payload } = props;
    if (!payload) return null;
    
    const { open, high, low, close, isUp } = payload;
    const color = isUp ? '#22c55e' : '#ef4444';
    
    // Chart-Scaling
    const chartDomain = maxPrice - minPrice;
    const chartHeight = 200;
    
    // Y-Positionen (von oben nach unten = high zu low)
    const getY = (price: number) => {
      return ((maxPrice - price) / chartDomain) * chartHeight;
    };
    
    const yHigh = getY(high);
    const yLow = getY(low);
    const yOpen = getY(open);
    const yClose = getY(close);
    
    // Body
    const bodyTop = Math.min(yOpen, yClose);
    const bodyHeight = Math.max(Math.abs(yClose - yOpen), 1);
    const centerX = x + width / 2;
    const candleWidth = Math.max(width * 0.6, 4);
    
    return (
      <g>
        {/* Wick */}
        <line
          x1={centerX}
          y1={yHigh}
          x2={centerX}
          y2={yLow}
          stroke={color}
          strokeWidth={1}
        />
        {/* Body */}
        <rect
          x={x + (width - candleWidth) / 2}
          y={bodyTop}
          width={candleWidth}
          height={bodyHeight}
          fill={color}
          stroke={color}
          strokeWidth={1}
        />
      </g>
    );
  };

  return (
    <div className="bg-[#0d1220] border border-[#1a1f37] rounded-xl p-4">
      {/* Header */}
      <div className="flex items-center justify-between mb-3">
        <div className="flex items-center gap-2">
          <BarChart2 className="w-5 h-5 text-[#f0b90b]" />
          <h3 className="text-base font-semibold text-white">
            {name} <span className="text-gray-400">({ticker})</span>
          </h3>
        </div>
        
        <div className="flex gap-1">
          {['1M', '5M', '15M', '1H', '4H', '1D', '1W'].map((tf) => (
            <button
              key={tf}
              onClick={() => setTimeFrame(tf)}
              className={`px-2 py-1 text-xs rounded ${
                timeFrame === tf ? 'bg-[#f0b90b] text-black' : 'bg-[#1a1f37] text-gray-400'
              }`}
            >
              {tf}
            </button>
          ))}
        </div>
      </div>

      {/* Chart-Typ Toggle */}
      <div className="flex gap-1 mb-3">
        <button onClick={() => setChartType('candles')} className={`px-3 py-1 text-xs rounded ${chartType === 'candles' ? 'bg-[#00bfff] text-black' : 'bg-[#1a1f37] text-gray-400'}`}>
          Kerzen
        </button>
        <button onClick={() => setChartType('line')} className={`px-3 py-1 text-xs rounded ${chartType === 'line' ? 'bg-[#00bfff] text-black' : 'bg-[#1a1f37] text-gray-400'}`}>
          Linie
        </button>
      </div>

      {/* Haupt-Chart */}
      <div style={{ height: 250 }}>
        <ResponsiveContainer width="100%" height="100%">
          <ComposedChart data={chartData} margin={{ top: 5, right: 30, left: 10, bottom: 25 }}>
            <XAxis dataKey="time" tick={{ fontSize: 9, fill: '#666' }} tickCount={6} />
            <YAxis 
              domain={[minPrice - priceRange * 0.02, maxPrice + priceRange * 0.02]} 
              tick={{ fontSize: 10, fill: '#666' }} 
              width={55}
              tickFormatter={(val) => val.toFixed(2)}
            />
            <Tooltip 
              contentStyle={{ backgroundColor: '#0d1220', border: '1px solid #1a1f37', fontSize: 11 }}
              formatter={(val: any, name: string) => [typeof val === 'number' ? val.toFixed(2) : val, name]}
            />
            
            {showFibonacci && (
              <>
                <ReferenceLine y={fib382} stroke="#00bfff" strokeDasharray="3 3" />
                <ReferenceLine y={fib50} stroke="#00bfff" strokeDasharray="5 5" strokeWidth={2} />
                <ReferenceLine y={fib618} stroke="#00bfff" strokeDasharray="3 3" />
              </>
            )}

            {showSupportResistance && (
              <>
                {recentHighs.map((level, i) => (
                  <ReferenceLine key={`res-${i}`} y={level} stroke="#ef4444" strokeDasharray="2 2" strokeOpacity={0.6} />
                ))}
                {recentLows.map((level, i) => (
                  <ReferenceLine key={`sup-${i}`} y={level} stroke="#22c55e" strokeDasharray="2 2" strokeOpacity={0.6} />
                ))}
              </>
            )}

            {showMax && (
              <ReferenceLine y={maxPrice} stroke="#ffffff" strokeDasharray="4 4" strokeWidth={2} />
            )}
            
            {chartType === 'candles' ? (
              <Bar dataKey="close" shape={<CandleShape />} />
            ) : (
              <Line type="monotone" dataKey="close" stroke="#22c55e" strokeWidth={2.5} dot={false} strokeLinecap="round" />
            )}
            
            {showEMA20 && <Line type="monotone" dataKey="ema20" stroke="#00ff88" strokeWidth={2} dot={false} strokeLinecap="round" />}
            {showEMA50 && <Line type="monotone" dataKey="ema50" stroke="#ffdd00" strokeWidth={2} dot={false} strokeLinecap="round" />}
            {showEMA100 && <Line type="monotone" dataKey="ema100" stroke="#ff8800" strokeWidth={2} dot={false} strokeLinecap="round" />}
            {showEMA200 && <Line type="monotone" dataKey="ema200" stroke="#ff3366" strokeWidth={2} dot={false} strokeLinecap="round" />}
          </ComposedChart>
        </ResponsiveContainer>
      </div>

      {/* Volumen-Chart */}
      {showVolume && (
        <div style={{ height: 60, marginTop: 2 }}>
          <ResponsiveContainer width="100%" height="100%">
            <ComposedChart data={chartData} margin={{ top: 0, right: 30, left: 10, bottom: 0 }}>
              <XAxis dataKey="time" hide />
              <YAxis hide />
              <Bar dataKey="volume" fill="#22c55e" />
            </ComposedChart>
          </ResponsiveContainer>
        </div>
      )}

      {/* RSI-Chart */}
      {showRSI && (
        <div style={{ height: 50, marginTop: 2 }}>
          <ResponsiveContainer width="100%" height="100%">
            <ComposedChart data={chartData} margin={{ top: 0, right: 30, left: 10, bottom: 0 }}>
              <XAxis dataKey="time" hide />
              <YAxis domain={[0, 100]} tick={{ fontSize: 9, fill: '#666' }} width={25} />
              <ReferenceLine y={70} stroke="#ef4444" strokeDasharray="2 2" />
              <ReferenceLine y={30} stroke="#22c55e" strokeDasharray="2 2" />
              <Line type="linear" dataKey="rsi" stroke="#60b5ff" strokeWidth={1} dot={false} />
            </ComposedChart>
          </ResponsiveContainer>
        </div>
      )}

      {/* Controls */}
      <div className="flex flex-wrap gap-2 mt-3 justify-center">
        <button onClick={() => setChartType(chartType === 'candles' ? 'line' : 'candles')} className={`px-2 py-1 text-xs rounded`}>
          {chartType === 'candles' ? '🔥 Kerzen' : '📈 Linie'}
        </button>
        <button onClick={() => setShowFibonacci(!showFibonacci)} className={`px-2 py-1 text-xs rounded flex items-center gap-1 ${showFibonacci ? 'bg-[#00bfff]/20 text-[#00bfff]' : 'bg-[#1a1f37] text-gray-400'}`}>
          <TrendingUp className="w-3 h-3" /> Fib
        </button>

        <button onClick={() => setShowSupportResistance(!showSupportResistance)} className={`px-2 py-1 text-xs rounded ${showSupportResistance ? 'bg-[#ff6b6b]/20 text-[#ff6b6b]' : 'bg-[#1a1f37] text-gray-400'}`}>
          S/R Zonen
        </button>

        <button onClick={() => setShowMax(!showMax)} className={`px-2 py-1 text-xs rounded ${showMax ? 'bg-[#ffffff]/30 text-white' : 'bg-[#1a1f37] text-gray-400'}`}>
          MAX
        </button>
        <button onClick={() => setShowEMA20(!showEMA20)} className={`px-2 py-1 text-xs rounded ${showEMA20 ? 'bg-[#00ff88]/20 text-[#00ff88]' : 'bg-[#1a1f37] text-gray-400'}`}>EMA 20</button>
        <button onClick={() => setShowEMA50(!showEMA50)} className={`px-2 py-1 text-xs rounded ${showEMA50 ? 'bg-[#ffdd00]/20 text-[#ffdd00]' : 'bg-[#1a1f37] text-gray-400'}`}>EMA 50</button>
        <button onClick={() => setShowEMA100(!showEMA100)} className={`px-2 py-1 text-xs rounded ${showEMA100 ? 'bg-[#ff8800]/20 text-[#ff8800]' : 'bg-[#1a1f37] text-gray-400'}`}>EMA 100</button>
        <button onClick={() => setShowEMA200(!showEMA200)} className={`px-2 py-1 text-xs rounded ${showEMA200 ? 'bg-[#ff3366]/20 text-[#ff3366]' : 'bg-[#1a1f37] text-gray-400'}`}>EMA 200</button>
        <button onClick={() => setShowVolume(!showVolume)} className={`px-2 py-1 text-xs rounded ${showVolume ? 'bg-[#22c55e]/20 text-[#22c55e]' : 'bg-[#1a1f37] text-gray-400'}`}>Volumen</button>
        <button onClick={() => setShowRSI(!showRSI)} className={`px-2 py-1 text-xs rounded flex items-center gap-1 ${showRSI ? 'bg-[#60b5ff]/20 text-[#60b5ff]' : 'bg-[#1a1f37] text-gray-400'}`}>
          <Activity className="w-3 h-3" /> RSI
        </button>
      </div>
    </div>
  );
}
