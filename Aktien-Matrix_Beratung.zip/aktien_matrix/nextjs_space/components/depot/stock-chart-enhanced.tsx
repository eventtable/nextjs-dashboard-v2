'use client';

import React, { useState, useMemo } from 'react';
import { 
  AreaChart, 
  Area, 
  XAxis, 
  YAxis, 
  Tooltip, 
  ResponsiveContainer, 
  ReferenceLine,
  Line
} from 'recharts';
import { BarChart2, TrendingUp } from 'lucide-react';

interface ChartPoint {
  date: string;
  close: number;
  open?: number;
  high?: number;
  low?: number;
  volume?: number;
}

interface StockChartEnhancedProps {
  ticker: string;
  name: string;
  currentPrice: number;
  fiftyTwoWeekHigh: number;
  fiftyTwoWeekLow: number;
  chartData?: ChartPoint[];
}

// Einfache gleitende Durchschnitts-Berechnung (keine EMA, einfach SMA)
function calculateSMA(prices: number[], period: number): (number | null)[] {
  const sma: (number | null)[] = [];
  
  for (let i = 0; i < prices.length; i++) {
    if (i < period - 1) {
      sma.push(null);
    } else {
      const sum = prices.slice(i - period + 1, i + 1).reduce((a, b) => a + b, 0);
      sma.push(sum / period);
    }
  }
  
  return sma;
}

// Mock-Daten generieren
function generateMockData(
  currentPrice: number, 
  high52w: number, 
  low52w: number,
  days: number
): ChartPoint[] {
  const data: ChartPoint[] = [];
  const today = new Date();
  const volatility = (high52w - low52w) * 0.015;
  let price = currentPrice * (0.9 + Math.random() * 0.1);
  
  for (let i = days; i >= 0; i--) {
    const date = new Date(today);
    date.setDate(date.getDate() - i);
    if (date.getDay() === 0 || date.getDay() === 6) continue;
    
    const change = (Math.random() - 0.48) * volatility;
    price += change;
    
    data.push({
      date: date.toISOString().split('T')[0],
      close: Math.round(price * 100) / 100,
    });
  }
  
  return data;
}

export default function StockChartEnhanced({
  ticker,
  name,
  currentPrice,
  fiftyTwoWeekHigh,
  fiftyTwoWeekLow,
  chartData: externalChartData,
}: StockChartEnhancedProps) {
  const [showFibonacci, setShowFibonacci] = useState(false);
  const [showSMA50, setShowSMA50] = useState(true);
  const [range, setRange] = useState<'1m' | '3m' | '6m' | '1y'>('3m');

  const daysForRange = { '1m': 30, '3m': 90, '6m': 180, '1y': 365 };

  // Generiere Daten
  const chartData = useMemo(() => {
    const days = daysForRange[range];
    if (externalChartData && externalChartData.length > 0) {
      const cutoffDate = new Date();
      cutoffDate.setDate(cutoffDate.getDate() - days);
      return externalChartData.filter(d => new Date(d.date) >= cutoffDate);
    }
    return generateMockData(currentPrice, fiftyTwoWeekHigh, fiftyTwoWeekLow, days);
  }, [externalChartData, currentPrice, fiftyTwoWeekHigh, fiftyTwoWeekLow, range]);

  // Berechne SMA (einfacher gleitender Durchschnitt)
  const prices = chartData.map(d => d.close);
  const sma50 = calculateSMA(prices, 50);

  // Kombiniere Daten - NUR Punkte mit SMA-Werten
  const combinedData = useMemo(() => {
    return chartData.map((point, index) => ({
      ...point,
      sma50: sma50[index],
      label: (() => {
        const d = point.date;
        const parts = d.split('-');
        return `${parts[2]}.${parts[1]}.${parts[0].slice(2)}`;
      })(),
    })).slice(49); // Entferne erst 49 Punkte ohne SMA
  }, [chartData, sma50]);

  // Berechne Fibonacci
  const fibLevel50 = fiftyTwoWeekLow + (fiftyTwoWeekHigh - fiftyTwoWeekLow) * 0.5;

  const minPrice = Math.min(...combinedData.map(d => d.close));
  const maxPrice = Math.max(...combinedData.map(d => d.close));
  const padding = (maxPrice - minPrice) * 0.1;
  const yDomain = [minPrice - padding, maxPrice + padding];

  return (
    <div className="glass-card rounded-xl p-5 bg-[#0d1220] border border-[#1a1f37]">
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-2">
          <BarChart2 className="w-5 h-5 text-[#f0b90b]" />
          <div>
            <h3 className="text-base font-semibold text-white">
              {name} <span className="text-gray-400">({ticker})</span>
            </h3>
            <p className="text-xs text-gray-500">
              {range === '1m' ? '30 Tage' : range === '3m' ? '3 Monate' : range === '6m' ? '6 Monate' : '1 Jahr'} 
              • {combinedData.length} Punkte
            </p>
          </div>
        </div>
        
        <div className="flex gap-1">
          {(['1m', '3m', '6m', '1y'] as const).map((r) => (
            <button
              key={r}
              onClick={() => setRange(r)}
              className={`px-3 py-1.5 text-xs rounded-lg font-medium ${
                range === r ? 'bg-[#f0b90b] text-black' : 'bg-[#1a1f37] text-gray-400'
              }`}
            >
              {r === '1m' ? '1M' : r === '3m' ? '3M' : r === '6m' ? '6M' : '1J'}
            </button>
          ))}
        </div>
      </div>

      <div className="w-full" style={{ height: 350 }}>
        <ResponsiveContainer width="100%" height="100%">
          <AreaChart data={combinedData} margin={{ top: 20, right: 15, left: 15, bottom: 25 }}>
            <defs>
              <linearGradient id={`grad-${ticker}`} x1="0" y1="0" x2="0" y2="1">
                <stop offset="5%" stopColor="#22c55e" stopOpacity={0.4} />
                <stop offset="95%" stopColor="#22c55e" stopOpacity={0.05} />
              </linearGradient>
            </defs>
            
            <XAxis dataKey="label" tick={{ fontSize: 10, fill: '#6b7280' }} angle={-45} textAnchor="end" height={50} />
            <YAxis domain={yDomain} tick={{ fontSize: 10, fill: '#6b7280' }} width={60} />
            
            <Tooltip contentStyle={{ backgroundColor: '#0f1629', border: '1px solid #1a1f37', borderRadius: 8, fontSize: 11 }} />

            {/* Fibonacci 50% - GEPUNKTET */}
            {showFibonacci && (
              <ReferenceLine 
                y={fibLevel50} 
                stroke="#00bfff"
                strokeDasharray="8 4"
                strokeWidth={2}
                label={{ value: '50%', position: 'insideTopLeft', fill: '#00bfff', fontSize: 11 }}
              />
            )}

            {/* SMA 50 - GEPUNKTETE GESTRICHELTE LINIE MIT PUNKTEN */}
            {showSMA50 && (
              <Line
                type="monotone"
                dataKey="sma50"
                stroke="#00ffaa"
                strokeWidth={3}
                strokeDasharray="5 5"
                dot={{ r: 4, fill: '#00ffaa' }}
                activeDot={{ r: 6 }}
              />
            )}

            {/* Haupt-Area */}
            <Area
              type="monotone"
              dataKey="close"
              stroke="#22c55e"
              strokeWidth={2}
              fill={`url(#grad-${ticker})`}
              dot={false}
            />
          </AreaChart>
        </ResponsiveContainer>
      </div>

      {/* Toggle-Buttons */}
      <div className="flex flex-wrap gap-2 mt-4 justify-center">
        <button
          onClick={() => setShowFibonacci(!showFibonacci)}
          className={`px-3 py-1.5 text-xs rounded-lg ${
            showFibonacci ? 'bg-[#00bfff]/20 text-[#00bfff] border border-[#00bfff]/50' : 'bg-[#1a1f37] text-gray-400'
          }`}
        >
          <TrendingUp className="w-3 h-3 inline mr-1" />
          50% Level
        </button>

        <button
          onClick={() => setShowSMA50(!showSMA50)}
          className={`px-3 py-1.5 text-xs rounded-lg flex items-center gap-1.5 ${
            showSMA50 ? 'bg-[#00ffaa]/20 text-[#00ffaa] border border-[#00ffaa]/50' : 'bg-[#1a1f37] text-gray-400'
          }`}
        >
          <span className="w-3 h-3 rounded-full bg-[#00ffaa]"></span>
          SMA 50 (gepunktet)
        </button>
      </div>
    </div>
  );
}