'use client';

import React, { useState, useMemo } from 'react';
import { 
  AreaChart, 
  Area, 
  XAxis, 
  YAxis, 
  Tooltip, 
  ResponsiveContainer, 
  ReferenceLine,
  Line
} from 'recharts';
import { BarChart2 } from 'lucide-react';

interface StockChartTestProps {
  ticker: string;
  name: string;
  currentPrice: number;
  fiftyTwoWeekHigh: number;
  fiftyTwoWeekLow: number;
}

// Einfache EMA-Berechnung
function calculateEMA(prices: number[], period: number): (number | null)[] {
  const k = 2 / (period + 1);
  const ema: (number | null)[] = [];
  let emaPrev: number | null = null;

  for (let i = 0; i < prices.length; i++) {
    if (i < period - 1) {
      ema.push(null);
    } else if (emaPrev === null) {
      const sum = prices.slice(i - period + 1, i + 1).reduce((a, b) => a + b, 0);
      emaPrev = sum / period;
      ema.push(emaPrev);
    } else {
      emaPrev = (prices[i] * k) + (emaPrev * (1 - k));
      ema.push(emaPrev);
    }
  }
  return ema;
}

// Mock-Daten
function generateData(currentPrice: number, days: number) {
  const data: any[] = [];
  const today = new Date();
  let price = currentPrice * 0.95;
  
  for (let i = days + 200; i >= 0; i--) {
    const date = new Date(today);
    date.setDate(date.getDate() - i);
    if (date.getDay() === 0 || date.getDay() === 6) continue;
    
    const change = (Math.random() - 0.48) * (currentPrice * 0.02);
    price += change;
    
    data.push({
      date: date.toISOString().split('T')[0],
      close: price,
      label: `${date.getDate()}.${date.getMonth() + 1}.`,
    });
  }
  return data;
}

export default function StockChartTest({
  ticker,
  name,
  currentPrice,
}: StockChartTestProps) {
  const [showEMA50, setShowEMA50] = useState(true);
  const [showEMA100, setShowEMA100] = useState(true);
  const [showEMA200, setShowEMA200] = useState(true);

  // Generiere Daten
  const allData = useMemo(() => generateData(currentPrice, 90), [currentPrice]);
  
  // Berechne EMAs
  const prices = allData.map(d => d.close);
  const ema50 = calculateEMA(prices, 50);
  const ema100 = calculateEMA(prices, 100);
  const ema200 = calculateEMA(prices, 200);
  
  // Kombiniere und entferne erstes Drittel (wo EMAs noch null)
  const sliceIndex = 200;
  const chartData = allData.slice(sliceIndex).map((d, i) => ({
    ...d,
    ema50: ema50[i + sliceIndex] ?? null,
    ema100: ema100[i + sliceIndex] ?? null,
    ema200: ema200[i + sliceIndex] ?? null,
  }));
  
  // DEBUG: Zeige die ersten paar EMA-Werte
  console.log('EMA 50 first values:', ema50.slice(sliceIndex, sliceIndex + 5));
  console.log('Chart data points:', chartData.length);

  const lastPrice = chartData[chartData.length - 1]?.close || currentPrice;
  const minPrice = Math.min(...chartData.map(d => d.close));
  const maxPrice = Math.max(...chartData.map(d => d.close));
  const padding = (maxPrice - minPrice) * 0.1;

  return (
    <div className="glass-card rounded-xl p-5 bg-[#0d1220] border border-[#1a1f37]">
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-base font-semibold text-white flex items-center gap-2">
          <BarChart2 className="w-5 h-5 text-[#f0b90b]" />
          {name} ({ticker})
        </h3>
        <div className="flex gap-2">
          <button onClick={() => setShowEMA50(!showEMA50)} 
            className={`px-3 py-1 text-xs rounded ${showEMA50 ? 'bg-[#00ff88] text-black font-bold' : 'bg-[#333] text-gray-400'}`}>
            EMA 50
          </button>
          <button onClick={() => setShowEMA100(!showEMA100)}
            className={`px-3 py-1 text-xs rounded ${showEMA100 ? 'bg-[#ffdd00] text-black font-bold' : 'bg-[#333] text-gray-400'}`}>
            EMA 100
          </button>
          <button onClick={() => setShowEMA200(!showEMA200)}
            className={`px-3 py-1 text-xs rounded ${showEMA200 ? 'bg-[#ff3366] text-black font-bold' : 'bg-[#333] text-gray-400'}`}>
            EMA 200
          </button>
        </div>
      </div>

      <div className="w-full" style={{ height: 300 }}>
        <ResponsiveContainer width="100%" height="100%">
          <AreaChart data={chartData} margin={{ top: 10, right: 20, left: 10, bottom: 20 }}>
            <defs>
              <linearGradient id={`grad-${ticker}`} x1="0" y1="0" x2="0" y2="1">
                <stop offset="5%" stopColor="#22c55e" stopOpacity={0.3} />
                <stop offset="95%" stopColor="#22c55e" stopOpacity={0} />
              </linearGradient>
            </defs>
            
            <XAxis dataKey="label" tick={{ fontSize: 9, fill: '#666' }} interval={10} />
            <YAxis domain={[minPrice - padding, maxPrice + padding]} tick={{ fontSize: 9, fill: '#666' }} width={50} />
            
            <Tooltip contentStyle={{ backgroundColor: '#0f1629', border: '1px solid #333' }} />

            {/* EMA 200 - ROT, immer mit Punkten */}
            {showEMA200 && (
              <Line 
                type="monotone" 
                dataKey="ema200" 
                stroke="#ff3366" 
                strokeWidth={4} 
                dot={{ r: 2, fill: '#ff3366' }} 
                activeDot={{ r: 4 }}
              />
            )}
            
            {/* EMA 100 - GELB */}
            {showEMA100 && (
              <Line 
                type="monotone" 
                dataKey="ema100" 
                stroke="#ffdd00" 
                strokeWidth={4} 
                dot={{ r: 2, fill: '#ffdd00' }}
              />
            )}
            
            {/* EMA 50 - GRÜN */}
            {showEMA50 && (
              <Line 
                type="monotone" 
                dataKey="ema50" 
                stroke="#00ff88" 
                strokeWidth={4} 
                dot={{ r: 2, fill: '#00ff88' }}
              />
            )}

            {/* Haupt-Area */}
            <Area type="monotone" dataKey="close" stroke="#fff" strokeWidth={2} fill={`url(#grad-${ticker})`} dot={false} />
          </AreaChart>
        </ResponsiveContainer>
      </div>

      <p className="text-xs text-gray-500 mt-2 text-center">
        {chartData.length} Datenpunkte | Aktuell: {lastPrice.toFixed(2)}€
      </p>
    </div>
  );
}