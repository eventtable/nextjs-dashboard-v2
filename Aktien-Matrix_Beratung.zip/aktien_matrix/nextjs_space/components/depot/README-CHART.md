# Erweiterte Chart-Komponente für Depot-Dashboard

## Übersicht

Diese Erweiterung fügt dem Depot-Dashboard fortschrittliche technische Indikatoren hinzu:

1. **Fibonacci-Retracement-Levels** - Unterstützungs- und Widerstandslinien basierend auf 52W High/Low
2. **EMA-Linien** - Exponentielle gleitende Durchschnitte (50, 100, 200)
3. **Interaktive Toggle-Buttons** - Ein-/Ausblenden der Indikatoren

## Neue Dateien

### 1. `components/depot/stock-chart-enhanced.tsx`
Die Haupt-Chart-Komponente mit allen neuen Features.

**Props:**
```typescript
interface StockChartEnhancedProps {
  ticker: string;
  name: string;
  currentPrice: number;
  fiftyTwoWeekHigh: number;
  fiftyTwoWeekLow: number;
  chartData?: ChartPoint[]; // Optional: eigene Chart-Daten
}
```

**Features:**
- **Fibonacci-Linien**: Berechnet aus 52W High/Low
  - 38.2% Level (gestrichelt, 70% Opazität)
  - 50% Level (gestrichelt, 80% Opazität)
  - 61.8% Level (gestrichelt, 70% Opazität)
  - Farbe: `#60B5FF` (hellblau)

- **EMA-Linien**:
  - EMA 50: `#00D4AA` (Cyan) - Mittelfristiger Trend
  - EMA 100: `#f0b90b` (Gelb) - Langfristiger Trend  
  - EMA 200: `#FF6B6B` (Rot) - Sehr langfristiger Trend

- **Zeitraum-Selector**: 1M / 3M / 6M / 1J

- **Toggle-Buttons** unter dem Chart:
  - `[Fibonacci]` - Ein-/Ausblenden der Fibonacci-Linien
  - `[EMA 50]` - Ein-/Ausblenden EMA 50
  - `[EMA 100]` - Ein-/Ausblenden EMA 100
  - `[EMA 200]` - Ein-/Ausblenden EMA 200

**Berechnungen:**

EMA-Formel:
```
EMA_heute = (Kurs × Multiplikator) + (EMA_gestern × (1 - Multiplikator))
Multiplikator = 2 / (Periode + 1)
```

Fibonacci-Levels:
```
Range = 52W High - 52W Low
38.2% = 52W High - Range × 0.382
50%   = 52W High - Range × 0.5
61.8% = 52W High - Range × 0.618
```

### 2. `app/depot/chart-demo/page.tsx`
Demo-Seite zur Visualisierung der neuen Chart-Komponente.

**URL:** `/depot/chart-demo`

**Features:**
- Aktien-Auswahl aus Depot-Bestand
- Live-Vorschau der Charts mit allen Indikatoren
- Info-Boxen zu Fibonacci und EMA

## Integration

### Schritt 1: Komponente importieren
```tsx
import StockChartEnhanced from '@/components/depot/stock-chart-enhanced';
```

### Schritt 2: Verwendung
```tsx
<StockChartEnhanced
  ticker="SAP.DE"
  name="SAP"
  currentPrice={145.80}
  fiftyTwoWeekHigh={168.00}
  fiftyTwoWeekLow={125.00}
/>
```

### Schritt 3: Mit eigenen Chart-Daten
```tsx
const myChartData = [
  { date: '2024-01-01', close: 140.00, open: 139.00, high: 141.00, low: 138.50, volume: 1000000 },
  // ... weitere Datenpunkte
];

<StockChartEnhanced
  ticker="SAP.DE"
  name="SAP"
  currentPrice={145.80}
  fiftyTwoWeekHigh={168.00}
  fiftyTwoWeekLow={125.00}
  chartData={myChartData}
/>
```

### Schritt 4: Auf Depot-Seite verlinken (bereits erledigt)
In `/app/depot/page.tsx` wurde ein Link zur Chart-Demo hinzugefügt.

## Mock-Daten

Wenn keine `chartData` übergeben werden, generiert die Komponente automatisch 90 Tage historische Mock-Daten basierend auf:
- Aktueller Preis als Zielwert
- 52W High/Low als Volatilitäts-Bounds
- Realistische zufällige Schwankungen mit Trend

## Technische Details

- **Framework**: React + TypeScript + Next.js
- **Charts**: Recharts (ComposedChart, Area, Line, ReferenceLine)
- **Styling**: Tailwind CSS
- **Icons**: Lucide React
- **Theme**: Dark Mode (beibehalten)

## Anpassungen

### Farben ändern
In `stock-chart-enhanced.tsx` suchen nach:
- Fibonacci: `stroke="#60B5FF"`
- EMA 50: `stroke="#00D4AA"`
- EMA 100: `stroke="#f0b90b"`
- EMA 200: `stroke="#FF6B6B"`

### Standard-Zustände ändern
In der Komponente suchen nach:
```tsx
const [showFibonacci, setShowFibonacci] = useState(false);
const [showEMA50, setShowEMA50] = useState(true);
const [showEMA100, setShowEMA100] = useState(false);
const [showEMA200, setShowEMA200] = useState(false);
```

## Testing

1. **Dev-Server starten:**
   ```bash
   npm run dev
   ```

2. **Zur Chart-Demo navigieren:**
   - Depot-Seite öffnen: `http://localhost:3000/depot`
   - Auf "Erweiterte Chart-Analyse" klicken
   - Oder direkt: `http://localhost:3000/depot/chart-demo`

3. **Features testen:**
   - Aktien auswählen (Buttons oben)
   - Toggle-Buttons für Indikatoren testen
   - Zeitraum wechseln (1M/3M/6M/1J)
   - Tooltip bei Hover über Chart prüfen

## Zukünftige Erweiterungen

- [ ] Echte API-Integration für historische Daten
- [ ] Weitere Indikatoren (RSI, MACD, Bollinger Bands)
- [ ] Zoom und Pan im Chart
- [ ] Candlestick-Darstellung
- [ ] Vergleich mehrerer Aktien