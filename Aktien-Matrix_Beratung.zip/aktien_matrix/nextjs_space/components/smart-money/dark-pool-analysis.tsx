'use client';

import { Eye, ArrowUp, ArrowDown, Activity, AlertTriangle, BarChart3 } from 'lucide-react';

interface DarkPoolLevel {
  price: string;
  volume: string;
  significance: 'high' | 'medium' | 'low';
}

const darkPoolLevels: DarkPoolLevel[] = [
  { price: '$185.50', volume: '12.5 Mio', significance: 'high' },
  { price: '$182.25', volume: '8.3 Mio', significance: 'high' },
  { price: '$178.90', volume: '15.2 Mio', significance: 'high' },
  { price: '$175.40', volume: '6.8 Mio', significance: 'medium' },
  { price: '$172.15', volume: '9.1 Mio', significance: 'high' },
];

export function DarkPoolAnalysis() {
  return (
    <div className="space-y-6">
      <div className="bg-[#0d1220] border border-[#1a1f37] rounded-xl p-6">
        <div className="flex items-center justify-between mb-6">
          <div>
            <h3 className="text-lg font-semibold flex items-center gap-2">
              <Eye className="w-5 h-5 text-[#f0b90b]" />
              👁️ Dark Pool Analyse
            </h3>
            <p className="text-sm text-gray-400 mt-1">
              Institutionelle Block-Trades außerhalb der öffentlichen Märkte
            </p>
          </div>
          <div className="px-3 py-1 bg-emerald-500/20 text-emerald-400 rounded-full text-sm">
            Live
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
          <div className="bg-[#1a1f37] border border-[#252a3d] rounded-lg p-4">
            <div className="flex items-center gap-2 mb-2">
              <BarChart3 className="w-4 h-4 text-gray-400" />
              <span className="text-sm text-gray-400">Dark Pool Vol</span>
            </div>
            <div className="text-2xl font-bold">45.2 Mio</div>
            <div className="text-xs text-emerald-400">+8.3% vs Ø</div>
          </div>
          <div className="bg-[#1a1f37] border border-[#252a3d] rounded-lg p-4">
            <div className="flex items-center gap-2 mb-2">
              <Activity className="w-4 h-4 text-gray-400" />
              <span className="text-sm text-gray-400">% vom Gesamtvolumen</span>
            </div>
            <div className="text-2xl font-bold">38.5%</div>
            <div className="text-xs text-red-400">+2.1% vs gestern</div>
          </div>
          <div className="bg-[#1a1f37] border border-[#252a3d] rounded-lg p-4">
            <div className="flex items-center gap-2 mb-2">
              <ArrowUp className="w-4 h-4 text-gray-400" />
              <span className="text-sm text-gray-400">Große Käufe (&gt;$1M)</span>
            </div>
            <div className="text-2xl font-bold text-emerald-400">127</div>
            <div className="text-xs text-gray-500">letzte Stunde</div>
          </div>
          <div className="bg-[#1a1f37] border border-[#252a3d] rounded-lg p-4">
            <div className="flex items-center gap-2 mb-2">
              <ArrowDown className="w-4 h-4 text-gray-400" />
              <span className="text-sm text-gray-400">Große Verkäufe (&gt;$1M)</span>
            </div>
            <div className="text-2xl font-bold text-red-400">89</div>
            <div className="text-xs text-gray-500">letzte Stunde</div>
          </div>
        </div>

        <div className="bg-[#1a1f37] border border-[#252a3d] rounded-lg p-4 mb-6">
          <h4 className="font-medium mb-4 flex items-center gap-2">
            <AlertTriangle className="w-4 h-4 text-[#f0b90b]" />
            🔑 Key Dark Pool Levels (SPY)
          </h4>
          <div className="space-y-2">
            {darkPoolLevels.map((level, index) => (
              <div key={level.price} className="flex items-center gap-3">
                <div className="w-8 text-sm text-gray-500">#{index + 1}</div>
                <div className="flex-1">
                  <div className="flex items-center justify-between mb-1">
                    <span className="font-medium">{level.price}</span>
                    <span className="text-sm text-gray-400">{level.volume}</span>
                  </div>
                  <div className="h-2 bg-[#0d1220] rounded-full overflow-hidden">
                    <div
                      className={`h-full rounded-full ${
                        level.significance === 'high'
                          ? 'bg-[#f0b90b]'
                          : level.significance === 'medium'
                          ? 'bg-blue-500'
                          : 'bg-gray-500'
                      }`}
                      style={{ width: `${Math.min(100, (parseFloat(level.volume) / 15.2) * 100)}%` }}
                    />
                  </div>
                </div>
                <span className={`px-2 py-1 text-xs rounded ${
                  level.significance === 'high'
                    ? 'bg-[#f0b90b]/20 text-[#f0b90b]'
                    : level.significance === 'medium'
                    ? 'bg-blue-500/20 text-blue-400'
                    : 'bg-gray-500/20 text-gray-400'
                }`}
                >
                  {level.significance === 'high' ? '🔥 Hoch' : level.significance === 'medium' ? 'Mittel' : 'Niedrig'}
                </span>
              </div>
            ))}
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div className="bg-[#1a1f37] border border-[#252a3d] rounded-lg p-4">
            <h4 className="font-medium mb-3 flex items-center gap-2">
              <ArrowUp className="w-4 h-4 text-emerald-400" />
              📈 Signale (Bullish)
            </h4>
            <ul className="space-y-2 text-sm">
              <li className="flex items-start gap-2">
                <div className="w-1.5 h-1.5 rounded-full bg-emerald-400 mt-1.5" />
                <span className="text-gray-400">
                  Große Block-Käufe bei $182.25
                </span>
              </li>
              <li className="flex items-start gap-2">
                <div className="w-1.5 h-1.5 rounded-full bg-emerald-400 mt-1.5" />
                <span className="text-gray-400">
                  Accumulation im Dark Pool seit 3 Tagen
                </span>
              </li>
              <li className="flex items-start gap-2">
                <div className="w-1.5 h-1.5 rounded-full bg-emerald-400 mt-1.5" />
                <span className="text-gray-400">
                  Premium zu öffentlichem Markt: +0.15%
                </span>
              </li>
            </ul>
          </div>
          <div className="bg-[#1a1f37] border border-[#252a3d] rounded-lg p-4">
            <h4 className="font-medium mb-3 flex items-center gap-2">
              <ArrowDown className="w-4 h-4 text-red-400" />
              📉 Signale (Bearish)
            </h4>
            <ul className="space-y-2 text-sm">
              <li className="flex items-start gap-2">
                <div className="w-1.5 h-1.5 rounded-full bg-red-400 mt-1.5" />
                <span className="text-gray-400">
                  Verkaufswall bei $185.50
                </span>
              </li>
              <li className="flex items-start gap-2">
                <div className="w-1.5 h-1.5 rounded-full bg-red-400 mt-1.5" />
                <span className="text-gray-400">
                  Institutionsflucht über Dark Pools
                </span>
              </li>
              <li className="flex items-start gap-2">
                <div className="w-1.5 h-1.5 rounded-full bg-red-400 mt-1.5" />
                <span className="text-gray-400">
                  Discount zu öffentlichem Markt: -0.08%
                </span>
              </li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
}