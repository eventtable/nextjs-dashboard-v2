import "next-auth";

declare module "next-auth" {
  interface User {
    id?: string;
    isAdmin?: boolean;
    isFriend?: boolean;
    permissions?: {
      canViewDepot?: boolean;
      canViewTrading?: boolean;
      canViewML?: boolean;
      canEdit?: boolean;
    };
  }

  interface Session {
    user: {
      id?: string;
      name?: string | null;
      email?: string | null;
      image?: string | null;
      isAdmin?: boolean;
      isFriend?: boolean;
      permissions?: {
        canViewDepot?: boolean;
        canViewTrading?: boolean;
        canViewML?: boolean;
        canEdit?: boolean;
      };
    };
  }
}

declare module "next-auth/jwt" {
  interface JWT {
    id?: string;
    isAdmin?: boolean;
    isFriend?: boolean;
    permissions?: {
      canViewDepot?: boolean;
      canViewTrading?: boolean;
      canViewML?: boolean;
      canEdit?: boolean;
    };
    name?: string;
  }
}
